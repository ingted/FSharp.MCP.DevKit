namespace Akka.Proc.Supervisor

open System
open System.Text
open System.Text.Json
open Argu
open Akka.FSI.Contracts

module ProcMessageParser =
    type ExecArgs =
        | Id of string
        | [<Mandatory>] Session of string
        | [<Mandatory>] Code of string
        | Refs of string list
        | Loads of string list
        | Args of string list
        | TimeoutMs of int
        | CaptureStdout of bool

        interface IArgParserTemplate with
            member _.Usage = "exec --session <name> --code <text> [--refs ...] [--loads ...]"

    type ListSessionsArgs =
        | All of bool

        interface IArgParserTemplate with
            member _.Usage = "listsessions [--all true|false]"

    type CheckpointArgs =
        | [<Mandatory>] Session of string
        | Id of string
        | Comment of string

        interface IArgParserTemplate with
            member _.Usage = "checkpoint --session <name> [--id <id>] [--comment <text>]"

    type ForkArgs =
        | [<Mandatory>] FromSession of string
        | [<Mandatory>] NewSession of string
        | CheckpointId of string

        interface IArgParserTemplate with
            member _.Usage = "fork --fromsession <name> --newsession <name> [--checkpointid <id>]"

    type JoinArgs =
        | [<Mandatory>] ParentSession of string
        | [<Mandatory>] ChildSessions of string list
        | Reducer of string

        interface IArgParserTemplate with
            member _.Usage = "join --parentsession <name> --childsessions <a> <b> [--reducer <code>]"

    type ExecBatchArgs =
        | Json of string
        | TimeoutMs of int

        interface IArgParserTemplate with
            member _.Usage = "execbatch --json <batch-json> [--timeoutms 30000]"

    let private splitCommandLine (text: string) =
        let args = ResizeArray<string>()
        let buffer = StringBuilder()
        let mutable inQuotes = false
        let mutable escapeInQuotes = false

        let flush () =
            if buffer.Length > 0 then
                args.Add(buffer.ToString())
                buffer.Clear() |> ignore

        for ch in text do
            if inQuotes && escapeInQuotes then
                let unescaped =
                    match ch with
                    | 'n' -> '\n'
                    | 'r' -> '\r'
                    | 't' -> '\t'
                    | '\\' -> '\\'
                    | '"' -> '"'
                    | other -> other
                buffer.Append(unescaped) |> ignore
                escapeInQuotes <- false
            elif inQuotes && ch = '\\' then
                escapeInQuotes <- true
            elif ch = '"' then
                inQuotes <- not inQuotes
            elif Char.IsWhiteSpace ch && not inQuotes then
                flush ()
            else
                buffer.Append(ch) |> ignore

        if escapeInQuotes then
            buffer.Append('\\') |> ignore

        flush ()
        args |> Seq.toList

    let private parseArgs<'T when 'T :> IArgParserTemplate> (argv: string list) =
        let parser = ArgumentParser.Create<'T>(programName = "fsi")
        parser.Parse(argv |> List.toArray, raiseOnUsage = false)

    let private parseExec (argv: string list) : Result<ExecCode, string> =
        let results = parseArgs<ExecArgs> argv
        match results.TryGetResult(<@ ExecArgs.Session @>) with
        | None -> Error "Missing required argument: session"
        | Some session ->
            match results.TryGetResult(<@ ExecArgs.Code @>) with
            | None -> Error "Missing required argument: code"
            | Some code ->
                let id = results.TryGetResult(<@ ExecArgs.Id @>) |> Option.defaultValue(Guid.NewGuid().ToString("N"))
                let refs = results.TryGetResult(<@ ExecArgs.Refs @>) |> Option.defaultValue []
                let loads = results.TryGetResult(<@ ExecArgs.Loads @>) |> Option.defaultValue []
                let args = results.TryGetResult(<@ ExecArgs.Args @>) |> Option.defaultValue []
                let timeoutMs = results.TryGetResult(<@ ExecArgs.TimeoutMs @>)
                let captureStdout = results.TryGetResult(<@ ExecArgs.CaptureStdout @>)
                Ok
                    { id = id
                      session = session
                      code = code
                      refs = refs
                      loads = loads
                      args = if args.IsEmpty then None else Some args
                      timeoutMs = timeoutMs
                      captureStdout = captureStdout }

    let private parseListSessions (argv: string list) : Result<ListSessions, string> =
        let results = parseArgs<ListSessionsArgs> argv
        let all = results.TryGetResult(<@ ListSessionsArgs.All @>) |> Option.defaultValue false
        Ok { all = all }

    let private parseCheckpoint (argv: string list) : Result<Checkpoint, string> =
        let results = parseArgs<CheckpointArgs> argv
        match results.TryGetResult(<@ CheckpointArgs.Session @>) with
        | None -> Error "Missing required argument: session"
        | Some session ->
            let id = results.TryGetResult(<@ CheckpointArgs.Id @>)
            let comment = results.TryGetResult(<@ CheckpointArgs.Comment @>)
            Ok { session = session; id = id; comment = comment }

    let private parseFork (argv: string list) : Result<Fork, string> =
        let results = parseArgs<ForkArgs> argv
        match results.TryGetResult(<@ ForkArgs.FromSession @>) with
        | None -> Error "Missing required argument: fromSession"
        | Some fromSession ->
            match results.TryGetResult(<@ ForkArgs.NewSession @>) with
            | None -> Error "Missing required argument: newSession"
            | Some newSession ->
                let checkpointId = results.TryGetResult(<@ ForkArgs.CheckpointId @>)
                Ok { fromSession = fromSession; newSession = newSession; checkpointId = checkpointId }

    let private parseJoin (argv: string list) : Result<Join, string> =
        let results = parseArgs<JoinArgs> argv
        match results.TryGetResult(<@ JoinArgs.ParentSession @>) with
        | None -> Error "Missing required argument: parentSession"
        | Some parent ->
            match results.TryGetResult(<@ JoinArgs.ChildSessions @>) with
            | None -> Error "Missing required argument: childSessions"
            | Some children ->
                let reducer = results.TryGetResult(<@ JoinArgs.Reducer @>)
                Ok { parentSession = parent; childSessions = children; reducer = reducer }

    let private parseExecBatch (argv: string list) : Result<ExecBatch, string> =
        let results = parseArgs<ExecBatchArgs> argv
        match results.TryGetResult(<@ ExecBatchArgs.Json @>) with
        | None -> Error "Missing required argument: json"
        | Some json ->
            let timeoutMs = results.TryGetResult(<@ ExecBatchArgs.TimeoutMs @>)
            try
                let batch =
                    if json.TrimStart().StartsWith("[", StringComparison.Ordinal) then
                        let items = JsonCodec.deserialize<ExecCode list> json
                        { items = items; timeoutMs = timeoutMs }
                    else
                        let parsed = JsonCodec.deserialize<ExecBatch> json
                        { parsed with timeoutMs = timeoutMs |> Option.orElse parsed.timeoutMs }
                Ok batch
            with ex ->
                Error(sprintf "Invalid ExecBatch json: %s" ex.Message)

    // Design: session name is the routing key used by the FSI supervisor to select the per-session actor.
    // UI can show actor path to disambiguate when session names are not GUIDs.
    let private parseSimpleSession (argv: string list) : Result<GetSessionInfo, string> =
        match argv with
        | session :: _ -> Ok { session = session }
        | [] -> Error "Missing session name."

    let private tryUnwrapMessage (text: string) =
        try
            use doc = JsonDocument.Parse(text)
            if doc.RootElement.ValueKind = JsonValueKind.Object then
                let mutable prop = Unchecked.defaultof<JsonElement>
                if doc.RootElement.TryGetProperty("message", &prop) && prop.ValueKind = JsonValueKind.String then
                    prop.GetString() |> Option.ofObj
                else
                    None
            else
                None
        with _ ->
            None

    let tryParse (text: string) : Result<obj, string> =
        if String.IsNullOrWhiteSpace(text) then
            Error "Message is empty."
        else
            let trimmed = text.Trim()
            let normalized =
                match tryUnwrapMessage trimmed with
                | Some inner when not (String.IsNullOrWhiteSpace inner) -> inner.Trim()
                | _ -> trimmed
            if normalized.StartsWith("{", StringComparison.Ordinal) || normalized.StartsWith("[", StringComparison.Ordinal) then
                Ok(ExecCodeJson normalized :> obj)
            else
                let argv = splitCommandLine normalized
                match argv with
                | [] -> Error "Message is empty."
                | cmd :: rest ->
                    match cmd.Trim().ToLowerInvariant() with
                    | "exec" ->
                        parseExec rest |> Result.map (fun x -> x :> obj)
                    | "execjson" ->
                        let payload =
                            if normalized.Length <= cmd.Length then String.Empty
                            else normalized.Substring(cmd.Length).Trim()
                        Ok(ExecCodeJson payload :> obj)
                    | "getsession"
                    | "getsessioninfo" ->
                        parseSimpleSession rest |> Result.map (fun x -> x :> obj)
                    | "listsessions" ->
                        parseListSessions rest |> Result.map (fun x -> x :> obj)
                    | "checkpoint" ->
                        parseCheckpoint rest |> Result.map (fun x -> x :> obj)
                    | "fork" ->
                        parseFork rest |> Result.map (fun x -> x :> obj)
                    | "join" ->
                        parseJoin rest |> Result.map (fun x -> x :> obj)
                    | "execbatch" ->
                        parseExecBatch rest |> Result.map (fun x -> x :> obj)
                    | other ->
                        Error(sprintf "Unknown command: %s" other)
