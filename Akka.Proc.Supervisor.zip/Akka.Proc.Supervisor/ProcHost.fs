﻿namespace Akka.Proc.Supervisor

open System
open System.IO
open System.Reflection
open System.Diagnostics
open System.Net
open System.Net.Sockets
open System.Threading
open System.Collections
open Akka.Actor
open Akka.Configuration
open Akka.Cluster
open Akka.Cluster.Sharding
open Akka.DistributedData
open Akka.Quartz.Actor
open Akka.WebSocketBridge
open Akka.Serialization
open Argu
open FAkka.Util
open Akka.FSI.Supervisor
open Akka.FSI.Contracts

type HostMode =
    | Supervisor
    | ProcNode

type ProcCliArgs =
    | Mode of string
    | Seed of string list
    | Role of string list
    | ProcNodeRole of string list
    | SystemName of string
    | Host of string
    | Port of int
    | WebHost of string
    | WebPort of int
    | Hocon of string
    | Supervisor of string
    | ProcId of string
    | Spawn of string
    | SpawnArg of string list
    | SpawnWorkDir of string
    | SpawnDefault
    | SpawnNone
    | Probe of string
    | ProbeCron of string
    | ProbeIntervalMs of int
    | ScheduleQ of string

    interface IArgParserTemplate with
        member _.Usage = "Proc supervisor host arguments."

module ProcHost =
    let private dumpSerializationState (label: string) (system: ActorSystem) =
        try
            let flags = BindingFlags.NonPublic ||| BindingFlags.Instance
            let fields =
                system.Serialization.GetType().GetFields(flags)
                |> Array.map (fun f -> f.Name, f)
                |> Map.ofArray

            let serializersById =
                match fields.TryFind "_serializersById" with
                | Some field ->
                    match field.GetValue(system.Serialization) with
                    | :? IDictionary as dict ->
                        dict.Keys
                        |> Seq.cast<obj>
                        |> Seq.map (fun key ->
                            let serializer = dict[key] :?> Serializer
                            string key, serializer.GetType().AssemblyQualifiedName)
                        |> Seq.sortBy fst
                        |> Seq.toArray
                    | _ -> [||]
                | None -> [||]

            let identifiersCfg = system.Settings.Config.GetConfig("akka.actor.serialization-identifiers")
            let opCmdSerializer = system.Serialization.FindSerializerForType(typeof<OpCmd>)
            let opResultSerializer = system.Serialization.FindSerializerForType(typeof<OpResult>)
            let procInfoSerializer = system.Serialization.FindSerializerForType(typeof<GetAllProcInfo>)

            printfn "[ProcHost.Serialization][%s] identifiers=%s" label (if isNull identifiersCfg then "<null>" else identifiersCfg.ToString())
            serializersById
            |> Array.iter (fun (key, serializerType) ->
                printfn "[ProcHost.Serialization][%s] serializerId=%s type=%s" label key serializerType)
            printfn "[ProcHost.Serialization][%s] OpCmd -> id=%d type=%s" label opCmdSerializer.Identifier (opCmdSerializer.GetType().AssemblyQualifiedName)
            printfn "[ProcHost.Serialization][%s] OpResult -> id=%d type=%s" label opResultSerializer.Identifier (opResultSerializer.GetType().AssemblyQualifiedName)
            printfn "[ProcHost.Serialization][%s] GetAllProcInfo -> id=%d type=%s" label procInfoSerializer.Identifier (procInfoSerializer.GetType().AssemblyQualifiedName)
        with ex ->
            printfn "[ProcHost.Serialization][%s] dump failed: %s" label ex.Message

    let private getFreePort () =
        use listener = new TcpListener(IPAddress.Any, 0)
        listener.Start()
        let port = (listener.LocalEndpoint :?> IPEndPoint).Port
        listener.Stop()
        port

    let private defaultHocon (host: string) =
        $"""
akka {{
  loglevel = "INFO"
  stdout-loglevel = "INFO"
  actor.provider = "cluster"

  remote.dot-netty.tcp {{
    hostname = "{host}"
    port = 0
  }}

  cluster {{
    roles = []
    sharding {{
      state-store-mode = "ddata"
      entity-recovery-strategy = "all"
      coordinator-singleton = "akka.cluster.singleton"
    }}
  }}
  cluster.singleton {{
    singleton-name = "singleton"
    role = ""
    hand-over-retry-interval = 1s
    min-number-of-hand-over-retries = 15
    use-lease = ""
    lease-retry-interval = 5s
    consider-app-version = false
  }}

  proc {{
    system-name = "proc-system"
    sharding {{
      type-name = "proc-node"
      number-of-shards = 100
    }}
    web {{
      host = "0.0.0.0"
      port = 6001
    }}
  }}
}}
"""

    let private loadConfig (args: ParseResults<ProcCliArgs>) =
        let contractSerializationConfig =
            Akka.FSI.Contracts.ContractSerialization.configForAssemblies [ typeof<Akka.FSI.Contracts.IMessage>.Assembly; typeof<ProcStartSpec>.Assembly ]

        let hoconPath =
            args.TryGetResult(<@ Hocon @>)
            |> Option.defaultValue ".hocon"

        let baseHost =
            args.TryGetResult(<@ Host @>)
            |> Option.defaultValue(
                try Networking.getMyIpWithTimeout 200
                with _ -> "127.0.0.1"
            )

        let baseConfig =
            if File.Exists hoconPath then
                File.ReadAllText hoconPath |> ConfigurationFactory.ParseString
            else
                defaultHocon baseHost |> ConfigurationFactory.ParseString

        let baseConfig = contractSerializationConfig.WithFallback(baseConfig)

        let overrides =
            let hostOverride =
                args.TryGetResult(<@ Host @>)
                |> Option.map (fun h -> $"akka.remote.dot-netty.tcp.hostname = \"{h}\"")
            let portOverride =
                args.TryGetResult(<@ Port @>)
                |> Option.map (fun p -> $"akka.remote.dot-netty.tcp.port = {p}")
            let roleOverride =
                args.TryGetResult(<@ Role @>)
                |> Option.filter (fun r -> not r.IsEmpty)
                |> Option.map (fun roles ->
                    let literal = roles |> List.map (fun r -> $"\"{r}\"") |> String.concat ", "
                    $"akka.cluster.roles = [{literal}]")
            [ hostOverride; portOverride; roleOverride ]
            |> List.choose id
            |> String.concat "\n"

        let combined =
            if String.IsNullOrWhiteSpace overrides then
                baseConfig
            else
                ConfigurationFactory.ParseString(overrides)
                    .WithFallback(baseConfig)
        let remoteDefaults =
            ConfigurationFactory.FromResource(
                "Akka.Remote.Configuration.Remote.conf",
                typeof<Akka.Remote.RemoteActorRefProvider>.Assembly)
        let distributedDataDefaults = Akka.DistributedData.DistributedData.DefaultConfig()
        let shardingDefaults = ClusterSharding.DefaultConfig()
        let singletonDefaults = Akka.Cluster.Tools.Singleton.ClusterSingleton.DefaultConfig()
        combined.WithFallback(
            remoteDefaults
                .WithFallback(distributedDataDefaults)
                .WithFallback(shardingDefaults)
                .WithFallback(singletonDefaults)
                .WithFallback(ConfigurationFactory.Default()))

    let private resolveMode (args: ParseResults<ProcCliArgs>) =
        let modeOpt: string option = args.TryGetResult(<@ Mode @>)
        match modeOpt with
        | Some value when String.Equals(value, "supervisor", StringComparison.OrdinalIgnoreCase) -> HostMode.Supervisor
        | Some value when String.Equals(value, "procnode", StringComparison.OrdinalIgnoreCase) -> HostMode.ProcNode
        | _ -> HostMode.ProcNode

    let private joinCluster (system: ActorSystem) (seeds: string list) =
        let cluster = Cluster.Get system
        if seeds.IsEmpty then
            cluster.Join(cluster.SelfAddress)
        else
            let addresses =
                seeds
                |> List.map Address.Parse
                |> List.toArray
            cluster.JoinSeedNodes addresses

    type HealthActor() as this =
        inherit ReceiveActor()

        do
            this.Receive<string>(fun msg ->
                if String.Equals(msg, "healthcheck", StringComparison.OrdinalIgnoreCase) then
                    let ctx = this.ActorCtx
                    ctx.Sender.Tell("ok", ctx.Self))
            this.Receive<string[]>(fun (msg: string[]) ->
                if msg.Length > 0 && String.Equals(msg.[0], "healthcheck", StringComparison.OrdinalIgnoreCase) then
                    let ctx = this.ActorCtx
                    ctx.Sender.Tell("ok", ctx.Self))

        member _.ActorCtx: IActorContext = ActorBase.Context

    type ReadySenderActor(selection: ActorSelection, ready: ProcNodeReady, interval: TimeSpan) as this =
        inherit ReceiveActor()

        let mutable schedule: ICancelable option = None

        do
            this.Receive<ProcNodeReady>(fun msg -> selection.Tell(msg))

        override _.PreStart() =
            let initial = TimeSpan.Zero
            let ctx = this.ActorCtx
            schedule <-
                Some(ctx.System.Scheduler.ScheduleTellRepeatedlyCancelable(initial, interval, ctx.Self, ready, ctx.Self))

        override _.PostStop() =
            schedule |> Option.iter (fun c -> c.Cancel())

        member _.ActorCtx: IActorContext = ActorBase.Context

    let private startSupervisor (args: ParseResults<ProcCliArgs>) =
        let config = loadConfig args
        let settings = ProcSettingsReader.load(Some config)
        let systemName = args.TryGetResult(<@ SystemName @>) |> Option.defaultValue settings.systemName
        let webHost = args.TryGetResult(<@ WebHost @>) |> Option.defaultValue settings.web.host
        let webPort = args.TryGetResult(<@ WebPort @>) |> Option.defaultValue settings.web.port
        let settings = { settings with systemName = systemName; web = { host = webHost; port = webPort } }

        use system = ActorSystem.Create(systemName, config)
        dumpSerializationState "supervisor" system
        joinCluster system (args.TryGetResult(<@ Seed @>) |> Option.defaultValue [])

        let registry = system.ActorOf(Props.Create(fun () -> ProcRegistryActor()), "proc-registry")
        let quartz = system.ActorOf(Props.Create(fun () -> QuartzActor()), "proc-quartz")

        let shardSettings =
            let baseSettings =
                ClusterShardingSettings.Create(system)
                    .WithStateStoreMode(StateStoreMode.DData)
            let baseSettings =
                ClusterShardingSettings(
                    baseSettings.Role,
                    baseSettings.RememberEntities,
                    baseSettings.JournalPluginId,
                    baseSettings.SnapshotPluginId,
                    TimeSpan.Zero,
                    baseSettings.StateStoreMode,
                    baseSettings.RememberEntitiesStore,
                    baseSettings.ShardRegionQueryTimeout,
                    baseSettings.TuningParameters,
                    baseSettings.CoordinatorSingletonSettings,
                    baseSettings.LeaseSettings
                )
            match settings.sharding.role with
            | Some role -> baseSettings.WithRole(role)
            | None -> baseSettings

        let extractor = ProcMessageExtractor(settings.sharding.numberOfShards)
        let region =
            ClusterSharding.Get(system).Start(
                settings.sharding.typeName,
                Props.Create(fun () -> ProcNodeActor(settings, registry, Some quartz)),
                shardSettings,
                extractor)

        let supervisor = system.ActorOf(Props.Create(fun () -> ProcSupervisorActor(region, registry)), "proc-supervisor")
        let health = system.ActorOf(Props.Create(fun () -> HealthActor()), "proc-health")
        let webParts = ProcRest.createWebParts system supervisor settings
        let _server =
            WebSocketServer.start
                system
                "proc"
                (Some(fun _ -> [ webParts ]))
                (Choice2Of2(webHost, webPort))
                (fun _ _ -> Some health)

        let cluster = Cluster.Get(system)
        let supervisorPath = supervisor.Path.ToStringWithAddress(cluster.SelfAddress)

        let spawnMode =
            if args.Contains(<@ SpawnNone @>) then
                None
            elif args.Contains(<@ Spawn @>) then
                Some "custom"
            elif args.Contains(<@ SpawnDefault @>) then
                Some "default"
            else
                Some "default"

        spawnMode
        |> Option.iter (fun mode ->
            let procId =
                args.TryGetResult(<@ ProcId @>)
                |> Option.defaultValue(Guid.NewGuid().ToString("N"))
            let probeMessage =
                args.TryGetResult(<@ Probe @>)
            let probeCron =
                args.TryGetResult(<@ ProbeCron @>)
                |> Option.orElse (args.TryGetResult(<@ ScheduleQ @>))
            let probeIntervalMs =
                args.TryGetResult(<@ ProbeIntervalMs @>)
            let spec: ProcStartSpec =
                if mode = "custom" then
                    let fileName = args.GetResult(<@ Spawn @>)
                    let spawnArgs = args.TryGetResult(<@ SpawnArg @>) |> Option.defaultValue []
                    let workingDir = args.TryGetResult(<@ SpawnWorkDir @>)
                    { procId = procId
                      fileName = fileName
                      args = spawnArgs
                      workingDir = workingDir
                      role = None
                      probeMessage = probeMessage
                      probeCron = probeCron
                      probeIntervalMs = probeIntervalMs }
                else
                    let procNodeRoles =
                        args.TryGetResult(<@ ProcNodeRole @>)
                        |> Option.defaultValue (settings.sharding.role |> Option.toList)
                    let seedArgs =
                        args.TryGetResult(<@ Seed @>)
                        |> Option.defaultValue [ cluster.SelfAddress.ToString() ]
                    let hostArg =
                        let hostValue =
                            if config.HasPath("akka.remote.dot-netty.tcp.hostname") then
                                config.GetString("akka.remote.dot-netty.tcp.hostname")
                            else
                                "127.0.0.1"
                        hostValue
                    let portArg =
                        let portValue = getFreePort ()
                        portValue
                    ProcStartSpecBuilder.buildManagedProcNodeSpec procId supervisorPath systemName seedArgs hostArg portArg procNodeRoles probeMessage probeCron probeIntervalMs
            supervisor.Tell({ procId = procId; spec = spec } : StartProc))

        system.WhenTerminated.Wait()
        0

    let private startProcNode (args: ParseResults<ProcCliArgs>) =
        let config = loadConfig args
        let settings = ProcSettingsReader.load(Some config)
        let systemName = args.TryGetResult(<@ SystemName @>) |> Option.defaultValue settings.systemName

        use system = ActorSystem.Create(systemName, config)
        dumpSerializationState "procnode" system
        joinCluster system (args.TryGetResult(<@ Seed @>) |> Option.defaultValue [])

        let supervisorOpt = args.TryGetResult(<@ Supervisor @>)
        let procId = args.TryGetResult(<@ ProcId @>) |> Option.defaultValue(Guid.NewGuid().ToString("N"))

        let fsiSupervisor = AkkaFsiBootstrap.EnsureSupervisor system
        let cluster = Cluster.Get(system)
        let fsiPath = fsiSupervisor.Path.ToStringWithAddress(cluster.SelfAddress)
        let _ =
            let timeout = TimeSpan.FromSeconds(2.0)
            let mutable attempt = 0
            let maxAttempts = 10
            let mutable readyOk = false
            while not readyOk && attempt < maxAttempts do
                attempt <- attempt + 1
                try
                    fsiSupervisor.Ask<Sessions>({ all = true }, timeout).Wait()
                    readyOk <- true
                with _ ->
                    Thread.Sleep 200
            readyOk
        let ready =
            { procId = procId
              pid = Process.GetCurrentProcess().Id
              fsiSupervisorPath = fsiPath
              nodeAddress = cluster.SelfAddress.ToString() }

        supervisorOpt
        |> Option.iter (fun address ->
            let selection = system.ActorSelection(address)
            let interval = TimeSpan.FromSeconds 1.0
            system.ActorOf(Props.Create(fun () -> ReadySenderActor(selection, ready, interval)), "proc-ready-sender")
            |> ignore)

        system.WhenTerminated.Wait()
        0

    [<EntryPoint>]
    let main argv =
        let parser = ArgumentParser.Create<ProcCliArgs>(programName = "proc-supervisor")
        let args = parser.ParseCommandLine argv
        match resolveMode args with
        | HostMode.Supervisor -> startSupervisor args
        | HostMode.ProcNode -> startProcNode args
