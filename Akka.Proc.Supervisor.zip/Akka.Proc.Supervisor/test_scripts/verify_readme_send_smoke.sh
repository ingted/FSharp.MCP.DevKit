#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
OUT=/tmp/proc_readme_send_smoke.out
ERR=/tmp/proc_readme_send_smoke.err
rm -f "$OUT" "$ERR"

PROC_DLL="$ROOT/Libs/Akka.Proc.Supervisor/bin/Debug/net10.0/Akka.Proc.Supervisor.dll"
RUNTIME="$ROOT/Libs/Akka.Proc.Supervisor/bin/Debug/net10.0/Akka.Proc.Supervisor.runtimeconfig.json"
DEPS="$ROOT/Libs/Akka.Proc.Supervisor/bin/Debug/net10.0/Akka.Proc.Supervisor.deps.json"
PORT=5011
WEBPORT=6011
SYS=proc-readme-smoke

dotnet exec --runtimeconfig "$RUNTIME" --depsfile "$DEPS" "$PROC_DLL" \
  --mode supervisor --systemname "$SYS" --host 127.0.0.1 --port "$PORT" \
  --webhost 127.0.0.1 --webport "$WEBPORT" --spawnnone >"$OUT" 2>"$ERR" &
PID=$!

cleanup() {
  kill $PID >/dev/null 2>&1 || true
  wait $PID >/dev/null 2>&1 || true
}
trap cleanup EXIT

for i in $(seq 1 60); do
  if curl -fsS "http://127.0.0.1:${WEBPORT}/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
  if ! kill -0 $PID >/dev/null 2>&1; then
    echo "supervisor exited"
    cat "$OUT"
    echo '---ERR---'
    cat "$ERR"
    exit 1
  fi
  if [ "$i" = 60 ]; then
    echo "health timeout"
    cat "$OUT"
    echo '---ERR---'
    cat "$ERR"
    exit 1
  fi
done

START=$(curl -fsS -X POST "http://127.0.0.1:${WEBPORT}/api/proc/nodes/start-default" -H 'Content-Type: application/json' -d '{"procId":"demo-node-01"}')
sleep 3
NODES=$(curl -fsS "http://127.0.0.1:${WEBPORT}/api/proc/nodes")
SEND=$(curl -fsS -X POST "http://127.0.0.1:${WEBPORT}/api/proc/nodes/demo-node-01/send" -H 'Content-Type: application/json' -d '{"message":"exec --session mysession --code \"let add a b = a + b\\nadd 5 7\"","timeoutMs":30000}')
STOP=$(curl -fsS -X POST "http://127.0.0.1:${WEBPORT}/api/proc/nodes/demo-node-01/stop" -H 'Content-Type: application/json' -d '{"force":true}')

printf 'START=%s\nNODES=%s\nSEND=%s\nSTOP=%s\n' "$START" "$NODES" "$SEND" "$STOP"

if ! printf '%s' "$SEND" | grep -q '"ok":true'; then
  echo "send did not succeed"
  exit 1
fi

if ! printf '%s' "$SEND" | grep -q '"resultJson":"12"'; then
  echo "unexpected send result"
  exit 1
fi
