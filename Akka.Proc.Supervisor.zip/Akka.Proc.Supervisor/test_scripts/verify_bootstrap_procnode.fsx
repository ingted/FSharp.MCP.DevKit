open System
open System.Diagnostics
open System.IO
open System.Net
open System.Net.Http
open System.Net.Sockets
open System.Text.Json
open System.Threading.Tasks

let getFreePort () =
    use listener = new TcpListener(IPAddress.Loopback, 0)
    listener.Start()
    let port = (listener.LocalEndpoint :?> IPEndPoint).Port
    listener.Stop()
    port

let http = new HttpClient(Timeout = TimeSpan.FromSeconds 5.0)

let poll (label: string) (timeout: TimeSpan) (work: unit -> Task<'T option>) =
    task {
        let started = DateTime.UtcNow
        let mutable result = None

        while result.IsNone && DateTime.UtcNow - started < timeout do
            let! next = work ()
            result <- next

            if result.IsNone then
                do! Task.Delay 500

        return
            result
            |> Option.defaultWith (fun () -> failwith $"{label} did not complete within {timeout}.")
    }

let procProjectDir = Path.GetFullPath(Path.Combine(__SOURCE_DIRECTORY__, ".."))
let repoRoot = Path.GetFullPath(Path.Combine(procProjectDir, "..", ".."))
let procProjectPath = Path.Combine(procProjectDir, "Akka.Proc.Supervisor.fsproj")
let outputDir = Path.Combine(procProjectDir, "bin", "Debug", "net10.0")
let procDll = Path.Combine(outputDir, "Akka.Proc.Supervisor.dll")
let runtimeConfig = Path.Combine(outputDir, "Akka.Proc.Supervisor.runtimeconfig.json")
let depsFile = Path.Combine(outputDir, "Akka.Proc.Supervisor.deps.json")

let buildPsi = ProcessStartInfo()
buildPsi.FileName <- "dotnet"
buildPsi.WorkingDirectory <- repoRoot
buildPsi.ArgumentList.Add("build")
buildPsi.ArgumentList.Add(procProjectPath)
buildPsi.ArgumentList.Add("-c")
buildPsi.ArgumentList.Add("Debug")
buildPsi.ArgumentList.Add("-f")
buildPsi.ArgumentList.Add("net10.0")
buildPsi.ArgumentList.Add("-m:1")
buildPsi.RedirectStandardOutput <- true
buildPsi.RedirectStandardError <- true
buildPsi.UseShellExecute <- false

let buildProc = Process.Start(buildPsi)
let buildOut = buildProc.StandardOutput.ReadToEnd()
let buildErr = buildProc.StandardError.ReadToEnd()
buildProc.WaitForExit()

if buildProc.ExitCode <> 0 then
    failwith $"dotnet build failed.%s{Environment.NewLine}%s{buildOut}%s{Environment.NewLine}%s{buildErr}"

let procHost = "127.0.0.1"
let procPort = getFreePort ()
let webPort = getFreePort ()
let systemSuffix = Guid.NewGuid().ToString("N").Substring(0, 8)
let procSuffix = Guid.NewGuid().ToString("N").Substring(0, 8)
let systemName = $"proc-system-{systemSuffix}"
let procId = $"bootstrap-{procSuffix}"
let seedAddress = $"akka.tcp://{systemName}@{procHost}:{procPort}"

let startPsi = ProcessStartInfo()
startPsi.FileName <- "dotnet"
startPsi.WorkingDirectory <- outputDir
startPsi.ArgumentList.Add("exec")
startPsi.ArgumentList.Add("--runtimeconfig")
startPsi.ArgumentList.Add(runtimeConfig)
startPsi.ArgumentList.Add("--depsfile")
startPsi.ArgumentList.Add(depsFile)
startPsi.ArgumentList.Add(procDll)
startPsi.ArgumentList.Add("--mode")
startPsi.ArgumentList.Add("supervisor")
startPsi.ArgumentList.Add("--systemname")
startPsi.ArgumentList.Add(systemName)
startPsi.ArgumentList.Add("--host")
startPsi.ArgumentList.Add(procHost)
startPsi.ArgumentList.Add("--port")
startPsi.ArgumentList.Add(string procPort)
startPsi.ArgumentList.Add("--webhost")
startPsi.ArgumentList.Add(procHost)
startPsi.ArgumentList.Add("--webport")
startPsi.ArgumentList.Add(string webPort)
startPsi.ArgumentList.Add("--seed")
startPsi.ArgumentList.Add(seedAddress)
startPsi.ArgumentList.Add("--spawndefault")
startPsi.ArgumentList.Add("--procid")
startPsi.ArgumentList.Add(procId)
startPsi.RedirectStandardOutput <- true
startPsi.RedirectStandardError <- true
startPsi.UseShellExecute <- false

let proc = Process.Start(startPsi)
let stdout = System.Collections.Concurrent.ConcurrentQueue<string>()
let stderr = System.Collections.Concurrent.ConcurrentQueue<string>()
proc.OutputDataReceived.Add(fun args -> if not (isNull args.Data) then stdout.Enqueue args.Data)
proc.ErrorDataReceived.Add(fun args -> if not (isNull args.Data) then stderr.Enqueue args.Data)
proc.BeginOutputReadLine()
proc.BeginErrorReadLine()

let dumpOutput () =
    let lines =
        seq {
            while not stdout.IsEmpty do
                match stdout.TryDequeue() with
                | true, line -> yield $"stdout> {line}"
                | _ -> ()

            while not stderr.IsEmpty do
                match stderr.TryDequeue() with
                | true, line -> yield $"stderr> {line}"
                | _ -> ()
        }
        |> String.concat Environment.NewLine

    if not (String.IsNullOrWhiteSpace lines) then
        printfn "%s" lines

let readString (url: string) =
    task {
        try
            let! text = http.GetStringAsync(url)
            return Some text
        with _ ->
            return None
    }

let nodesContainProcId (json: string) =
    try
        use doc = JsonDocument.Parse(json)
        doc.RootElement.ValueKind = JsonValueKind.Array
        && doc.RootElement.EnumerateArray()
           |> Seq.exists (fun item ->
               let mutable procIdValue = Unchecked.defaultof<JsonElement>
               item.TryGetProperty("procId", &procIdValue)
               && String.Equals(procIdValue.GetString(), procId, StringComparison.OrdinalIgnoreCase))
    with _ ->
        false

let cleanup () =
    if not proc.HasExited then
        try
            proc.Kill(true)
            proc.WaitForExit(5000) |> ignore
        with _ ->
            ()

    dumpOutput ()

let run () =
    try
        poll "ProcSupervisor health" (TimeSpan.FromSeconds 20.0) (fun () -> readString $"http://{procHost}:{webPort}/health")
        |> fun t -> t.GetAwaiter().GetResult() |> ignore

        let nodesJson =
            poll "bootstrap procnode registration" (TimeSpan.FromSeconds 30.0) (fun () ->
                task {
                    let! json = readString $"http://{procHost}:{webPort}/api/proc/nodes"
                    return json |> Option.filter nodesContainProcId
                })
            |> fun t -> t.GetAwaiter().GetResult()

        let clusterInfo =
            readString $"http://{procHost}:{webPort}/api/cluster/info"
            |> fun t -> t.GetAwaiter().GetResult()
            |> Option.defaultValue "<cluster info unavailable>"

        printfn "PASS"
        printfn "clusterInfo=%s" clusterInfo
        printfn "nodes=%s" nodesJson
        cleanup ()
    with ex ->
        cleanup ()
        failwith $"Bootstrap procnode verification failed: {ex.Message}"

run ()
