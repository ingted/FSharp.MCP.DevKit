namespace Akka.Proc.Supervisor

open System
open System.IO
open System.Reflection
open Akka.FSI.Contracts

[<CLIMutable>]
type ProcStartSpec =
    { procId: string
      fileName: string
      args: string list
      workingDir: string option
      role: string option
      probeMessage: string option
      probeCron: string option
      probeIntervalMs: int option }

    interface IMessage

[<CLIMutable>]
type ProcNodeReady =
    { procId: string
      pid: int
      fsiSupervisorPath: string
      nodeAddress: string }

    interface IMessage

[<CLIMutable>]
type ProcSnapshot =
    { procId: string
      status: string
      pid: int option
      fsiSupervisorPath: string option
      nodeAddress: string option
      lastProbeUtc: DateTime option
      lastProbeOk: bool option
      probeFailures: int
      spec: ProcStartSpec option
      lastError: string option }

    interface IMessage

[<CLIMutable>]
type StartProc =
    { procId: string
      spec: ProcStartSpec }

    interface IMessage

[<CLIMutable>]
type StopProc =
    { procId: string
      force: bool }

    interface IMessage

[<CLIMutable>]
type UpdateProbe =
    { procId: string
      probeMessage: string option
      probeCron: string option
      probeIntervalMs: int option }

    interface IMessage

[<CLIMutable>]
type ForwardMessage =
    { procId: string
      message: string }

    interface IMessage

[<CLIMutable>]
type GetProcInfo =
    { procId: string }

    interface IMessage

type GetAllProcInfo =
    | GetAllProcInfo

    interface IMessage

/// Design: keep stopped proc nodes until supervisor explicitly clears them.
type CleanStoppedProcNodes =
    | CleanStoppedProcNodes

    interface IMessage

[<CLIMutable>]
type ProcEnvelope =
    { entityId: string
      payload: obj }

    interface IMessage

module ProcStartSpecBuilder =
    type ManagedProcNodeLaunch =
        { DllPath: string
          RuntimeConfigPath: string option
          DepsFilePath: string option
          WorkingDirectory: string option }

    let private tryResolveSidecarPath (assemblyPath: string) (suffix: string) =
        if String.IsNullOrWhiteSpace assemblyPath then
            None
        else
            let directory = Path.GetDirectoryName assemblyPath
            let baseName = Path.GetFileNameWithoutExtension assemblyPath
            let candidate = Path.Combine(directory, $"{baseName}.{suffix}")
            if File.Exists candidate then Some candidate else None

    let private resolveManagedProcNodeLaunch () =
        let executingAssemblyPath = Assembly.GetExecutingAssembly().Location
        let entryAssemblyPath =
            Assembly.GetEntryAssembly()
            |> Option.ofObj
            |> Option.map (fun asm -> asm.Location)
            |> Option.filter (fun path -> not (String.IsNullOrWhiteSpace path))

        let runtimeConfigPath =
            [ entryAssemblyPath |> Option.bind (fun path -> tryResolveSidecarPath path "runtimeconfig.json")
              tryResolveSidecarPath executingAssemblyPath "runtimeconfig.json" ]
            |> List.tryPick id

        let depsFilePath =
            [ entryAssemblyPath |> Option.bind (fun path -> tryResolveSidecarPath path "deps.json")
              tryResolveSidecarPath executingAssemblyPath "deps.json" ]
            |> List.tryPick id

        { DllPath = executingAssemblyPath
          RuntimeConfigPath = runtimeConfigPath
          DepsFilePath = depsFilePath
          WorkingDirectory = Path.GetDirectoryName(executingAssemblyPath) |> Option.ofObj }

    let buildManagedProcNodeSpec
        (procId: string)
        (supervisorPath: string)
        (systemName: string)
        (seedNodes: string list)
        (hostValue: string)
        (portValue: int)
        (procNodeRoles: string list)
        (probeMessage: string option)
        (probeCron: string option)
        (probeIntervalMs: int option)
        =
        let launch = resolveManagedProcNodeLaunch ()
        let seedArgs = seedNodes |> List.collect (fun s -> [ "--seed"; s ])
        let roleArgs = procNodeRoles |> List.collect (fun r -> [ "--role"; r ])
        let roleLabel =
            match procNodeRoles with
            | [] -> None
            | roles -> Some(String.Join(",", roles))

        let baseArgs =
            [ match launch.RuntimeConfigPath with
              | Some runtimeConfigPath ->
                  yield "exec"
                  yield "--runtimeconfig"
                  yield runtimeConfigPath
              | None -> ()
              match launch.DepsFilePath with
              | Some depsFilePath ->
                  yield "--depsfile"
                  yield depsFilePath
              | None -> ()
              yield launch.DllPath
              yield "--mode"
              yield "procnode"
              yield "--procid"
              yield procId
              yield "--supervisor"
              yield supervisorPath
              yield "--systemname"
              yield systemName
              yield "--host"
              yield hostValue
              yield "--port"
              yield string portValue ]
            @ seedArgs
            @ roleArgs

        { procId = procId
          fileName = "dotnet"
          args = baseArgs
          workingDir = launch.WorkingDirectory
          role = roleLabel
          probeMessage = probeMessage
          probeCron = probeCron
          probeIntervalMs = probeIntervalMs }
