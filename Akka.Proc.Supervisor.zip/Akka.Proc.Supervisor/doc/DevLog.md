# DevLog.md

## 2026-03-25 - 導入 FsPickler remoting contracts，修復 direct ask 掉成 JObject

### Context

- `ProcSupervisor` 新增 `GetVesion` 後，本地 actor ask 可過，但跨 `Akka.Remote` ask timeout。
- 最小重現確認：
  - actor path 正常
  - port 正常
  - remote 端收到的是 `JObject`

### Technical Decisions

1. 不再對新的 command surface 追加 `JObject` workaround
2. 改在 shared contracts package 裡提供正式 serializer
3. serializer registration 走 startup HOCON，而不是只靠 runtime install

### Resolutions

- `FAkka.Fsi.Contracts` 新增 `ContractSerializer`
- `ProcContracts` 跨 wire message 加上 `IMessage`
- `ProcHost` 啟動時注入 shared serializer/binding config
- `Akka.Proc.Supervisor.Tests` 補 remote `GetVesion` / `GetAllProcInfo`

### Verification

- `dotnet test Libs/Akka.Proc.Supervisor.Tests/Akka.Proc.Supervisor.Tests.fsproj -c Debug -m:1`
- 結果：`9 passed, 0 failed`

### Follow-up

- 發佈新版 `FAkka.Proc.Supervisor`
- `FSharp.MCP.DevKit` 升級新版 package 後再驗 host/session 隔離

## 2026-03-26 - README 補齊 `--mode`、probe 與 `StartProc` timeout recovery 說明

### Context

- 文件先前只說了 `start-default` / `send` 的基本用法，沒有把下列容易誤解的點寫清楚：
  - `--mode` 只對 `Akka.Proc.Supervisor.dll` 自己有意義，不是 generic supervisee contract
  - `probeMessage` / `probeIntervalMs` 其實依賴 `fsiSupervisorPath` 與 `ProcMessageParser`
  - 上層 orchestration 在 `StartProc` ask timeout 時，常會改用 `GetProcInfo` 做短時間補收斂

### Resolutions

- 在 `README.md` 補上：
  - 自訂 `.NET dll` / Python supervisee 不應使用 `--mode`
  - `probeMessage` 僅適用於 `procnode + Akka.FSI.Supervisor`
  - 推薦 probe 範例使用 `listsessions --all true`
  - `StartProc` ask timeout 不一定等於建立失敗；應短時間輪詢 `GetProcInfo(procId)`

### Rationale

- 這些點若不寫明，呼叫端很容易把：
  - generic process lifecycle
  - FSI-specific forwarding
  - provisioning timeout recovery
  混成同一件事，之後排錯成本會持續偏高。

## 2026-03-30 - 追版 FAKka.FSI.Supervisor session cache 修正

### 變更
- `FAkka.Proc.Supervisor` release 依賴的 `FAkka.FSI.Supervisor` 由 `1.562.101.201-dgx.16` 升至 `1.562.101.201-dgx.17`。
- package 版本同步由 `1.562.101.201-dgx.20` 升至 `1.562.101.201-dgx.21`。

### 理由
- 讓 deployment 鏈在建立 procnode / fsi supervisor 後，可以吃到本輪 `ListSessions/GetSessionInfo` control-plane cache 修正。

## 2026-03-30 - 發布 `FAkka.Proc.Supervisor 1.562.101.201-dgx.21`

### 過程
- 正式 feed 一開始尚未看到 `FAkka.FSI.Supervisor dgx.17`，因此 `Release` restore 先失敗於 `NU1102`。
- 為了不修改 repo 的正式 `nuget.config`，本輪只在本地建置時額外指定 `FAkka.FSI.Supervisor/bin/Release` 作為 restore source。
- 之後 `Akka.Proc.Supervisor` Release build 成功，且 Post-Build `dotnet nuget push` 已成功發布：
  - `FAkka.Proc.Supervisor 1.562.101.201-dgx.21`

### 結果
- `dgx.21` 現已在 NuGet 上存在，但正式 flat container/restore graph 仍可能短暫 lag。
- 這不影響 package 本身已發布，只影響上游 `FSharp.MCP.DevKit` 何時能只靠正式 feed restore。
