namespace Akka.Proc.Supervisor

open System
open System.IO
open System.Net
open System.Net.Sockets
open System.Text
open Akka.Actor
open Akka.Cluster
open Suave
open Suave.Filters
open Suave.Operators
open Suave.Successful
open Suave.RequestErrors
open Suave.ServerErrors
open Akka.FSI.Contracts

[<CLIMutable>]
type StartProcRequest =
    { procId: string
      fileName: string
      args: string list
      workingDir: string option
      role: string option
      probeMessage: string option
      probeCron: string option
      probeIntervalMs: int option }

[<CLIMutable>]
type StopProcRequest =
    { force: bool option }

[<CLIMutable>]
type SendMessageRequest =
    { message: string
      timeoutMs: int option }

[<CLIMutable>]
type UpdateProbeRequest =
    { probeMessage: string option
      probeCron: string option
      probeIntervalMs: int option }

[<CLIMutable>]
type StartDefaultProcRequest =
    { procId: string option }

[<CLIMutable>]
type ClusterInfo =
    { systemName: string
      address: string
      roles: string list }

module ProcRest =
    let private getFreePort () =
        use listener = new TcpListener(IPAddress.Any, 0)
        listener.Start()
        let port = (listener.LocalEndpoint :?> IPEndPoint).Port
        listener.Stop()
        port

    let private jsonOk (payload: obj) =
        let json = JsonCodec.serializeObj payload
        OK json >=> Writers.setMimeType "application/json; charset=utf-8"

    let private jsonError (message: string) =
        let payload = {| error = message |}
        let json = JsonCodec.serialize payload
        BAD_REQUEST json >=> Writers.setMimeType "application/json; charset=utf-8"

    let private readBody (ctx: HttpContext) =
        Encoding.UTF8.GetString ctx.request.rawForm

    let private parseBody<'T> (ctx: HttpContext) =
        try
            readBody ctx |> JsonCodec.deserialize<'T> |> Result.Ok
        with ex ->
            Result.Error ex.Message

    let private ask<'T> (actor: IActorRef) (msg: obj) (timeout: TimeSpan) =
        actor.Ask<'T>(msg, timeout) |> Async.AwaitTask

    let createWebParts (system: ActorSystem) (supervisor: IActorRef) (settings: ProcSupervisorSettings) =
        let cluster = Cluster.Get(system)
        let config = system.Settings.Config
        let info =
            { systemName = system.Name
              address = cluster.SelfAddress.ToString()
              roles = cluster.SelfRoles |> Seq.toList }

        let buildDefaultSpec (procId: string) : ProcStartSpec =
            let supervisorPath = supervisor.Path.ToStringWithAddress(cluster.SelfAddress)
            let hostValue =
                if config.HasPath("akka.remote.dot-netty.tcp.hostname") then
                    config.GetString("akka.remote.dot-netty.tcp.hostname")
                else
                    if String.IsNullOrWhiteSpace(cluster.SelfAddress.Host) then
                        "127.0.0.1"
                    else
                        cluster.SelfAddress.Host
            let portValue = getFreePort ()
            let seedNodes =
                if config.HasPath("akka.cluster.seed-nodes") then
                    config.GetStringList("akka.cluster.seed-nodes") |> Seq.toList
                else
                    [ cluster.SelfAddress.ToString() ]
            let seedArgs =
                seedNodes |> List.collect (fun s -> [ "--seed"; s ])
            let roles = settings.sharding.role |> Option.toList
            ProcStartSpecBuilder.buildManagedProcNodeSpec procId supervisorPath system.Name seedNodes hostValue portValue roles None None None

        let healthHandler =
            fun ctx ->
                async {
                    try
                        let selection = system.ActorSelection("/user/proc-health")
                        let! reply =
                            selection.Ask<string>("healthcheck", TimeSpan.FromSeconds(2.0))
                            |> Async.AwaitTask
                        return! OK reply ctx
                    with ex ->
                        return! INTERNAL_ERROR ex.Message ctx
                }

        choose
            [ path "/api/cluster/info" >=> GET >=> jsonOk info
              path "/health" >=> GET >=> healthHandler
              path "/healthcheck" >=> GET >=> healthHandler
              path "/api/cluster/shutdown"
              >=> POST
              >=> fun ctx ->
                  async {
                      // Design: proc supervisor is a sharded failover unit; shutdown first stops all proc nodes
                      // gracefully, then force-kills any unresponsive processes.
                      try
                          let! snapshots = ask<ProcSnapshot[]> supervisor GetAllProcInfo (TimeSpan.FromSeconds(5.0))
                          let running =
                              snapshots
                              |> Array.filter (fun s -> not (String.Equals(s.status, "stopped", StringComparison.OrdinalIgnoreCase)))
                              |> Array.map (fun s -> s.procId)
                              |> Array.toList

                          for procId in running do
                              let stopMsg: StopProc = { procId = procId; force = false }
                              let! _ = ask<ProcSnapshot> supervisor stopMsg (TimeSpan.FromSeconds(5.0))
                              ()

                          do! Async.Sleep(1500)

                          let! after = ask<ProcSnapshot[]> supervisor GetAllProcInfo (TimeSpan.FromSeconds(5.0))
                          let stillRunning =
                              after
                              |> Array.filter (fun s -> not (String.Equals(s.status, "stopped", StringComparison.OrdinalIgnoreCase)))
                              |> Array.map (fun s -> s.procId)
                              |> Array.toList

                          for procId in stillRunning do
                              let stopMsg: StopProc = { procId = procId; force = true }
                              let! _ = ask<ProcSnapshot> supervisor stopMsg (TimeSpan.FromSeconds(5.0))
                              ()
                      with _ ->
                          ()
                      system.Terminate() |> ignore
                      return! jsonOk {| status = "terminating" |} ctx
                  }
              path "/api/proc/nodes"
              >=> GET
              >=> fun ctx ->
                  async {
                      try
                          let! snapshots = ask<ProcSnapshot[]> supervisor GetAllProcInfo (TimeSpan.FromSeconds(3.0))
                          return! jsonOk snapshots ctx
                      with ex ->
                          return! jsonError ex.Message ctx
                  }
              path "/api/proc/nodes/start"
              >=> POST
              >=> fun ctx ->
                  async {
                      match parseBody<StartProcRequest> ctx with
                      | Result.Error err ->
                          return! jsonError err ctx
                      | Result.Ok req ->
                          let args = if isNull (box req.args) then [] else req.args
                          let spec: ProcStartSpec =
                              { procId = req.procId
                                fileName = req.fileName
                                args = args
                                workingDir = req.workingDir
                                role = req.role
                                probeMessage = req.probeMessage
                                probeCron = req.probeCron
                                probeIntervalMs = req.probeIntervalMs }
                          let startMsg: StartProc = { procId = req.procId; spec = spec }
                          try
                              let! snapshot =
                                  ask<ProcSnapshot> supervisor startMsg (TimeSpan.FromSeconds(5.0))
                              return! jsonOk snapshot ctx
                          with ex ->
                              return! jsonError ex.Message ctx
                  }
              // Design: bootstrap a default proc node from supervisor for quick remote FSI startup.
              path "/api/proc/nodes/start-default"
              >=> POST
              >=> fun ctx ->
                  async {
                      let procId =
                          match parseBody<StartDefaultProcRequest> ctx with
                          | Result.Ok req -> req.procId |> Option.filter (fun v -> not (String.IsNullOrWhiteSpace v))
                          | Result.Error _ -> None
                          |> Option.defaultValue(Guid.NewGuid().ToString("N"))
                      let spec = buildDefaultSpec procId
                      let startMsg: StartProc = { procId = procId; spec = spec }
                      try
                          let! snapshot =
                              ask<ProcSnapshot> supervisor startMsg (TimeSpan.FromSeconds(5.0))
                          return! jsonOk snapshot ctx
                      with ex ->
                          return! jsonError ex.Message ctx
                  }
              path "/api/proc/nodes/clean-stopped"
              >=> POST
              >=> fun ctx ->
                  async {
                      // Design: keep stopped proc nodes for diagnostics; supervisor clears them explicitly.
                      try
                          let! removed = ask<int> supervisor CleanStoppedProcNodes (TimeSpan.FromSeconds(5.0))
                          return! jsonOk {| removed = removed |} ctx
                      with ex ->
                          return! jsonError ex.Message ctx
                  }
              pathScan "/api/proc/nodes/%s/stop" (fun procId ->
                  POST
                  >=> fun ctx ->
                      async {
                          let force =
                              match parseBody<StopProcRequest> ctx with
                              | Result.Ok req -> req.force |> Option.defaultValue true
                              | Result.Error _ -> true
                          let stopMsg: StopProc = { procId = procId; force = force }
                          try
                              let! _ = ask<obj> supervisor stopMsg (TimeSpan.FromSeconds(5.0))
                              return! jsonOk {| procId = procId; status = "stopped" |} ctx
                          with ex ->
                              return! jsonError ex.Message ctx
                      })
              pathScan "/api/proc/nodes/%s/probe" (fun procId ->
                  choose
                      [ GET
                        >=> fun ctx ->
                            async {
                                try
                                    let infoMsg: GetProcInfo = { procId = procId }
                                    let! snapshot = ask<ProcSnapshot> supervisor infoMsg (TimeSpan.FromSeconds(3.0))
                                    let probe =
                                        {| procId = procId
                                           probeMessage =
                                            snapshot.spec |> Option.bind (fun s -> s.probeMessage)
                                           probeCron =
                                            snapshot.spec |> Option.bind (fun s -> s.probeCron)
                                           probeIntervalMs =
                                            snapshot.spec |> Option.bind (fun s -> s.probeIntervalMs) |}
                                    return! jsonOk probe ctx
                                with ex ->
                                    return! jsonError ex.Message ctx
                            }
                        POST
                        >=> fun ctx ->
                            async {
                                match parseBody<UpdateProbeRequest> ctx with
                                | Result.Error err -> return! jsonError err ctx
                                | Result.Ok req ->
                                    let updateMsg: UpdateProbe =
                                        { procId = procId
                                          probeMessage = req.probeMessage
                                          probeCron = req.probeCron
                                          probeIntervalMs = req.probeIntervalMs }
                                    try
                                        let! snapshot = ask<ProcSnapshot> supervisor updateMsg (TimeSpan.FromSeconds(5.0))
                                        return! jsonOk snapshot ctx
                                    with ex ->
                                        return! jsonError ex.Message ctx
                            } ])
              pathScan "/api/proc/nodes/%s/sessions" (fun procId ->
                  GET
                  >=> fun ctx ->
                      async {
                          try
                              let forwardMsg: ForwardMessage = { procId = procId; message = "listsessions --all true" }
                              let! result = ask<obj> supervisor forwardMsg (TimeSpan.FromSeconds(10.0))
                              match result with
                              | :? Sessions as sessions -> return! jsonOk sessions ctx
                              | _ -> return! jsonOk result ctx
                          with ex ->
                              return! jsonError ex.Message ctx
                      })
              pathScan "/api/proc/nodes/%s/send" (fun procId ->
                  POST
                  >=> fun ctx ->
                      async {
                          match parseBody<SendMessageRequest> ctx with
                          | Result.Error err -> return! jsonError err ctx
                          | Result.Ok req ->
                              let timeout =
                                  req.timeoutMs
                                  |> Option.defaultValue settings.forwardTimeoutMs
                                  |> float
                                  |> TimeSpan.FromMilliseconds
                              let forwardMsg: ForwardMessage = { procId = procId; message = req.message }
                              try
                                  let! result = ask<obj> supervisor forwardMsg timeout
                                  match result with
                                  | :? ExecResult as execResult ->
                                      return! jsonOk execResult ctx
                                  | :? Status.Failure as failure ->
                                      return! jsonError failure.Cause.Message ctx
                                  | _ ->
                                      return! jsonOk result ctx
                              with ex ->
                                  return! jsonError ex.Message ctx
                      }) ]
