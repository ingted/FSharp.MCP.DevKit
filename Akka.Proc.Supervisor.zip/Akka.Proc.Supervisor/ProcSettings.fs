namespace Akka.Proc.Supervisor

open Akka.Configuration

[<CLIMutable>]
type ProcWebSettings =
    { host: string
      port: int }

[<CLIMutable>]
type ProcShardingSettings =
    { typeName: string
      role: string option
      numberOfShards: int }

[<CLIMutable>]
type ProcSupervisorSettings =
    { systemName: string
      probeIntervalMs: int
      probeTimeoutMs: int
      probeFailureThreshold: int
      restartDelayMs: int
      checkIntervalMs: int
      forwardTimeoutMs: int
      web: ProcWebSettings
      sharding: ProcShardingSettings }

    static member Default =
        { systemName = "proc-system"
          probeIntervalMs = 15000
          probeTimeoutMs = 5000
          probeFailureThreshold = 3
          restartDelayMs = 3000
          checkIntervalMs = 5000
          forwardTimeoutMs = 30000
          web = { host = "0.0.0.0"; port = 6001 }
          sharding = { typeName = "proc-node"; role = None; numberOfShards = 100 } }

module ProcSettingsReader =
    let private getString (cfg: Config) path fallback =
        if cfg.HasPath(path) then cfg.GetString(path) else fallback

    let private getInt (cfg: Config) path fallback =
        if cfg.HasPath(path) then cfg.GetInt(path) else fallback

    let private getOptionalString (cfg: Config) path =
        if cfg.HasPath(path) then Some(cfg.GetString(path)) else None

    let load (config: Config option) =
        let defaults = ProcSupervisorSettings.Default

        let root =
            match config with
            | Some cfg when cfg.HasPath("akka.proc") -> cfg.GetConfig("akka.proc")
            | _ -> null

        if isNull root then
            defaults
        else
            let webCfg =
                if root.HasPath("web") then root.GetConfig("web") else null

            let shardCfg =
                if root.HasPath("sharding") then root.GetConfig("sharding") else null

            let web =
                if isNull webCfg then
                    defaults.web
                else
                    { host = getString webCfg "host" defaults.web.host
                      port = getInt webCfg "port" defaults.web.port }

            let sharding =
                if isNull shardCfg then
                    defaults.sharding
                else
                    { typeName = getString shardCfg "type-name" defaults.sharding.typeName
                      role = getOptionalString shardCfg "role"
                      numberOfShards = getInt shardCfg "number-of-shards" defaults.sharding.numberOfShards }

            { systemName = getString root "system-name" defaults.systemName
              probeIntervalMs = getInt root "probe-interval-ms" defaults.probeIntervalMs
              probeTimeoutMs = getInt root "probe-timeout-ms" defaults.probeTimeoutMs
              probeFailureThreshold = getInt root "probe-failure-threshold" defaults.probeFailureThreshold
              restartDelayMs = getInt root "restart-delay-ms" defaults.restartDelayMs
              checkIntervalMs = getInt root "check-interval-ms" defaults.checkIntervalMs
              forwardTimeoutMs = getInt root "forward-timeout-ms" defaults.forwardTimeoutMs
              web = web
              sharding = sharding }
