namespace Akka.Proc.Supervisor

open System
open System.Diagnostics
open System.Text.RegularExpressions
open Akka.Actor
open Akka.Event
open Akka.Cluster
open Akka.Cluster.Sharding
open Akka.Quartz.Actor.Commands
open Quartz
open System.Threading.Tasks
open Akka.FSI.Contracts
open Akka.FSI.Supervisor

module ProcNodeBootstrapParser =
    let tryExtractNodeAddressFromStdout (line: string) =
        if String.IsNullOrWhiteSpace line then
            None
        else
            let matchResult = Regex.Match(line, @"akka\.tcp://[^ \]\r\n]+")
            if matchResult.Success then Some matchResult.Value else None

type RegistryCommand =
    | UpdateSnapshot of ProcSnapshot
    | RemoveSnapshot of string
    /// Design: keep stopped nodes until supervisor explicitly cleans them.
    | CleanStoppedSnapshots of IActorRef
    | GetSnapshots of IActorRef
    | GetSnapshot of string * IActorRef

type ProcRegistryActor() as this =
    inherit ReceiveActor()

    let snapshots = System.Collections.Generic.Dictionary<string, ProcSnapshot>(StringComparer.OrdinalIgnoreCase)

    let updateSnapshot (snapshot: ProcSnapshot) =
        snapshots[snapshot.procId] <- snapshot

    let removeSnapshot procId =
        snapshots.Remove(procId) |> ignore

    do
        this.Receive<RegistryCommand>(fun msg ->
            let ctx: IActorContext = this.ActorCtx
            match msg with
            | UpdateSnapshot snapshot -> updateSnapshot snapshot
            | RemoveSnapshot procId -> removeSnapshot procId
            | CleanStoppedSnapshots replyTo ->
                // Design: keep stopped nodes for diagnostics; supervisor clears them explicitly.
                let stopped =
                    snapshots
                    |> Seq.filter (fun kvp -> String.Equals(kvp.Value.status, "stopped", StringComparison.OrdinalIgnoreCase))
                    |> Seq.map (fun kvp -> kvp.Key)
                    |> Seq.toList
                for procId in stopped do
                    removeSnapshot procId
                replyTo.Tell(stopped.Length, ctx.Self)
            | GetSnapshots replyTo ->
                let payload = snapshots.Values |> Seq.toArray
                replyTo.Tell(payload, ctx.Self)
            | GetSnapshot (procId, replyTo) ->
                match snapshots.TryGetValue(procId) with
                | true, snapshot -> replyTo.Tell(Some snapshot, ctx.Self)
                | _ -> replyTo.Tell(None, ctx.Self))

    member _.ActorCtx: IActorContext = ActorBase.Context

type internal ProcInternal =
    | CheckProcess
    | ProbeTick
    | Restart
    | ProcessExited of int
    | ProbeResult of Result<obj, exn>
    | ChildNodeAddressDiscovered of string

type ProcNodeActor(settings: ProcSupervisorSettings, registry: IActorRef, quartz: IActorRef option) as this =
    inherit ReceiveActor()

    let actorCtx () : IActorContext = this.ActorCtx
    let log () = Logging.GetLogger(actorCtx ())
    let entityId () = actorCtx().Self.Path.Name
    let selfRef () = actorCtx().Self
    let mutable spec: ProcStartSpec option = None
    let mutable proc: Process option = None
    let mutable fsiSupervisorPath: string option = None
    let mutable nodeAddress: string option = None
    let mutable status = "idle"
    let mutable lastProbeUtc: DateTime option = None
    let mutable lastProbeOk: bool option = None
    let mutable probeFailures = 0
    let mutable lastError: string option = None
    let mutable checkSchedule: ICancelable option = None
    let mutable probeSchedule: ICancelable option = None
    let mutable probeJobKeys: (JobKey * TriggerKey) option = None

    let tryGetArg name (args: string list) =
        args
        |> List.tryFindIndex ((=) name)
        |> Option.bind (fun idx ->
            if idx + 1 < args.Length then Some args[idx + 1] else None)

    let tryGetArgAny names (args: string list) =
        names |> List.tryPick (fun name -> tryGetArg name args)

    let tryInferNodeInfo (spec: ProcStartSpec) =
        let systemName =
            tryGetArgAny [ "--systemname"; "--system-name" ] spec.args
        match systemName, tryGetArg "--host" spec.args, tryGetArg "--port" spec.args with
        | Some systemName, Some host, Some portText ->
            match Int32.TryParse portText with
            | true, port when port > 0 ->
                let address = $"akka.tcp://{systemName}@{host}:{port}"
                Some(address, $"{address}{AkkaFsiBootstrap.supervisorPath}")
            | _ -> None
        | _ -> None

    let buildSnapshot () =
        let pid =
            match proc with
            | Some p when not p.HasExited -> Some p.Id
            | _ -> None
        { procId = entityId ()
          status = status
          pid = pid
          fsiSupervisorPath = fsiSupervisorPath
          nodeAddress = nodeAddress
          lastProbeUtc = lastProbeUtc
          lastProbeOk = lastProbeOk
          probeFailures = probeFailures
          spec = spec
          lastError = lastError }

    let updateSnapshot () =
        let snapshot = buildSnapshot ()
        registry.Tell(UpdateSnapshot snapshot)

    let stopProcess (force: bool) =
        match proc with
        | Some p ->
            try
                if not p.HasExited then
                    if force then p.Kill(true) else p.Kill()
            with ex ->
                log().Warning("Failed to kill process {0}: {1}", entityId (), ex.Message)
            proc <- None
        | None -> ()
        status <- "stopped"
        fsiSupervisorPath <- None
        updateSnapshot ()

    let scheduleRestart () =
        let delay = TimeSpan.FromMilliseconds(float settings.restartDelayMs)
        actorCtx().System.Scheduler.ScheduleTellOnce(delay, selfRef (), ProcInternal.Restart, selfRef ()) |> ignore

    let startProcess (spec: ProcStartSpec) =
        try
            let procId = entityId ()
            let psi = ProcessStartInfo()
            psi.FileName <- spec.fileName
            psi.UseShellExecute <- false
            psi.CreateNoWindow <- true
            psi.RedirectStandardOutput <- true
            psi.RedirectStandardError <- true
            let workingDir =
                match spec.workingDir with
                | Some path when not (String.IsNullOrWhiteSpace path) -> path
                | _ -> Environment.CurrentDirectory
            psi.WorkingDirectory <- workingDir
            for arg in spec.args do
                psi.ArgumentList.Add(arg)

            log().Info("Starting process [{0}]: {1} {2}", procId, psi.FileName, String.Join(" ", psi.ArgumentList))
            let started = Process.Start(psi)
            if isNull started then
                status <- "failed"
                lastError <- Some "Process.Start returned null."
            else
                started.EnableRaisingEvents <- true
                let logger = log ()
                let self = selfRef ()
                started.OutputDataReceived.Add(fun args ->
                    if not (isNull args.Data) then
                        logger.Info("Proc {0} stdout: {1}", procId, args.Data)
                        match ProcNodeBootstrapParser.tryExtractNodeAddressFromStdout args.Data with
                        | Some address -> self.Tell(ChildNodeAddressDiscovered address)
                        | _ -> ())
                started.ErrorDataReceived.Add(fun args ->
                    if not (isNull args.Data) then
                        logger.Warning("Proc {0} stderr: {1}", procId, args.Data))
                started.Exited.Add(fun _ -> self.Tell(ProcessExited started.Id))
                started.BeginOutputReadLine()
                started.BeginErrorReadLine()
                proc <- Some started
                status <- "starting"
                lastError <- None
                if fsiSupervisorPath.IsNone then
                    match tryInferNodeInfo spec with
                    | Some(address, supervisorPath) ->
                        nodeAddress <- Some address
                        fsiSupervisorPath <- Some supervisorPath
                    | None -> ()
            updateSnapshot ()
        with ex ->
            status <- "failed"
            lastError <- Some ex.Message
            updateSnapshot ()

    let ensureCheckSchedule () =
        if checkSchedule.IsNone then
            let interval = TimeSpan.FromMilliseconds(float settings.checkIntervalMs)
            checkSchedule <- Some(actorCtx().System.Scheduler.ScheduleTellRepeatedlyCancelable(interval, interval, selfRef (), CheckProcess, selfRef ()))

    let clearProbeSchedule () =
        probeSchedule |> Option.iter (fun c -> c.Cancel())
        probeSchedule <- None
        probeJobKeys
        |> Option.iter (fun (jobKey, triggerKey) ->
            match quartz with
            | Some q -> q.Tell(RemoveJob(jobKey, triggerKey))
            | None -> ())
        probeJobKeys <- None

    let configureProbe (spec: ProcStartSpec) =
        clearProbeSchedule ()
        if spec.probeMessage.IsSome then
            match spec.probeCron, quartz with
            | Some cron, Some q ->
                let jobKey = JobKey("probe-" + entityId ())
                let triggerKey = TriggerKey("probe-" + entityId ())
                let trigger =
                    TriggerBuilder.Create()
                        .WithIdentity(triggerKey)
                        .ForJob(jobKey)
                        .WithCronSchedule(cron)
                        .Build()
                q.Tell(CreateJob(selfRef (), ProbeTick, trigger))
                probeJobKeys <- Some(jobKey, triggerKey)
            | _ ->
                let interval =
                    spec.probeIntervalMs
                    |> Option.defaultValue settings.probeIntervalMs
                    |> float
                    |> TimeSpan.FromMilliseconds
                probeSchedule <- Some(actorCtx().System.Scheduler.ScheduleTellRepeatedlyCancelable(interval, interval, selfRef (), ProbeTick, selfRef ()))

    let ensureProcess () =
        match spec with
        | None -> ()
        | Some currentSpec ->
            match proc with
            | Some p when not p.HasExited -> ()
            | _ ->
                startProcess currentSpec

    let applyProbeResult (result: Result<obj, exn>) =
        lastProbeUtc <- Some DateTime.UtcNow
        match result with
        | Error ex ->
            lastProbeOk <- Some false
            probeFailures <- probeFailures + 1
            lastError <- Some ex.Message
        | Ok payload ->
            match payload with
            | :? Status.Failure as failure ->
                lastProbeOk <- Some false
                probeFailures <- probeFailures + 1
                lastError <- Some failure.Cause.Message
            | :? ExecResult as execResult when not execResult.ok ->
                lastProbeOk <- Some false
                probeFailures <- probeFailures + 1
                lastError <- execResult.error |> Option.map (fun e -> e.message)
            | _ ->
                lastProbeOk <- Some true
                probeFailures <- 0
                lastError <- None
        updateSnapshot ()
        if probeFailures >= settings.probeFailureThreshold then
            log().Warning("Probe failed {0} times for {1}; restarting process.", probeFailures, entityId ())
            stopProcess true
            scheduleRestart ()

    let handleProbe () =
        let handleProbeFailure (error: string option) =
            lastProbeUtc <- Some DateTime.UtcNow
            lastProbeOk <- Some false
            lastError <- error
            probeFailures <- probeFailures + 1
            updateSnapshot ()
            if probeFailures >= settings.probeFailureThreshold then
                log().Warning("Probe failed {0} times for {1}; restarting process.", probeFailures, entityId ())
                stopProcess true
                scheduleRestart ()

        let markProbeMissing () =
            lastProbeUtc <- Some DateTime.UtcNow
            lastProbeOk <- Some false
            lastError <- Some "FSI supervisor not ready."
            updateSnapshot ()

        match spec with
        | None -> ()
        | Some currentSpec ->
            match currentSpec.probeMessage with
            | None -> ()
            | Some probeText ->
                match fsiSupervisorPath with
                | None ->
                    if status = "running" then
                        handleProbeFailure (Some "FSI supervisor not ready.")
                    else
                        markProbeMissing ()
                | Some targetPath ->
                    match ProcMessageParser.tryParse probeText with
                    | Error err ->
                        handleProbeFailure (Some err)
                    | Ok payload ->
                        let ctx = actorCtx ()
                        let selection = ctx.System.ActorSelection(targetPath)
                        let timeout = TimeSpan.FromMilliseconds(float settings.probeTimeoutMs)
                        let self = selfRef ()
                        let work: Task<obj> = selection.Ask(payload, timeout)
                        work.ContinueWith(fun (t: Task<obj>) ->
                            if t.IsFaulted then
                                let ex = t.Exception.GetBaseException()
                                self.Tell(ProbeResult(Result.Error ex))
                            else
                                self.Tell(ProbeResult(Result.Ok t.Result))) |> ignore

    // Design: ForwardMessage is routed by procId (sharding) to this proc node actor,
    // then forwarded to the FSI supervisor; session selection happens inside the supervisor via session name.
    let forwardToFsi (payload: obj) (senderRef: IActorRef) =
        match fsiSupervisorPath with
        | None ->
            senderRef.Tell(Status.Failure(Exception("FSI supervisor not ready.")), selfRef ())
        | Some targetPath ->
            log().Debug(sprintf "Forwarding to fsi supervisor: %A" payload)
            let selection = actorCtx().System.ActorSelection(targetPath)
            let timeout = TimeSpan.FromMilliseconds(float settings.forwardTimeoutMs)
            let selfSender = selfRef ()
            let work: Task<obj> = selection.Ask(payload, timeout)
            work.ContinueWith(fun (t: Task<obj>) ->
                    if t.IsFaulted then
                        senderRef.Tell(Status.Failure(t.Exception.GetBaseException()), selfSender)
                    else
                        senderRef.Tell(t.Result, selfSender)) |> ignore

    do
        this.Receive<StartProc>(fun msg ->
            spec <- Some msg.spec
            status <- "starting"
            lastError <- None
            updateSnapshot ()
            ensureCheckSchedule ()
            configureProbe msg.spec
            ensureProcess ()
            let ctx = actorCtx ()
            ctx.Sender.Tell(buildSnapshot (), ctx.Self))

        this.Receive<StopProc>(fun msg ->
            stopProcess msg.force
            spec <- None
            clearProbeSchedule ()
            updateSnapshot ()
            let ctx = actorCtx ()
            ctx.Sender.Tell(buildSnapshot (), ctx.Self))

        this.Receive<UpdateProbe>(fun msg ->
            spec <-
                spec
                |> Option.map (fun current ->
                    { current with
                        probeMessage = msg.probeMessage
                        probeCron = msg.probeCron
                        probeIntervalMs = msg.probeIntervalMs })
            spec |> Option.iter configureProbe
            updateSnapshot ()
            let ctx = actorCtx ()
            ctx.Sender.Tell(buildSnapshot (), ctx.Self))

        this.Receive<ForwardMessage>(fun (msg: ForwardMessage) ->
            log().Debug(sprintf "ForwardMessage received: %A" msg)
            let ctx = actorCtx ()
            let senderRef = ctx.Sender
            match ProcMessageParser.tryParse msg.message with
            | Ok payload -> forwardToFsi payload senderRef
            | Error err -> senderRef.Tell(Status.Failure(Exception(err)), selfRef ()))

        this.Receive<GetProcInfo>(fun (_: GetProcInfo) ->
            let ctx = actorCtx ()
            ctx.Sender.Tell(buildSnapshot (), ctx.Self))

        this.Receive<ProcNodeReady>(fun (msg: ProcNodeReady) ->
            let toOption value =
                if String.IsNullOrWhiteSpace value then None else Some value
            nodeAddress <- toOption msg.nodeAddress
            fsiSupervisorPath <- toOption msg.fsiSupervisorPath
            status <- "running"
            updateSnapshot ())

        this.Receive<ProcInternal>(fun msg ->
            match msg with
            | CheckProcess ->
                ensureProcess ()
            | ProbeTick ->
                handleProbe ()
            | Restart ->
                ensureProcess ()
            | ProcessExited _ ->
                status <- "stopped"
                proc <- None
                fsiSupervisorPath <- None
                updateSnapshot ()
                scheduleRestart ()
            | ChildNodeAddressDiscovered address ->
                if nodeAddress <> Some address then
                    nodeAddress <- Some address
                    if fsiSupervisorPath.IsNone then
                        fsiSupervisorPath <- Some(address + AkkaFsiBootstrap.supervisorPath)
                    updateSnapshot ()
            | ProbeResult result ->
                applyProbeResult result)

    member _.ActorCtx: IActorContext = ActorBase.Context

type ProcMessageExtractor(shardCount: int) =
    interface IMessageExtractor with
        member _.EntityId(message) =
            match message with
            | :? ProcEnvelope as env -> env.entityId
            | _ -> null

        member _.EntityMessage(message) =
            match message with
            | :? ProcEnvelope as env -> env.payload
            | _ -> message

        member _.ShardId(message) =
            match message with
            | :? ProcEnvelope as env ->
                (abs (env.entityId.GetHashCode()) % shardCount).ToString()
            | _ -> null

        member _.ShardId(entityId: string, messageHint: obj) =
            (abs (entityId.GetHashCode()) % shardCount).ToString()

type ProcSupervisorActor(region: IActorRef, registry: IActorRef) as this =
    inherit ReceiveActor()

    let log () = Logging.GetLogger(this.ActorCtx)

    do
        this.Receive<OpCmd>(fun cmd ->
            let ctx: IActorContext = this.ActorCtx
            match cmd with
            | GetVesion ->
                let result =
                    OpResult.fromAssembly
                        cmd
                        (Some(ctx.Self.Path.ToString()))
                        (System.Reflection.Assembly.GetExecutingAssembly())
                ctx.Sender.Tell(result, ctx.Self))
        this.Receive<StartProc>(fun (msg: StartProc) ->
            region.Forward({ entityId = msg.procId; payload = msg }))
        this.Receive<StopProc>(fun (msg: StopProc) ->
            region.Forward({ entityId = msg.procId; payload = msg }))
        this.Receive<UpdateProbe>(fun (msg: UpdateProbe) ->
            region.Forward({ entityId = msg.procId; payload = msg }))
        this.Receive<ForwardMessage>(fun (msg: ForwardMessage) ->
            log().Debug(sprintf "ForwardMessage routed: %A" msg)
            region.Forward({ entityId = msg.procId; payload = msg }))
        this.Receive<GetProcInfo>(fun (msg: GetProcInfo) ->
            region.Forward({ entityId = msg.procId; payload = msg }))
        this.Receive<ProcNodeReady>(fun (msg: ProcNodeReady) ->
            let ctx: IActorContext = this.ActorCtx
            region.Tell({ entityId = msg.procId; payload = msg }, ctx.Sender))
        this.Receive<GetAllProcInfo>(fun _ ->
            let ctx: IActorContext = this.ActorCtx
            registry.Forward(GetSnapshots(ctx.Sender)))
        this.Receive<CleanStoppedProcNodes>(fun _ ->
            let ctx: IActorContext = this.ActorCtx
            registry.Forward(CleanStoppedSnapshots(ctx.Sender)))

    member _.ActorCtx: IActorContext = ActorBase.Context
