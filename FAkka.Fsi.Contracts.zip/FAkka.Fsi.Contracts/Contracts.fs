﻿namespace Akka.FSI.Contracts

open System
open System.Diagnostics
open System.Reflection
open System.Runtime.CompilerServices

#if NET10_0_OR_GREATER
[<IsReadOnly; Struct>]
#else
[<Struct>]
#endif
type RangeLite =
    { file: string
      startLine: int
      startCol: int
      endLine: int
      endCol: int }

#if NET10_0_OR_GREATER
[<IsReadOnly; Struct>]
#else
[<Struct>]
#endif
type DiagnosticInfo =
    { severity: string
      code: string option
      message: string
      range: RangeLite option }

#if NET10_0_OR_GREATER
[<IsReadOnly; Struct>]
#else
[<Struct>]
#endif
type ErrorDetailInfo =
    { errorType: string option
      stackTrace: string option
      extra: string option }

#if NET10_0_OR_GREATER
[<IsReadOnly; Struct>]
#else
[<Struct>]
#endif
type ErrorInfo =
    { code: string
      message: string
      detail: ErrorDetailInfo option }

type IMessage = interface end

type OpCmd =
    | GetVesion

    interface IMessage

[<CLIMutable>]
type OpResult =
    { op: string
      assemblyName: string
      assemblyVersion: string option
      fileVersion: string option
      informationalVersion: string option
      actorPath: string option }

    interface IMessage

module OpResult =
    let fromAssembly (op: OpCmd) (actorPath: string option) (assembly: Assembly) =
        let asmName = assembly.GetName()
        let location =
            try assembly.Location
            with _ -> String.Empty
        let fileVersion =
            if String.IsNullOrWhiteSpace location then
                None
            else
                try
                    FileVersionInfo.GetVersionInfo(location).FileVersion
                    |> Option.ofObj
                with _ -> None
        let informationalVersion =
            try
                assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                |> Option.ofObj
                |> Option.map (fun attr -> attr.InformationalVersion)
            with _ -> None

        { op = string op
          assemblyName = asmName.Name
          assemblyVersion = asmName.Version |> Option.ofObj |> Option.map string
          fileVersion = fileVersion
          informationalVersion = informationalVersion
          actorPath = actorPath }

[<CLIMutable>]
type ExecCode =
    { id: string
      session: string
      code: string
      refs: string list
      loads: string list
      args: string list option
      timeoutMs: int option
      captureStdout: bool option }

    interface IMessage

[<CLIMutable>]
type ExecResult =
    { id: string
      ok: bool
      resultJson: string option
      stdout: string
      stderr: string
      diagnostics: DiagnosticInfo list
      elapsedMs: int64
      session: string
      error: ErrorInfo option }

    interface IMessage

type ExecCodeJson =
    | ExecCodeJson of json: string

    interface IMessage

type ExecResultJson =
    | ExecResultJson of json: string

    interface IMessage

[<CLIMutable>]
type GetSessionInfo =
    { session: string }

    interface IMessage

[<CLIMutable>]
type SessionInfo =
    { session: string
      status: string
      refs: string list
      loads: string list
      searchPaths: string list
      variables: (string * string) list
      lastCheckpointId: string option
      runningSinceUtc: DateTime option }

    interface IMessage

[<CLIMutable>]
type ListSessions =
    { all: bool }

    interface IMessage

[<CLIMutable>]
type Sessions =
    { items: SessionInfo list }

    interface IMessage

[<CLIMutable>]
type ResetSession =
    { session: string }

    interface IMessage

[<CLIMutable>]
type ResetSessionResult =
    { session: string
      existed: bool
      status: string }

    interface IMessage

[<CLIMutable>]
type PutFile =
    { path: string
      content: string
      encoding: string option }

    interface IMessage

[<CLIMutable>]
type DeleteFile =
    { path: string }

    interface IMessage

[<CLIMutable>]
type Commit =
    { keyspace: string
      comment: string option }

    interface IMessage

[<CLIMutable>]
type GetFile =
    { path: string }

    interface IMessage

[<CLIMutable>]
type FileContent =
    { path: string
      content: string option }

    interface IMessage

[<CLIMutable>]
type Checkpoint =
    { session: string
      id: string option
      comment: string option }

    interface IMessage

[<CLIMutable>]
type CheckpointResult =
    { session: string
      id: string }

    interface IMessage

[<CLIMutable>]
type Fork =
    { fromSession: string
      newSession: string
      checkpointId: string option }

    interface IMessage

[<CLIMutable>]
type Join =
    { parentSession: string
      childSessions: string list
      reducer: string option }

    interface IMessage

[<CLIMutable>]
type FileRecord =
    { path: string
      content: string
      timestampUtc: DateTime }

    interface IMessage

[<CLIMutable>]
type StartWorker =
    { seedNodes: string list
      args: string list option }

    interface IMessage

[<CLIMutable>]
type WorkerStarted =
    { pid: int
      address: string option }

    interface IMessage

[<CLIMutable>]
type ExecBatch =
    { items: ExecCode list
      timeoutMs: int option }

    interface IMessage

[<CLIMutable>]
type ExecBatchResult =
    { results: ExecResult list }

    interface IMessage
