namespace Akka.FSI.Contracts

open System
open System.IO
open System.Reflection
open System.Collections.Immutable
open Akka.Actor
open Akka.Configuration
open Akka.Serialization
open MBrace.FsPickler

module ContractSerialization =
    let private serializeToBinary (serializer: BinarySerializer) (value: obj) =
        use stream = new MemoryStream()
        serializer.Serialize(stream, value)
        stream.ToArray()

    let private deserializeFromBinary<'T> (serializer: BinarySerializer) (bytes: byte array) =
        use stream = new MemoryStream(bytes)
        serializer.Deserialize<'T> stream

    let private immutableHashSetPickler (resolver: IPicklerResolver) =
        let intPickler = resolver.Resolve<int>()
        let stringPickler = resolver.Resolve<string>()

        let writer (state: WriteState) (items: ImmutableHashSet<string>) =
            intPickler.Write state "len" items.Count
            items |> Seq.iter (fun item -> stringPickler.Write state "itm" item)

        let reader (state: ReadState) =
            let len = intPickler.Read state "len"
            let values = Array.init len (fun _ -> stringPickler.Read state "itm")
            ImmutableHashSet.Create<string>(values)

        Pickler.FromPrimitives(reader, writer)

    let private actorRefPickler<'T when 'T :> IActorRef> (extendedSystem: ExtendedActorSystem) (resolver: IPicklerResolver) =
        let stringPickler = resolver.Resolve<string>()

        let writer (state: WriteState) (actorRef: 'T) =
            stringPickler.Write state "path" (Serialization.SerializedActorPath(actorRef))

        let reader (state: ReadState) =
            let path = stringPickler.Read state "path"
            extendedSystem.Provider.ResolveActorRef(path) :?> 'T

        Pickler.FromPrimitives(reader, writer)

    let private actorPathPickler<'T when 'T :> ActorPath> () =
        let factory (resolver: IPicklerResolver) =
            let int64Pickler = resolver.Resolve<int64>()
            let intPickler = resolver.Resolve<int>()
            let strPickler = resolver.Resolve<string>()
            let addrPickler = resolver.Resolve<Address>()

            let writer (state: WriteState) (path: 'T) =
                let rec loop (current: ActorPath) depth =
                    strPickler.Write state "type" (current.GetType().Name)
                    intPickler.Write state $"dp{depth}" current.Depth
                    int64Pickler.Write state $"uid{depth}" current.Uid
                    strPickler.Write state $"nm{depth}" current.Name
                    addrPickler.Write state $"addr{depth}" current.Address

                    if not (isNull current.Parent) then
                        loop current.Parent (depth + 1)

                loop path 0

            let rec readPath (state: ReadState) depth =
                let dp = intPickler.Read state $"dp{depth}"
                let uid = int64Pickler.Read state $"uid{depth}"
                let name = strPickler.Read state $"nm{depth}"
                let addr = addrPickler.Read state $"addr{depth}"

                if dp = 0 then
                    RootActorPath(addr, name) :> ActorPath
                else
                    ChildActorPath(readPath state (depth + 1), name, uid) :> ActorPath

            let reader (state: ReadState) = readPath state 0 :?> 'T

            Pickler.FromPrimitives(reader, writer)

        factory

    let private cacheGate = obj ()
    let mutable private cacheOpt: PicklerCache option = None

    let private getCache (system: ExtendedActorSystem) =
        lock cacheGate (fun () ->
            match cacheOpt with
            | Some cache -> cache
            | None ->
                let registry = CustomPicklerRegistry()
                registry.RegisterFactory immutableHashSetPickler |> ignore
                registry.RegisterFactory(actorRefPickler<RepointableActorRef> system) |> ignore
                registry.RegisterFactory(actorRefPickler<IActorRef> system) |> ignore
                registry.RegisterFactory(actorRefPickler<LocalActorRef> system) |> ignore
                registry.RegisterFactory(actorRefPickler<EmptyLocalActorRef> system) |> ignore
                registry.RegisterFactory(actorRefPickler<RootGuardianActorRef> system) |> ignore
                registry.DeclareSerializable<Address>() |> ignore
                registry.RegisterFactory(actorPathPickler<ChildActorPath>()) |> ignore
                registry.RegisterFactory(actorPathPickler<RootActorPath>()) |> ignore
                let cache = PicklerCache.FromCustomPicklerRegistry(registry)
                cacheOpt <- Some cache
                cache)

    let private collectMessageTypes (assemblies: Assembly seq) =
        assemblies
        |> Seq.distinctBy (fun assembly -> assembly.FullName)
        |> Seq.collect (fun assembly -> assembly.GetTypes())
        |> Seq.filter (fun messageType ->
            not (isNull messageType)
            && not messageType.IsAbstract
            && not messageType.ContainsGenericParameters
            && typeof<IMessage>.IsAssignableFrom(messageType))
        |> Seq.distinctBy (fun messageType -> messageType.AssemblyQualifiedName)

    type ContractSerializer(system: ExtendedActorSystem) =
        inherit Serializer(system)

        let binarySerializer =
            let cache = getCache system
            FsPickler.CreateBinarySerializer(picklerResolver = cache)

        override _.Identifier = 199
        override _.IncludeManifest = true
        override _.ToBinary(value: obj) = serializeToBinary binarySerializer value
        override _.FromBinary(bytes: byte array, _manifest: Type) =
            deserializeFromBinary<obj> binarySerializer bytes :> obj

    let configForAssemblies (assemblies: Assembly seq) =
        let serializerAlias = "fakka-contracts"
        let serializerType = typeof<ContractSerializer>.AssemblyQualifiedName
        let bindings =
            collectMessageTypes assemblies
            |> Seq.choose (fun messageType -> messageType.AssemblyQualifiedName |> Option.ofObj)
            |> Seq.map (fun assemblyQualifiedName -> $"\"{assemblyQualifiedName}\" = {serializerAlias}")
            |> String.concat "\n      "

        let body =
            $"""
akka.actor {{
  serializers {{
    {serializerAlias} = "{serializerType}"
  }}
  serialization-bindings {{
      {bindings}
  }}
  serialization-identifiers {{
    "{serializerType}" = 199
  }}
}}
"""

        ConfigurationFactory.ParseString(body)

    let private tryRegisterMessageType (system: ActorSystem) (serializer: Serializer) (messageType: Type) =
        if not (isNull messageType)
           && not messageType.IsAbstract
           && not messageType.ContainsGenericParameters
           && typeof<IMessage>.IsAssignableFrom(messageType) then
            system.Serialization.AddSerializationMap(messageType, serializer)

    let installForAssemblies (system: ActorSystem) (assemblies: Assembly seq) =
        let serializer = ContractSerializer(system :?> ExtendedActorSystem)
        let serializerName = "FAkkaContractsFsPickler"
        system.Serialization.AddSerializer(serializerName, serializer)

        assemblies |> collectMessageTypes |> Seq.iter (tryRegisterMessageType system serializer)

        serializer
