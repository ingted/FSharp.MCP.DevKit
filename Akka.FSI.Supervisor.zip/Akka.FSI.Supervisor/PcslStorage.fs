namespace Akka.FSI.Supervisor

open System
open System.IO
open Akka.FSI.Contracts
open PersistedConcurrentSortedList.PCSL2
open PersistedConcurrentSortedList.Type

/// PCSL2-backed storage abstraction used by the supervisor/FSI.
type IPcslStorage =
    abstract member Put: path: string * content: string -> unit
    abstract member Delete: path: string -> unit
    abstract member TryGet: path: string -> string option
    abstract member List: prefix: string -> FileRecord list
    abstract member Commit: keyspace: string * comment: string option -> unit

/// PCSL2 implementation using PersistedConcurrentSortedList<string, fCell2<string>>.
type Pcsl2Storage(basePath: string, schema: string) =
    // Single KV store for all keyspaces; the caller includes the keyspace in the key.
    let pcsl = new PersistedConcurrentSortedList<string, fCell2<string>>(40, basePath, schema)

    let normalize (path: string) =
        if String.IsNullOrWhiteSpace path then path
        else path.Replace('\\', '/').TrimEnd('/')

    interface IPcslStorage with
        member _.Put(path, content) =
            let key = normalize path
            pcsl.Upsert(key, fCell2<string>.S content) |> ignore

        member _.Delete(path) =
            let key = normalize path
            pcsl.Remove(key) |> ignore

        member _.TryGet(path) =
            let key = normalize path
            match pcsl.TryGetValue key with
            | (true, Some (S s)) -> Some s
            | (true, Some v) -> Some v.Value
            | _ -> None

        member _.List(prefix) =
            let pref = normalize prefix
            // Enumerate keys via underlying concurrent sorted list for prefix filtering.
            let keys = pcsl._base._base.Keys |> Seq.cast<string>
            keys
            |> Seq.filter (fun k -> k.StartsWith(pref, StringComparison.OrdinalIgnoreCase))
            |> Seq.choose (fun k ->
                match pcsl.TryGetValue k with
                | (true, Some (S s)) ->
                    Some { path = k; content = s; timestampUtc = DateTime.UtcNow }
                | (true, Some v) ->
                    Some { path = k; content = v.Value; timestampUtc = DateTime.UtcNow }
                | _ -> None)
            |> Seq.toList

        member _.Commit(_, _) = ()

module PcslStorage =
    /// Create a PCSL2-backed storage rooted at a directory (created if missing).
    let pcsl2 (root: string) (schema: string) : IPcslStorage =
        Directory.CreateDirectory(root) |> ignore
        new Pcsl2Storage(root, schema) :> IPcslStorage

    /// For development without persistence, fallback to a temp folder.
    let inMemory () : IPcslStorage =
        let tmp = Path.Combine(Path.GetTempPath(), "akka-fsi-pcsl")
        pcsl2 tmp "fsi"

