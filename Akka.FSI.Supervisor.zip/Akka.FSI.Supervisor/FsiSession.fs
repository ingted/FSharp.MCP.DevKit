﻿namespace Akka.FSI.Supervisor

open System
open System.IO
open System.Text
open FSharp.Compiler.Diagnostics
open FSharp.Compiler.Text
open FSharp.Compiler.Interactive.Shell
open Akka.FSI.Contracts

[<CLIMutable>]
type SessionRuntimeState =
    { mutable Status: string
      mutable Variables: (string * string) list
      mutable Refs: string list
      mutable Loads: string list
      mutable LastCheckpointId: string option
      CreatedUtc: DateTime
      mutable RunningSinceUtc: DateTime option }

module Diagnostics =
    let toRange (range: Range) =
        if String.IsNullOrEmpty range.FileName then
            None
        else
            Some
                { file = range.FileName
                  startLine = range.StartLine
                  startCol = range.StartColumn
                  endLine = range.EndLine
                  endCol = range.EndColumn }

    let ofFSharpDiagnostic (diag: FSharpDiagnostic) =
        { severity = diag.Severity.ToString().ToLowerInvariant()
          code =
            if String.IsNullOrWhiteSpace diag.ErrorNumberText then
                None
            else
                Some diag.ErrorNumberText
          message = diag.Message
          range = toRange diag.Range }

    let collect (diagnostics: FSharpDiagnostic array) =
        diagnostics |> Array.map ofFSharpDiagnostic |> Array.toList

module FsiSession =
    type Handle(sessionName: string, ?argv: string array) =
        let inStream = new StringReader(String.Empty)
        let outStream = new StringWriter(StringBuilder())
        let errStream = new StringWriter(StringBuilder())
        let argv = defaultArg argv [| "fsi.exe" |]
        let config = FsiEvaluationSession.GetDefaultConfiguration()
        let session = FsiEvaluationSession.Create(config, argv, inStream, outStream, errStream, collectible = false)

        let state =
            { Status = "ready"
              Variables = []
              Refs = []
              Loads = []
              LastCheckpointId = None
              CreatedUtc = DateTime.UtcNow
              RunningSinceUtc = Some DateTime.UtcNow }

        member _.SessionName = sessionName
        member _.Runtime = state
        member _.RawSession = session
        member _.Stdout = outStream
        member _.Stderr = errStream

        member _.ResetBuffers() =
            outStream.GetStringBuilder().Clear() |> ignore
            errStream.GetStringBuilder().Clear() |> ignore

        member _.UpdateRefs refs loads =
            state.Refs <- refs
            state.Loads <- loads

        member _.ApplyCheckpoint(checkpointId: string option) = state.LastCheckpointId <- checkpointId

        member _.RefreshVariables() =
            let bound = session.GetBoundValues()

            state.Variables <-
                bound
                |> Seq.map (fun v -> v.Name, v.Value.ReflectionType.FullName)
                |> Seq.toList

        member _.DiagnosticsFrom(diagnostics: FSharpDiagnostic array) = Diagnostics.collect diagnostics

        member _.EvalInteraction(code: string) = session.EvalInteractionNonThrowing code

        member _.EvalExpression(expression: string) =
            session.EvalExpressionNonThrowing expression

        member _.StdoutText() = outStream.ToString()
        member _.StderrText() = errStream.ToString()

        member _.Dispose() =
            (session :> IDisposable).Dispose()
            outStream.Dispose()
            errStream.Dispose()
            inStream.Dispose()

        interface IDisposable with
            member this.Dispose() = this.Dispose()

    let diagnostics = Diagnostics.collect
