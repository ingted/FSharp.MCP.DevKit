namespace Akka.FSI.Supervisor

open System
open System.IO
open System.Text
open FSharp.Compiler.IO

/// <summary>
/// FCS IFileSystem 實作，優先查詢 PCSL2 overlay，再回退至 OS FileSystem。
/// </summary>
type PcslFileSystem(storage: IPcslStorage, overlayRoots: string list) =
    let baseFs: IFileSystem = FileSystemAutoOpens.FileSystem

    let normalizedRoots =
        overlayRoots
        |> Seq.map (fun path ->
            if String.IsNullOrWhiteSpace path then
                path
            else
                Path.GetFullPath path)
        |> Seq.filter (fun path -> not (String.IsNullOrWhiteSpace path))
        |> Seq.toArray

    let isAllowedRoot (path: string) =
        if normalizedRoots.Length = 0 then
            true
        else
            let full = Path.GetFullPath path

            normalizedRoots
            |> Array.exists (fun root -> full.StartsWith(root, StringComparison.OrdinalIgnoreCase))

    let normalizePath (path: string) =
        if String.IsNullOrWhiteSpace path then
            path
        else
            path.Replace('\\', '/').TrimEnd('/')

    let toMemoryStream (content: string) =
        let bytes = Encoding.UTF8.GetBytes content
        new MemoryStream(bytes, 0, bytes.Length, false, true) :> Stream

    let storageHit path = storage.TryGet(normalizePath path)

    let storageHasChildren path =
        storage.List(normalizePath path) |> List.isEmpty |> not

    let deleteStoragePrefix path =
        let normalized = normalizePath path

        if String.IsNullOrEmpty normalized then
            ()
        else
            storage.Delete normalized

            let prefix =
                if normalized.EndsWith "/" then
                    normalized
                else
                    normalized + "/"

            storage.List(prefix) |> List.iter (fun record -> storage.Delete record.path)

    interface IFileSystem with
        member _.AssemblyLoader = baseFs.AssemblyLoader

        member _.ChangeExtensionShim(path, extension) =
            baseFs.ChangeExtensionShim(path, extension)

        member _.CopyShim(source, destination, overwrite) =
            baseFs.CopyShim(source, destination, overwrite)

        member _.DirectoryCreateShim path = baseFs.DirectoryCreateShim path

        member _.DirectoryDeleteShim path =
            deleteStoragePrefix path
            baseFs.DirectoryDeleteShim path

        member _.DirectoryExistsShim path =
            baseFs.DirectoryExistsShim path || storageHasChildren path

        member _.EnumerateDirectoriesShim path = baseFs.EnumerateDirectoriesShim path

        member _.EnumerateFilesShim(path, pattern) =
            baseFs.EnumerateFilesShim(path, pattern)

        member _.FileDeleteShim path =
            storage.Delete(normalizePath path)
            baseFs.FileDeleteShim path

        member _.FileExistsShim path =
            storageHit path |> Option.isSome
            || (isAllowedRoot path && baseFs.FileExistsShim path)

        member _.GetCreationTimeShim path = baseFs.GetCreationTimeShim path

        member _.GetDirectoryNameShim path = baseFs.GetDirectoryNameShim path

        member _.GetFullFilePathInDirectoryShim directory fileName =
            baseFs.GetFullFilePathInDirectoryShim directory fileName

        member _.GetFullPathShim path = baseFs.GetFullPathShim path

        member _.GetLastWriteTimeShim path = baseFs.GetLastWriteTimeShim path

        member _.GetTempPathShim() = baseFs.GetTempPathShim()

        member _.IsInvalidPathShim path = baseFs.IsInvalidPathShim path

        member _.IsPathRootedShim path = baseFs.IsPathRootedShim path

        member _.IsStableFileHeuristic path = baseFs.IsStableFileHeuristic path

        member _.NormalizePathShim path = baseFs.NormalizePathShim path

        member _.OpenFileForReadShim(path, ?useMemoryMappedFile, ?shouldShadowCopy) =
            match storageHit path with
            | Some content -> toMemoryStream content
            | None when isAllowedRoot path ->
                baseFs.OpenFileForReadShim(
                    path,
                    ?useMemoryMappedFile = useMemoryMappedFile,
                    ?shouldShadowCopy = shouldShadowCopy
                )
            | _ -> raise (FileNotFoundException(sprintf "File '%s' not found" path))

        member _.OpenFileForWriteShim(path, ?fileMode, ?fileAccess, ?fileShare) =
            raise (UnauthorizedAccessException(sprintf "Write operation '%s' is not allowed in PcslFileSystem." path))

module PcslFileSystem =
    let install (storage: IPcslStorage) (overlayRoots: string list) =
        let fs = PcslFileSystem(storage, overlayRoots)
        FileSystemAutoOpens.FileSystem <- fs :> IFileSystem
        fs
