namespace Akka.FSI.Supervisor

open System
open Akka.Configuration

[<CLIMutable>]
type TimeoutSettings =
    { startupMs: int
      execMs: int
      idleRestartMs: int }

    static member Default =
        { startupMs = 20_000
          execMs = 30_000
          idleRestartMs = 600_000 }

[<CLIMutable>]
type PcslSettings =
    { scriptsKeyspace: string
      resultsKeyspace: string
      snapshotsKeyspace: string
      autoCommit: bool }

    static member Default =
        { scriptsKeyspace = "scripts"
          resultsKeyspace = "results"
          snapshotsKeyspace = "snapshots"
          autoCommit = true }

[<CLIMutable>]
type FileSystemSettings =
    { overlayRoots: string list
      allowOsRead: bool
      allowOsWrite: bool }

    static member Default =
        { overlayRoots = []
          allowOsRead = true
          allowOsWrite = false }

[<CLIMutable>]
type SupervisorSettings =
    { mode: string
      workerCount: int
      autoSession: string
      timeouts: TimeoutSettings
      pcsl: PcslSettings
      filesystem: FileSystemSettings }

    static member Default =
        { mode = "inproc"
          workerCount = 1
          autoSession = "default"
          timeouts = TimeoutSettings.Default
          pcsl = PcslSettings.Default
          filesystem = FileSystemSettings.Default }

module SupervisorSettingsReader =
    let getStringList (config: Config) (path: string) =
        if config.HasPath(path) then
            config.GetStringList(path) |> Seq.toList
        else
            []

    let load (config: Config option) =
        let root =
            match config with
            | Some cfg when cfg.HasPath("akka.fsi") -> cfg.GetConfig("akka.fsi")
            | _ -> null

        let defaults = SupervisorSettings.Default

        if isNull root then
            defaults
        else
            { mode =
                if root.HasPath("mode") then
                    root.GetString("mode")
                else
                    defaults.mode
              workerCount =
                if root.HasPath("worker-count") then
                    root.GetInt("worker-count")
                else
                    defaults.workerCount
              autoSession =
                if root.HasPath("auto-session") then
                    root.GetString("auto-session")
                else
                    defaults.autoSession
              timeouts =
                let timeCfg =
                    if root.HasPath("timeouts") then
                        root.GetConfig("timeouts")
                    else
                        null

                if isNull timeCfg then
                    defaults.timeouts
                else
                    { startupMs =
                        if timeCfg.HasPath("startup-ms") then
                            timeCfg.GetInt("startup-ms")
                        else
                            defaults.timeouts.startupMs
                      execMs =
                        if timeCfg.HasPath("exec-ms") then
                            timeCfg.GetInt("exec-ms")
                        else
                            defaults.timeouts.execMs
                      idleRestartMs =
                        if timeCfg.HasPath("idle-restart-ms") then
                            timeCfg.GetInt("idle-restart-ms")
                        else
                            defaults.timeouts.idleRestartMs }
              pcsl =
                let pcslCfg =
                    if root.HasPath("pcsl2") then
                        root.GetConfig("pcsl2")
                    else
                        null

                if isNull pcslCfg then
                    defaults.pcsl
                else
                    { scriptsKeyspace =
                        if pcslCfg.HasPath("scripts-keyspace") then
                            pcslCfg.GetString("scripts-keyspace")
                        else
                            defaults.pcsl.scriptsKeyspace
                      resultsKeyspace =
                        if pcslCfg.HasPath("results-keyspace") then
                            pcslCfg.GetString("results-keyspace")
                        else
                            defaults.pcsl.resultsKeyspace
                      snapshotsKeyspace =
                        if pcslCfg.HasPath("snapshots-keyspace") then
                            pcslCfg.GetString("snapshots-keyspace")
                        else
                            defaults.pcsl.snapshotsKeyspace
                      autoCommit =
                        if pcslCfg.HasPath("auto-commit") then
                            pcslCfg.GetBoolean("auto-commit")
                        else
                            defaults.pcsl.autoCommit }
              filesystem =
                let fsCfg =
                    if root.HasPath("filesystem") then
                        root.GetConfig("filesystem")
                    else
                        null

                if isNull fsCfg then
                    defaults.filesystem
                else
                    { overlayRoots = getStringList fsCfg "overlay-roots"
                      allowOsRead =
                        if fsCfg.HasPath("allow-os-read") then
                            fsCfg.GetBoolean("allow-os-read")
                        else
                            defaults.filesystem.allowOsRead
                      allowOsWrite =
                        if fsCfg.HasPath("allow-os-write") then
                            fsCfg.GetBoolean("allow-os-write")
                        else
                            defaults.filesystem.allowOsWrite } }
