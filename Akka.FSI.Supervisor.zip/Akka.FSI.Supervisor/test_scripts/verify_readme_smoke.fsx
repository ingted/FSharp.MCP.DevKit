#r "nuget: Akka, 1.5.62"
#r "nuget: FSharp.Compiler.Service, 43.12.201"
#r "../bin/Debug/net10.0/FAkka.Fsi.Contracts.dll"
#r "../bin/Debug/net10.0/Akka.FSI.Supervisor.dll"
#r "../bin/Debug/net10.0/PersistedConcurrentSortedList.IFileSystem.dll"

open System
open System.IO
open Akka.Actor

let outDir =
    Path.GetFullPath(Path.Combine(__SOURCE_DIRECTORY__, "..", "bin", "Debug", "net10.0"))

Environment.SetEnvironmentVariable(
    "PROTOBUF_FSHARP_DLL",
    Path.Combine(outDir, "protobuf-net-fsharp.dll")
)

open Akka.FSI.Contracts
open Akka.FSI.Supervisor

let system = ActorSystem.Create("ReadmeSmokeFsiSystem")
let supervisorRef = AkkaFsiBootstrap.EnsureSupervisor(system)

let request =
    { id = Guid.NewGuid().ToString("N")
      session = "readme-smoke"
      code = "let add a b = a + b\nadd 5 7"
      refs = []
      loads = []
      args = None
      timeoutMs = Some 10000
      captureStdout = Some true }

let jsonRequest = JsonCodec.serialize request

let result =
    async {
        let! jsonResponse = AkkaFsiBootstrap.ExecJson supervisorRef jsonRequest
        let! sessionInfoJson = AkkaFsiBootstrap.GetSessionInfoJson supervisorRef "readme-smoke"
        return JsonCodec.deserialize<ExecResult> jsonResponse, JsonCodec.deserialize<SessionInfo> sessionInfoJson
    }
    |> Async.RunSynchronously

let execResult, sessionInfo = result

printfn "ok=%b" execResult.ok
printfn "resultJson=%A" execResult.resultJson
printfn "sessionStatus=%s" sessionInfo.status

system.Terminate() |> ignore
system.WhenTerminated.Wait()

if not execResult.ok then
    failwithf "README smoke failed: %A" execResult

if execResult.resultJson <> Some "12" then
    failwithf "Unexpected resultJson: %A" execResult.resultJson

if not (String.Equals(sessionInfo.status, "ready", StringComparison.OrdinalIgnoreCase)) then
    failwithf "Unexpected session status: %s" sessionInfo.status
