﻿namespace Akka.FSI.Supervisor
open PersistedConcurrentSortedList.IFileSystem
open PersistedConcurrentSortedList.Type
open System
open System.Diagnostics
open System.IO
open System.Reflection
open System.Text.Json
open Akka.Actor
open Akka.Event
open Akka.Pattern
open Akka.FSI.Contracts
open ExecHelpers
open ProtoBuf
open ProtoBuf.Meta

module ProtoBufInit =
    let private syncRoot = obj()
    let mutable private initialized = false
    let mutable private serialiserTypeCache: Type option = None

    let private findProtobufFsharpType () =
        match serialiserTypeCache with
        | Some cached -> Some cached
        | None ->
            let direct = Type.GetType("ProtoBuf.FSharp.Serialiser, protobuf-net-fsharp")
            let loaded =
                if isNull direct then None
                else Some direct

            let resolveFromAssembly (asm: Reflection.Assembly) =
                let resolved = asm.GetType("ProtoBuf.FSharp.Serialiser", false)
                if isNull resolved then None else Some resolved

            let fromLoadedAssemblies () =
                AppDomain.CurrentDomain.GetAssemblies()
                |> Array.tryPick resolveFromAssembly

            let tryLoadFromPath (path: string) =
                if String.IsNullOrWhiteSpace path || not (File.Exists path) then
                    None
                else
                    try
                        let asm = Reflection.Assembly.LoadFrom(path)
                        resolveFromAssembly asm
                    with _ -> None

            let candidatePaths () =
                let envPath = Environment.GetEnvironmentVariable("PROTOBUF_FSHARP_DLL")
                [ envPath
                  Path.Combine(AppContext.BaseDirectory, "protobuf-net-fsharp.dll")
                  Path.Combine(Directory.GetCurrentDirectory(), "protobuf-net-fsharp.dll")
                  @"G:\coldfar_py\sharftrade9\Libs5\KServer\fstring\bin\net10.0\protobuf-net-fsharp.dll"
                  @"G:\coldfar_py\sharftrade9\Libs5\KServer\fstring\bin\net9.0\protobuf-net-fsharp.dll"
                  @"G:\coldfar_py\sharftrade9\Libs5\KServer\protobuf-net-fsharp\bin\net10.0\protobuf-net-fsharp.dll"
                  @"G:\coldfar_py\sharftrade9\Libs5\KServer\protobuf-net-fsharp\bin\net9.0\protobuf-net-fsharp.dll" ]

            let resolved =
                loaded
                |> Option.orElseWith fromLoadedAssemblies
                |> Option.orElseWith (fun () ->
                    candidatePaths ()
                    |> Seq.tryPick tryLoadFromPath)

            serialiserTypeCache <- resolved
            resolved

    let private tryRegisterUnitIntoModel (model: RuntimeTypeModel) =
        try
            match findProtobufFsharpType () with
            | None -> false
            | Some serialiserType ->
                let methods =
                    serialiserType.GetMethods(Reflection.BindingFlags.Public ||| Reflection.BindingFlags.Static)

                let matches (m: Reflection.MethodInfo) =
                    let ps = m.GetParameters()
                    m.Name = "registerRuntimeTypeIntoModel"
                    && ps.Length = 2
                    && ps |> Array.exists (fun p -> p.ParameterType = typeof<Type>)
                    && ps |> Array.exists (fun p -> p.ParameterType = typeof<RuntimeTypeModel>)

                match methods |> Array.tryFind matches with
                | None -> false
                | Some methodInfo ->
                    let ps = methodInfo.GetParameters()
                    let args: obj[] =
                        if ps.[0].ParameterType = typeof<Type> then
                            [| box typeof<unit>; box model |]
                        else
                            [| box model; box typeof<unit> |]
                    methodInfo.Invoke(null, args) |> ignore
                    true
        with _ -> false

    let private tryRegisterInLoadedModels () =
        let binding =
            Reflection.BindingFlags.Public
            ||| Reflection.BindingFlags.NonPublic
            ||| Reflection.BindingFlags.Static

        let tryRegisterFromType (t: Type) =
            try
                for prop in t.GetProperties(binding) do
                    if prop.PropertyType = typeof<RuntimeTypeModel> then
                        match prop.GetValue(null) with
                        | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                        | _ -> ()
                for field in t.GetFields(binding) do
                    if field.FieldType = typeof<RuntimeTypeModel> then
                        match field.GetValue(null) with
                        | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                        | _ -> ()
            with _ -> ()

        try
            for asm in AppDomain.CurrentDomain.GetAssemblies() do
                try
                    for t in asm.GetTypes() do
                        tryRegisterFromType t
                with _ -> ()
        with _ -> ()

    let private tryRegisterWithProtobufFsharp () =
        try
            match findProtobufFsharpType () with
            | None -> ()
            | Some serialiserType ->
                let getter =
                    serialiserType.GetMethod(
                        "get_defaultModel",
                        Reflection.BindingFlags.Public ||| Reflection.BindingFlags.Static)
                if not (isNull getter) then
                    match getter.Invoke(null, [||]) with
                    | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                    | _ -> ()
        with _ -> ()

    let private tryRegisterPcslModel () =
        try
            let containerType =
                Type.GetType("PersistedConcurrentSortedList.PB+ModelContainer`1, PersistedConcurrentSortedList")

            if not (isNull containerType) then
                let binding =
                    Reflection.BindingFlags.Public
                    ||| Reflection.BindingFlags.NonPublic
                    ||| Reflection.BindingFlags.Static

                let valueTypes: Type list =
                    [ typeof<fCell2<string>> ]

                for valueType in valueTypes do
                    try
                        let closed = containerType.MakeGenericType(valueType)
                        let prop = closed.GetProperty("pbModel", binding)
                        let field = closed.GetField("pbModel@", binding)

                        match prop with
                        | null ->
                            match field with
                            | null -> ()
                            | _ ->
                                match field.GetValue(null) with
                                | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                                | _ -> ()
                        | _ ->
                            match prop.GetValue(null) with
                            | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                            | _ ->
                                match field with
                                | null -> ()
                                | _ ->
                                    match field.GetValue(null) with
                                    | :? RuntimeTypeModel as model -> tryRegisterUnitIntoModel model |> ignore
                                    | _ -> ()
                    with _ -> ()
        with _ -> ()

    /// Ensure protobuf-net runtime models know how to serialize F# `unit`.
    ///
    /// This is not required by Akka remoting or by `GetVesion`/`ListSessions`.
    /// It exists because this supervisor also initializes the PCSL-backed virtual
    /// filesystem and storage path, and those code paths rely on protobuf-net /
    /// protobuf-net-fsharp runtime models. If `unit` is missing from those models,
    /// later PCSL/protobuf operations can fail at runtime.
    ///
    /// In short:
    /// - Akka / remoting concern: no
    /// - PCSL / protobuf storage concern: yes
    /// - Needed during supervisor startup because PCSL is installed eagerly: yes
    let ensureUnitSerializer () =
        lock syncRoot (fun () ->
            if not initialized then
                try
                    let sw = Stopwatch.StartNew()
                    printfn "[ProtoBufInit] step=default-model.start"
                    let model = RuntimeTypeModel.Default
                    printfn "[ProtoBufInit] step=default-model.done elapsedMs=%d" sw.ElapsedMilliseconds
                    printfn "[ProtoBufInit] step=register-unit.start"
                    tryRegisterUnitIntoModel model |> ignore
                    printfn "[ProtoBufInit] step=register-unit.done elapsedMs=%d" sw.ElapsedMilliseconds
                    printfn "[ProtoBufInit] step=register-protobuf-fsharp.start"
                    tryRegisterWithProtobufFsharp ()
                    printfn "[ProtoBufInit] step=register-protobuf-fsharp.done elapsedMs=%d" sw.ElapsedMilliseconds
                    printfn "[ProtoBufInit] step=register-pcsl.start"
                    tryRegisterPcslModel ()
                    printfn "[ProtoBufInit] step=register-pcsl.done elapsedMs=%d" sw.ElapsedMilliseconds
                    printfn "[ProtoBufInit] step=register-loaded-models.start"
                    tryRegisterInLoadedModels ()
                    printfn "[ProtoBufInit] step=register-loaded-models.done elapsedMs=%d" sw.ElapsedMilliseconds
                with _ -> ()
                initialized <- true)

/// <summary>
/// PCSL-backed virtual file system actor.
/// </summary>
type PcslFileSystemActor(storage: IPcslStorage, settings: SupervisorSettings) as this =
    inherit ReceiveActor()

    do this.Initialize()

    member _.ActorCtx = ActorBase.Context

    member this.Reply<'T>(msg: 'T) =
        let ctx = this.ActorCtx
        ctx.Sender.Tell(msg, ctx.Self)

    member _.KeyForScript(path: string) =
        let normalized = path.TrimStart('/', '\\')
        sprintf "%s/%s" settings.pcsl.scriptsKeyspace normalized

    member this.Initialize() =
        this.Receive<PutFile>(fun (msg: PutFile) ->
            let key = this.KeyForScript msg.path
            storage.Put(key, msg.content)
            this.Reply true)

        this.Receive<GetFile>(fun (msg: GetFile) ->
            let key = this.KeyForScript msg.path
            let content = storage.TryGet key
            this.Reply { path = msg.path; content = content })

        this.Receive<DeleteFile>(fun (msg: DeleteFile) ->
            let key = this.KeyForScript msg.path
            storage.Delete key
            this.Reply true)

        this.Receive<Commit>(fun (msg: Commit) ->
            storage.Commit(msg.keyspace, msg.comment)
            this.Reply true)

/// <summary>
/// Supervisor responsible for coordinating workers and PCSL interactions.
/// </summary>
type FsiSupervisorActor(settings: SupervisorSettings, storage: IPcslStorage) as this =
    inherit ReceiveActor()

    let sessionActors =
        System.Collections.Generic.Dictionary<string, IActorRef>(StringComparer.OrdinalIgnoreCase)
    let sessionInfoCache =
        System.Collections.Generic.Dictionary<string, SessionInfo>(StringComparer.OrdinalIgnoreCase)

    let tryExtractExecJsonFromObject (payload: obj) =
        let typeName = payload.GetType().FullName

        let normalizeExecJson (text: string) =
            let trimmed = text.Trim()
            if trimmed.StartsWith("execjson", StringComparison.OrdinalIgnoreCase) then
                trimmed.Substring("execjson".Length).Trim()
            else
                trimmed

        let tryFromCaseFields (json: string) =
            try
                use doc = JsonDocument.Parse(json)
                let root = doc.RootElement
                let mutable caseProp = Unchecked.defaultof<JsonElement>
                let mutable fieldsProp = Unchecked.defaultof<JsonElement>
                if root.TryGetProperty("Case", &caseProp) && caseProp.ValueKind = JsonValueKind.String then
                    let caseName = caseProp.GetString()
                    if String.Equals(caseName, "ExecCodeJson", StringComparison.Ordinal) then
                        if root.TryGetProperty("Fields", &fieldsProp) && fieldsProp.ValueKind = JsonValueKind.Array then
                            let first =
                                fieldsProp.EnumerateArray()
                                |> Seq.tryHead
                            match first with
                            | Some value when value.ValueKind = JsonValueKind.String ->
                                value.GetString()
                                |> Option.ofObj
                            | _ -> None
                        else
                            None
                    else
                        None
                else
                    None
            with _ ->
                None

        let tryFromJsonString (json: string) =
            let trimmed = json.Trim()
            if String.IsNullOrWhiteSpace(trimmed) then None else Some(trimmed)

        match typeName with
        // Design: when ExecCodeJson crosses remoting without DU serializers,
        // it may arrive as a JObject with Case/Fields payload.
        | "Newtonsoft.Json.Linq.JObject" ->
            payload.ToString() |> tryFromCaseFields
        | "Newtonsoft.Json.Linq.JValue" ->
            payload.ToString() |> normalizeExecJson |> tryFromJsonString
        | "Newtonsoft.Json.Linq.JArray" ->
            try
                let json = payload.ToString()
                use doc = JsonDocument.Parse(json)
                let root = doc.RootElement
                if root.ValueKind = JsonValueKind.Array then
                    let items =
                        root.EnumerateArray()
                        |> Seq.choose (fun element ->
                            if element.ValueKind = JsonValueKind.String then
                                element.GetString() |> Option.ofObj
                            else
                                None)
                        |> Seq.toList
                    if items.Length > 0 && items.Length = root.GetArrayLength() then
                        items.Head |> normalizeExecJson |> tryFromJsonString
                    else
                        None
                else
                    None
            with _ ->
                None
        | _ -> None

    do this.Initialize()
    member _.ActorCtx = ActorBase.Context
    member this.Log() = Logging.GetLogger(this.ActorCtx)

    member private this.DumpSerializationState(label: string) =
        try
            let system : ActorSystem = this.ActorCtx.System
            let flags = BindingFlags.NonPublic ||| BindingFlags.Instance
            let fields =
                system.Serialization.GetType().GetFields(flags)
                |> Array.map (fun f -> f.Name, f)
                |> Map.ofArray

            let serializersById =
                match Map.tryFind "_serializersById" fields with
                | Some field ->
                    match field.GetValue(system.Serialization) with
                    | :? System.Collections.IDictionary as dict ->
                        dict.Keys
                        |> Seq.cast<obj>
                        |> Seq.map (fun key ->
                            let serializer = dict[key] :?> Akka.Serialization.Serializer
                            string key, serializer.GetType().AssemblyQualifiedName)
                        |> Seq.sortBy fst
                        |> Seq.toArray
                    | _ -> [||]
                | None -> [||]

            let identifiersCfg = system.Settings.Config.GetConfig("akka.actor.serialization-identifiers")
            let opCmdSerializer = system.Serialization.FindSerializerForType(typeof<OpCmd>)
            let opResultSerializer = system.Serialization.FindSerializerForType(typeof<OpResult>)
            let listSessionsSerializer = system.Serialization.FindSerializerForType(typeof<ListSessions>)
            let sessionsSerializer = system.Serialization.FindSerializerForType(typeof<Sessions>)

            this.Log().Info("[FsiSupervisor.Serialization][{0}] identifiers={1}", label, if isNull identifiersCfg then "<null>" else identifiersCfg.ToString())
            serializersById
            |> Array.iter (fun (key, serializerType) ->
                this.Log().Info("[FsiSupervisor.Serialization][{0}] serializerId={1} type={2}", label, key, serializerType))
            this.Log().Info("[FsiSupervisor.Serialization][{0}] OpCmd -> id={1} type={2}", label, opCmdSerializer.Identifier, opCmdSerializer.GetType().AssemblyQualifiedName)
            this.Log().Info("[FsiSupervisor.Serialization][{0}] OpResult -> id={1} type={2}", label, opResultSerializer.Identifier, opResultSerializer.GetType().AssemblyQualifiedName)
            this.Log().Info("[FsiSupervisor.Serialization][{0}] ListSessions -> id={1} type={2}", label, listSessionsSerializer.Identifier, listSessionsSerializer.GetType().AssemblyQualifiedName)
            this.Log().Info("[FsiSupervisor.Serialization][{0}] Sessions -> id={1} type={2}", label, sessionsSerializer.Identifier, sessionsSerializer.GetType().AssemblyQualifiedName)
        with ex ->
            this.Log().Warning(ex, "[FsiSupervisor.Serialization][{0}] dump failed", label)


    member this.GetSessionActor(sessionName: string) =
        let normalized = normalizeSessionName sessionName
        match sessionActors.TryGetValue normalized with
        | true, actor -> actor
        | _ ->
            let actorName = toSessionActorName normalized
            let actor =
                this.ActorCtx.ActorOf(
                    Props.Create(fun () -> FsiWorkerActor(settings, storage, normalized)),
                    actorName
                )
            sessionActors.[normalized] <- actor
            if not (sessionInfoCache.ContainsKey normalized) then
                sessionInfoCache.[normalized] <-
                    { session = normalized
                      status = "starting"
                      refs = []
                      loads = []
                      searchPaths = []
                      variables = []
                      lastCheckpointId = None
                      runningSinceUtc = None }
            actor

    member this.TryGetSessionActor(sessionName: string) =
        let normalized = normalizeSessionName sessionName
        match sessionActors.TryGetValue normalized with
        | true, actor -> Some actor
        | _ -> None

    member this.ResetSessionActor(sessionName: string) =
        task {
            let normalized = normalizeSessionName sessionName

            match sessionActors.TryGetValue normalized with
            | true, actor ->
                sessionActors.Remove normalized |> ignore
                sessionInfoCache.Remove normalized |> ignore
                let! _ = actor.GracefulStop(TimeSpan.FromSeconds 5.0)
                return normalized, true
            | _ ->
                let removed = sessionInfoCache.Remove normalized
                return normalized, removed
        }

    member this.ReplyMissingSession(sessionName: string) =
        let normalized = normalizeSessionName sessionName
        let info: SessionInfo =
            { session = normalized
              status = "missing"
              refs = []
              loads = []
              searchPaths = []
              variables = []
              lastCheckpointId = None
              runningSinceUtc = None }
        this.ActorCtx.Sender.Tell(info, this.ActorCtx.Self)

    member this.SeedBusySessionInfo(msg: ExecCode) =
        let normalized = normalizeSessionName msg.session
        let previous =
            match sessionInfoCache.TryGetValue normalized with
            | true, info -> Some info
            | _ -> None
        let refs =
            if obj.ReferenceEquals(msg.refs, null) then [] else msg.refs |> List.distinct
        let loads =
            if obj.ReferenceEquals(msg.loads, null) then [] else msg.loads |> List.distinct
        sessionInfoCache.[normalized] <-
            { session = normalized
              status = "busy"
              refs = refs
              loads = loads
              searchPaths = previous |> Option.map _.searchPaths |> Option.defaultValue []
              variables = previous |> Option.map _.variables |> Option.defaultValue []
              lastCheckpointId = previous |> Option.bind _.lastCheckpointId
              runningSinceUtc = Some DateTime.UtcNow }

    member this.Initialize() =
        this.Log().Info("FsiSupervisorActor initializing")
        // Design note:
        // This eager protobuf initialization is here for the PCSL/protobuf storage stack,
        // not for Akka remoting. Remote version probes such as `GetVesion` do not need it,
        // but the supervisor currently installs PCSL during startup, so we initialize the
        // relevant protobuf runtime models first to avoid later storage failures.
        this.Log().Info("FsiSupervisorActor init step=protobuf.ensure")
        ProtoBufInit.ensureUnitSerializer ()
        this.Log().Info("FsiSupervisorActor init step=protobuf.ensure.done")
        this.Log().Info("FsiSupervisorActor init step=serialization.dump")
        this.DumpSerializationState "init"
        this.Log().Info("FsiSupervisorActor init step=serialization.dump.done")
        this.Log().Info("FsiSupervisorActor init step=create.fsifs")
        let fsActor =
            this.ActorCtx.ActorOf(Props.Create(fun () -> PcslFileSystemActor(storage, settings)), "fsifs")
        this.Log().Info("FsiSupervisorActor init step=create.fsifs.done")

        this.Log().Info("FsiSupervisorActor init step=install.pcsl")
        PcslFileSystem.install storage settings.filesystem.overlayRoots |> ignore
        this.Log().Info("FsiSupervisorActor init step=install.pcsl.done")

        this.Receive<ExecCode>(fun (msg: ExecCode) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            this.SeedBusySessionInfo msg
            this.GetSessionActor msg.session |> fun actor -> actor.Forward msg)
        |> ignore
        this.Receive<ExecCodeJson>(fun (ExecCodeJson json) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" (ExecCodeJson json))
            try
                let exec = JsonCodec.execCodeFromJson json
                this.SeedBusySessionInfo exec
                this.GetSessionActor exec.session |> fun actor -> actor.Forward exec
            with ex ->
                let ctx = this.ActorCtx
                ctx.Sender.Tell(Status.Failure ex, ctx.Self))
        |> ignore
        this.Receive<GetSessionInfo>(fun (msg: GetSessionInfo) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            let normalized = normalizeSessionName msg.session
            match sessionInfoCache.TryGetValue normalized with
            | true, info -> this.ActorCtx.Sender.Tell(info, this.ActorCtx.Self)
            | _ -> this.ReplyMissingSession msg.session)
        |> ignore
        this.Receive<ListSessions>(fun (msg: ListSessions) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            let items =
                sessionInfoCache.Values
                |> Seq.sortBy (fun info -> info.session)
                |> Seq.toList

            this.ActorCtx.Sender.Tell({ items = items }, this.ActorCtx.Self))
        |> ignore
        this.Receive<SessionCacheUpsert>(fun (msg: SessionCacheUpsert) ->
            sessionInfoCache.[msg.cachedInfo.session] <- msg.cachedInfo)
        |> ignore
        this.Receive<SessionCacheRemove>(fun (msg: SessionCacheRemove) ->
            sessionInfoCache.Remove(normalizeSessionName msg.sessionName) |> ignore)
        |> ignore
        this.Receive<OpCmd>(fun cmd ->
            let ctx = this.ActorCtx
            this.Log().Info("FsiSupervisor received OpCmd={0} sender={1}", cmd, if isNull (box ctx.Sender) then "<null>" else ctx.Sender.Path.ToString())
            match cmd with
            | GetVesion ->
                let result =
                    OpResult.fromAssembly
                        cmd
                        (Some(ctx.Self.Path.ToString()))
                        (System.Reflection.Assembly.GetExecutingAssembly())
                this.Log().Info("FsiSupervisor replying OpCmd={0} assembly={1} version={2}", cmd, result.assemblyName, defaultArg result.informationalVersion "<none>")
                ctx.Sender.Tell(result, ctx.Self))
        |> ignore
        this.ReceiveAsync<ResetSession>(fun (msg: ResetSession) ->
            let ctx = this.ActorCtx
            let senderRef = ctx.Sender

            task {
                this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
                let! normalized, existed = this.ResetSessionActor msg.session

                let result: ResetSessionResult =
                    { session = normalized
                      existed = existed
                      status = if existed then "reset" else "missing" }

                senderRef.Tell(result, ctx.Self)
            }
            :> Threading.Tasks.Task)
        |> ignore
        this.Receive<Checkpoint>(fun (msg: Checkpoint) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            this.GetSessionActor msg.session |> fun actor -> actor.Forward msg)
        |> ignore
        this.Receive<Fork>(fun (msg: Fork) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            let ctx = this.ActorCtx
            let senderRef = ctx.Sender
            let timeout = TimeSpan.FromSeconds(5.0)

            let sourceActor = this.GetSessionActor msg.fromSession
            let targetActor = this.GetSessionActor msg.newSession

            Async.Start(
                async {
                    try
                        let! checkpoint =
                            sourceActor.Ask<ExecCode>({ checkpointId = msg.checkpointId }, timeout)
                            |> Async.AwaitTask
                        targetActor.Tell({ checkpoint = checkpoint }, ctx.Self)
                        senderRef.Tell({ session = msg.newSession; id = checkpoint.id }, ctx.Self)
                    with ex ->
                        senderRef.Tell(Status.Failure ex, ctx.Self)
                }))
        |> ignore
        this.Receive<Join>(fun (msg: Join) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            let _ = this.GetSessionActor msg.parentSession

            let results =
                msg.childSessions
                |> List.choose (fun sessionName ->
                    let key = sprintf "%s/%s.json" settings.pcsl.resultsKeyspace sessionName
                    storage.TryGet key |> Option.map (fun json -> sessionName, json))

            let payload = JsonCodec.serialize results
            let id = Guid.NewGuid().ToString("N")
            storage.Put(sprintf "%s/%s.json" settings.pcsl.resultsKeyspace id, payload)
            this.ActorCtx.Sender.Tell({ id = id; session = msg.parentSession }, this.ActorCtx.Self))
        |> ignore
        this.Receive<ExecBatch>(fun (msg: ExecBatch) ->
            this.Log().Debug(sprintf "FsiSupervisor received: %A" msg)
            let ctx = this.ActorCtx
            let senderRef = ctx.Sender
            let timeout =
                msg.timeoutMs
                |> Option.defaultValue settings.timeouts.execMs
                |> float
                |> TimeSpan.FromMilliseconds

            let work =
                msg.items
                |> List.map (fun item ->
                    (this.GetSessionActor item.session).Ask<ExecResult>(item, timeout)
                    |> Async.AwaitTask)
                |> Async.Parallel

            Async.Start(
                async {
                    try
                        let! results = work
                        senderRef.Tell({ results = results |> Array.toList }, ctx.Self)
                    with ex ->
                        senderRef.Tell(Status.Failure ex, ctx.Self)
                })
        )
        |> ignore
        this.Receive<PutFile>(fun (msg: PutFile) -> fsActor.Forward msg) |> ignore
        this.Receive<GetFile>(fun (msg: GetFile) -> fsActor.Forward msg) |> ignore
        this.Receive<DeleteFile>(fun (msg: DeleteFile) -> fsActor.Forward msg) |> ignore
        this.Receive<Commit>(fun (msg: Commit) -> fsActor.Forward msg) |> ignore
        this.Receive<StartWorker>(fun (msg: StartWorker) ->
            let ctx = this.ActorCtx
            let senderRef = ctx.Sender

            try
                let assemblyPath = System.Reflection.Assembly.GetExecutingAssembly().Location
                let workingDir =
                    match Path.GetDirectoryName assemblyPath with
                    | null -> Directory.GetCurrentDirectory()
                    | path -> path

                let psi = new ProcessStartInfo()
                psi.FileName <- "dotnet"
                psi.WorkingDirectory <- workingDir
                psi.UseShellExecute <- false
                psi.CreateNoWindow <- true
                psi.ArgumentList.Add(assemblyPath)

                msg.seedNodes
                |> List.iter (fun seed ->
                    psi.ArgumentList.Add("--seed")
                    psi.ArgumentList.Add(seed))

                msg.args
                |> Option.defaultValue []
                |> List.iter psi.ArgumentList.Add

                this.Log().Info("Starting worker process: {0} {1}", psi.FileName, String.Join(" ", psi.ArgumentList))

                let proc = Process.Start(psi)

                let result =
                    if isNull proc then
                        { pid = -1; address = None }
                    else
                        { pid = proc.Id
                          address = None }

                senderRef.Tell(result, ctx.Self)
            with ex ->
                this.Log().Error(ex, "Failed to start worker process")
                senderRef.Tell({ pid = -1; address = Some ex.Message }, ctx.Self))
        |> ignore

        this.Receive<obj>(fun payload ->
            match tryExtractExecJsonFromObject payload with
            | None ->
                let payloadType =
                    if isNull payload then "<null>"
                    else payload.GetType().AssemblyQualifiedName
                this.Log().Warning("FsiSupervisor unhandled payload type={0} value={1}", payloadType, payload)
            | Some json ->
                try
                    let exec = JsonCodec.execCodeFromJson json
                    this.GetSessionActor exec.session |> fun actor -> actor.Forward exec
                with ex ->
                    let ctx = this.ActorCtx
                    ctx.Sender.Tell(Status.Failure ex, ctx.Self))

        this.Log().Info("FsiSupervisorActor ready")

/// <summary>
/// /user/fsi guardian actor ensures supervisor availability.
/// </summary>
type FsiGuardianActor(settings: SupervisorSettings, storage: IPcslStorage) as this =
    inherit ReceiveActor()

    do this.Initialize()

    member _.ActorCtx = ActorBase.Context

    member this.Initialize() =
        Logging.GetLogger(this.ActorCtx).Info("FsiGuardianActor creating supervisor")
        let supervisor =
            this.ActorCtx.ActorOf(Props.Create(fun () -> FsiSupervisorActor(settings, storage)), "supervisor")

        this.ReceiveAny(fun _ ->
            let ctx = this.ActorCtx
            ctx.Sender.Tell(supervisor, ctx.Self))
