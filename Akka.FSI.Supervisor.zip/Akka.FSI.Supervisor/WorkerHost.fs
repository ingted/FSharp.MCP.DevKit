﻿namespace Akka.FSI.Supervisor

open System
open Akka.Actor
open Akka.Configuration
open Akka.Cluster

module Cmd =
    let rec parseSeeds (args: string list) (acc: string list) =
        match args with
        | "--seed" :: value :: rest -> parseSeeds rest (value :: acc)
        | _ :: rest -> parseSeeds rest acc
        | [] -> List.rev acc

    let parse (argv: string array) =
        let args = argv |> Array.toList
        let seeds = parseSeeds args []
        seeds

module HostConfig =
    let defaultHocon =
        """
        akka {
          actor.provider = cluster
          remote.dot-netty.tcp {
            hostname = "127.0.0.1"
            port = 0
          }
          cluster.roles = ["fsi-worker"]
        }
        """

    let withSeeds (seeds: string list) =
        let baseCfg = ConfigurationFactory.ParseString(defaultHocon)
        let contractCfg =
            Akka.FSI.Contracts.ContractSerialization.configForAssemblies [ typeof<Akka.FSI.Contracts.IMessage>.Assembly ]
        contractCfg.WithFallback(baseCfg), seeds

module WorkerHost =
    [<EntryPoint>]
    let main argv =
        let seeds = Cmd.parse argv
        let config, seedList = HostConfig.withSeeds seeds
        use system = ActorSystem.Create("fsi-system", config)

        // Join cluster if seeds are provided
        if seedList.Length > 0 then
            let addresses =
                seedList
                |> List.map (fun s -> Address.Parse s)
                |> List.toArray
            Cluster.Get(system).JoinSeedNodes(addresses)

        // Start guardian/supervisor inside worker process using the same default
        // storage fallback logic as the procnode bootstrap path.
        AkkaFsiBootstrap.EnsureSupervisorWithOptions(system, Some config, None) |> ignore

        // Keep process alive until killed
        system.WhenTerminated.Wait()
        0
