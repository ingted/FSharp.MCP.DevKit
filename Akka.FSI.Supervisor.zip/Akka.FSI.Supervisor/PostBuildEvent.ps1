param(
    $assembly = "FAkka.FSI.Supervisor",
    $build = "Release"
)

$apiKeyFile =
    if ($env:NUGET_API_KEY_FILE) {
        $env:NUGET_API_KEY_FILE
    } elseif (Test-Path "/Nuget/apikey.txt") {
        "/Nuget/apikey.txt"
    } else {
        "G:\Nuget\apikey.txt"
    }

function Get-VersionFromFileName {
    param (
        [string]$fileName
    )

    if ($fileName -match '\d+(\.\d+)+') {
        return [version]$matches[0]
    } else {
        return [version]'0.0'
    }
}

function Get-LatestPackage {
    param([string]$pattern)

    Get-ChildItem $pattern |
        Sort-Object -Property LastWriteTimeUtc -Descending |
        Select-Object -First 1
}

function Get-LibPacksContent {
    $currentDir = Get-Location

    while ($currentDir -ne [System.IO.Path]::GetPathRoot($currentDir)) {
        $libPacksPath = Join-Path -Path $currentDir -ChildPath 'lib-packs.txt'
        if (Test-Path $libPacksPath) {
            return Get-Content -Path $libPacksPath -Raw
        }
        $currentDir = (Get-Item $currentDir).Parent.FullName
    }

    Write-Host "lib-packs.txt not found in any parent directory." -ForegroundColor Red
    return $null
}

Write-Host ("[PostBuild]" + $assembly + ': Current path: ' + (Get-Location).Path)

if ($build -eq "Release") {
    Set-Location ./bin/$build
    try {
        $pkg = Get-LatestPackage "$($assembly)*.nupkg"
        $apiKey = (Get-Content $apiKeyFile -Raw).Trim()
        Write-Host "<dotnet nuget push $($pkg.Name)>"
        dotnet nuget push $pkg.Name --api-key $apiKey --source https://api.nuget.org/v3/index.json --skip-duplicate

        $libPacks = Get-LibPacksContent
        if ($libPacks -and (Test-Path $libPacks)) {
            Copy-Item $pkg.FullName $libPacks -Force
        }
    }
    catch {
        Write-Host "=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+="
        Write-Host $_
        Write-Host "=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+="
    }
    finally {
        Set-Location ../..
    }
}
