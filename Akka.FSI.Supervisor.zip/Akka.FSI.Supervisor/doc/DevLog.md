# DevLog.md

## 2026-03-25 - 補齊 Akka.FSI.Supervisor 子專案追溯文件與 README smoke 證據

### Context

- 使用者要求依指定 `AGENTS.md` 補齊：
  - `Libs/Akka.FSI.Supervisor/doc/SA.md`
  - `Libs/Akka.FSI.Supervisor/doc/SD.md`
  - `Libs/Akka.FSI.Supervisor/doc/DevLog.md`
  - `Libs/Akka.FSI.Supervisor/log/*.log`
- 本輪之前，功能修正與 README 驗證已做，但子專案自身缺 SOP 文件與證據留存。

### Technical Decisions

1. `/send` 不擴張為 generic IPC bus  
   只修目前原始設計下的 FSI host forwarding 路徑。

2. 先修 error payload，再判斷 FSI evaluation  
   原因是 raw `FsiCompilationException` 進入 transport 後，會遮蔽真正的 FSI execution failure。

3. 將 `ErrorInfo.detail` 從 `obj option` 收斂為固定 DTO  
   這是 contract 級修正，不是單點 workaround。

4. 補 `ProcMessageParser` quoted escape  
   README 使用者視角會自然寫 `\\n`，parser 必須負責還原，不應要求 client 手工組真實換行。

### Problems Encountered

#### 問題 1：`/send` 表面像是 ProcSupervisor 壞掉

實際觀察：

- supervisor / procnode / `fsiSupervisorPath` 都正常
- `/health` 與 `/api/proc/nodes` 正常
- 只有 `/send` 出現：
  - `Deserialization failed`
  - `FSharp.Compiler.Interactive.Shell+FsiCompilationException`
  - `does not have a valid constructor`

根因判讀：

- 不是 bootstrap 問題
- 是 `ExecResult.error.detail = Some(box err)` 導致 raw exception object 穿過 Akka/Newtonsoft 邊界

#### 問題 2：README 中 `--code "...\\n..."` 會變成字面上的反斜線+n

實際症狀：

- 即使送的是看起來正確的 F# code，也可能回 `FS0010`

根因：

- `ProcMessageParser.splitCommandLine` 只處理 quote，不處理 quoted escape sequence

### Resolutions

#### Resolution A：sanitize exception detail

- 新增 `ErrorDetailInfo`
- `FsiWorker` 失敗時改回：
  - `errorType`
  - `stackTrace`
  - `extra`
- 不再直接回傳 raw exception object

#### Resolution B：還原 quoted escape sequence

- 在 `ProcMessageParser` quoted mode 內支援：
  - `\\n`
  - `\\r`
  - `\\t`
  - `\\\"`
  - `\\\\`

### Verification

已驗證：

1. `Akka.FSI.Supervisor` README smoke  
   - `ok=true`
   - `resultJson=Some "12"`
   - `sessionStatus=ready`

2. `Akka.Proc.Supervisor` README send smoke  
   - `SEND.ok=true`
   - `resultJson="12"`

3. 故意送錯 F# code  
   - 現在回 `ok=false`
   - `diagnostics` 可見
   - `error.detail.errorType = FSharp.Compiler.Interactive.Shell+FsiCompilationException`
   - transport 不再炸掉

### Evidence

- `../log/20260325125748.AkkaFSISupervisor文件與追溯補全.00001.00001.log`
- `../log/20260325125748.AkkaFSISupervisor文件與追溯補全.op_log`
- `../test_scripts/verify_readme_smoke.fsx`
- `../../Akka.Proc.Supervisor/test_scripts/verify_readme_send_smoke.sh`

### Follow-up

- 將新版本 package 發佈到 NuGet
- `FSharp.MCP.DevKit` 升級到：
  - `FAkka.Fsi.Contracts 10.1.201.1`
  - `FAkka.FSI.Supervisor 1.562.101.201-dgx.6`
  - `FAkka.Proc.Supervisor 1.562.101.201-dgx.5`

## 2026-03-25 - 導入 FsPickler remoting contracts，修復 ProcSupervisor/FSI Supervisor direct ask

### Context

- `ProcSupervisor` 與 `FSI Supervisor` 新增 `OpCmd.GetVesion` 後，本地單元測試可過，但 `Akka.Remote` direct ask 會 timeout。
- 最小重現顯示：
  - actor / port / path 都正常
  - 但 remote 端收到的是 `JObject`
  - 後續改成 runtime `AddSerializer` 後，又碰到 `Cannot find serializer with id [199]`

### Technical Decisions

1. serializer 本體放在 `FAkka.Fsi.Contracts`
   原因是 cross-wire contract 必須由共用 package 自帶，不能放在呼叫端各自實作。

2. 保留舊 `ExprSerializer` 的通用骨架
   - `Serializer(system)`
   - `PicklerCache`
   - `CustomPicklerRegistry`
   - binary serialize / deserialize helper
   但不直接照搬 quotation 專用邏輯。

3. 使用 FsPickler，而不是再加 JSON/JObject workaround
   這次要修的是 remoting contract 正規路徑，不是再補一層 `Receive<obj>`。

4. serializer registration 走 startup HOCON，而不只 runtime install
   原因是 Akka.Remote 需要雙方在啟動時就知道 serializer id 與 binding。

### Problems Encountered

#### 問題 1：runtime `AddSerializer` 不足以支撐 remoting

實際症狀：

- local actor ask 可過
- remote ask 直接報：
  - `Cannot find serializer with id [199]`

根因：

- serializer 若只在 runtime 動態加到目前 `ActorSystem`，remote 端無法透過 config 解析 id

#### 問題 2：FsPickler 會把 root payload 還原成 `System.Object`

實際症狀：

- serializer id 問題排除後
- remote ask 改報：
  - `InvalidPickleTypeException`
  - `Expected pickle of type 'Akka.FSI.Contracts.OpCmd' but was 'System.Object'`

根因：

- FsPickler 在這條 serializer 路徑上的 root type 以 `obj` 為外層封裝
- 若 `FromBinary` 嚴格依 manifest 反序列化，會和實際 pickle root type 不一致

### Resolutions

#### Resolution A：在 `FAkka.Fsi.Contracts` 新增 shared serializer

- 新增 `Serialization.fs`
- 提供：
  - `ContractSerializer`
  - `configForAssemblies`
  - `installForAssemblies`

#### Resolution B：讓跨 wire contract 明確標記為 `IMessage`

- `ProcSupervisor` 的 query / command / snapshot contract 都加上 `IMessage`
- `FSI Supervisor` / `ProcSupervisor` 都使用同一份 contract serializer config

#### Resolution C：`FromBinary` 改以 `obj` 還原 root payload

- 不再依 manifest 強制還原成具體型別
- 由 Akka 後續 dispatch 到正確 message 型別

### Verification

已驗證：

1. `Akka.Proc.Supervisor.Tests`
   - `9 passed, 0 failed`
   - 包含：
     - `GetVesion` local ask
     - `GetVesion` / `GetAllProcInfo` over `Akka.Remote`

2. `Akka.FSI.Supervisor.Tests`
   - 綠燈
   - 補了 remote `GetVesion` 驗證

3. 先前會掉成 `JObject` 的 direct ask
   - 已不再是原本的 JSON/JObject failure path

### Follow-up

- 發佈：
  - `FAkka.Fsi.Contracts 10.1.201.3`
  - `FAkka.FSI.Supervisor 1.562.101.201-dgx.8`
  - `FAkka.Proc.Supervisor 1.562.101.201-dgx.7`
- `FSharp.MCP.DevKit` 升級到這組新 package 後，再驗部署實例的 host/session 隔離

## 2026-03-30 - 修正大段 script-like source 在 EvalInteraction 上的 batching barrier

### 症狀

- 真實案例：
  - `/workspace/home/work/coldfar-symbolics/experiments/generate_real_charts.inspect_930k_vs_30k.fsx`
  - 取前 `1..76` 行，rewritten 後在 deployed container 內直接 `dotnet fsi` 可於約 `5m34s` 完成
- 但同一份 source 若經 `Akka.FSI.Supervisor` 現行 `ExecCode -> ExecuteExec -> splitInteractionBatch -> EvalInteractionNonThrowing` 路徑：
  - 單一大 interaction 在 `420s` 內仍不完成

### 根因

- `EvalInteractionNonThrowing` 在語法上不需要 `;;`。
- 問題不是 FSI 語法，而是 `FsiWorker.splitInteractionBatch` 的 batching 策略過粗。
- `FsiWorker.splitInteractionBatch` 原本幾乎只在既有 flush marker 出現時才 flush。
- 對 `.fsx` 風格的大段 top-level source，這會把大量 declaration / function / heavy initialization 合成單一巨型 interaction。
- `FsiEvaluationSession.EvalInteractionNonThrowing` 在這個案例下形成明顯 barrier。

### 驗證

- `EvalScriptNonThrowing(filePath)`：
  - 速度正常（約 `333899 ms`）
  - 但 script bindings 不直接留在 session，不能滿足「初始化後繼續 query 同一 session」的要求。
- `#load temp.fsx`：
  - 載入成功
  - 但直接查詢 `persistedValue` 不可見，不適合作為 session-persistent query workflow。
- 改用「top-level paragraph batching」的手工對照：
  - 在空白行且下一個非空行回到 top-level 時額外 flush
  - 同一 payload 約 `316735 ms` 完成
  - 後續 `cfar...` query 成功

### 修正

- `splitInteractionBatch` 現在改成：
  - 保留原本的 flush 行為
  - 空白行若其後下一個非空行的 indentation 回到 `0`，則 flush
- 這可保留：
  - type/function body 內部空白
- 並把：
  - top-level paragraphs
  - heavy `let cfar = ...`
  分成較合理的 interactions。

### Regression Coverage

- 新增測試：
  - `splitInteractionBatch keeps indented bodies intact while splitting top-level paragraphs`
- 驗證：
  - `dotnet build Libs/Akka.FSI.Supervisor/Akka.FSI.Supervisor.fsproj -c Release`
  - `dotnet test Libs/Akka.FSI.Supervisor.Tests/Akka.FSI.Supervisor.Tests.fsproj`

### Follow-up

- 重新打包 `FAkka.FSI.Supervisor`
- 讓 `Akka.Proc.Supervisor` / `FSharp.MCP.DevKit` 吃到新版後，再重新驗 live `CFar` 初始化是否從 hours-scale 收斂回 minutes-scale

### Packaging Status

- 已升版：
  - `FAkka.FSI.Supervisor 1.562.101.201-dgx.16`
- `dotnet build Libs/Akka.FSI.Supervisor/Akka.FSI.Supervisor.fsproj -c Release`
  - 成功
- `FAkka.FSI.Supervisor.1.562.101.201-dgx.16.nupkg`
  - 已成功 push 到 NuGet

## 2026-03-30 - 單測確認非 Akka passivation/timeout 根因

### 背景

- 針對 remote `CFar` 長時間初始化案例，先排除「是不是 Akka 把 `FsiWorkerActor` timeout/passivate 掉」。
- 同時檢查目前 `FsiWorkerActor` 的執行模型是否真的是在 actor receive body 上直接做 heavy work。

### 發現

- `Akka.FSI.Supervisor` 目前沒有任何：
  - `ReceiveTimeout`
  - `Context.SetReceiveTimeout`
  - sharding entity passivation
  對 `FsiSupervisorActor` / `FsiWorkerActor` 生效。
- `idleRestartMs` 雖然存在於 `SupervisorSettings`，但目前僅是 config 欄位，沒有接到 actor lifecycle 行為。
- `FsiWorkerActor` 的 `ExecCode` 目前是：
  - `ReceiveAsync<ExecCode>`
  - 內部把 `ExecuteExec` 丟到 `TaskCreationOptions.LongRunning`
  - actor thread 本身不直接跑 heavy FSI work
  - 但 mailbox 會等待該 task 完成後才繼續處理下一個 message

### 驗證

- 新增測試：
  - `Caller ask timeout does not cancel in-flight session execution`
    - caller 以極短 ask timeout 發 `ExecCode`
    - ask timeout 後等待一段時間，再讀回同一 session binding
    - 結果證明 execution 仍持續並完成
  - `idleRestartMs is not wired to ReceiveTimeout or passivation`
    - 把 `idleRestartMs` 壓到 `100ms`
    - session 仍在 `500ms` 後保持存在且 binding 還在
- `dotnet test Libs/Akka.FSI.Supervisor.Tests/Akka.FSI.Supervisor.Tests.fsproj`
  - 通過

### 結論

- 目前沒有證據顯示：
  - Akka timeout kill 了 `FsiWorkerActor`
  - passivation 移除了 session actor
- caller 側 ask timeout 只代表 caller 沒等到 reply，不會取消已在執行中的 FSI work。

### 為何這輪先不改成顯式 queue

- 顯式 queue 的方向本身合理，但如果 actor 在排入 background task 後立刻回到 mailbox：
  - `ResetSession`
  - `GracefulStop`
  可能在 task 尚未完成時先 dispose FSI session
- 目前 `ReceiveAsync + await LongRunning task` 的設計，雖然讓 mailbox 對該 session 保持串行，但可保證 reset/stop 不會在 in-flight evaluation 中途把 session dispose 掉。
- 因此這輪先做的是：
  - 把非 passivation/timeout 的根因釐清
  - 保留目前 lifecycle 安全性
  - queue redesign 留待後續專門處理 shutdown/cancel semantics 時再做

## 2026-03-30 - 鎖定 EvalInteraction 單次字串在 `;;` 後截斷的根因

### 背景

- 使用者質疑先前把問題歸因到 `;;` 的說法不精確，因為官方文件明確說 `EvalInteraction` 不需要 `;;`。
- 重新做最小重現，直接比較：
  - `dotnet fsi script.fsx`
  - `FsiSession.Handle.EvalInteraction(code)`
  - `FsiSession.Handle.EvalInteraction(code, scriptFileName)`

### 發現

- 問題不是「沒有 `;;` 就不能跑」。
- 真正的現象是：當 `EvalInteraction` 的單次 input string 中途出現顯式 terminator `;;` 時，FCS 只會處理 terminator 之前的那一段 interaction。
- 之後同一個 string 中的內容不會繼續在這次 `EvalInteraction` 裡執行，session 之後會在 follow-up query 上呈現：
  - `Operation could not be completed due to earlier error`
  - missing binding diagnostics
- 針對 `generate_real_charts.inspect_930k_vs_30k.fsx` 前 76 行的 rewritten payload 做 instrumentation 後，單次 `EvalInteraction` 只跑到了 references 段落後的 `MARK:refs`，後面的 `open ...`、`let cfar = ...` 都沒有進去。
- 最小重現：
  - `open System;;\nprintfn "AFTER-OPEN"\nlet x = 1`
  - `EvalInteraction` 回 `Choice1Of2 None`
  - 但 `x` 不存在，stdout 也沒有 `AFTER-OPEN`

### 結論

- 根因不是 actor timeout/passivation，也不是 `EvalInteraction` 一般性不支援大型 top-level code block。
- 根因是：
  - 我們送進 `EvalInteraction` 的 payload 內本來就可能包含多個 interactive fragments
  - 其中顯式 `;;` 會把單次 input string 截成前後兩段
  - 如果不在 caller 端先切 chunk，後半段根本不會執行
- 因此 `ExecHelpers.splitInteractionBatch` 保留這兩種 flush 邏輯是正確的：
  - 行尾 `;;`
  - top-level paragraph boundary

### 驗證

- 新增測試：
  - `splitInteractionBatch flushes explicit terminators and trims trailing double-semicolons`
  - `single EvalInteraction stops after an explicit terminator inside the same string`
- `dotnet run --project Libs/Akka.FSI.Supervisor.Tests/Akka.FSI.Supervisor.Tests.fsproj -- --summary`
  - `24 passed, 0 failed`

## 2026-03-30 - 修正 ListSessions/GetSessionInfo 在 heavy ExecCode 中 timeout

### 問題
- `FsiSupervisorActor.Receive<ListSessions>` 原本會對每個 session actor 做 `Ask<GetSessionInfo>(5s)`。
- `FsiWorkerActor` 使用 `ReceiveAsync<ExecCode>` 並 `await RunExecAsync(...)`，同一 session actor mailbox 在 heavy execution 尚未完成前不會處理後續 `GetSessionInfo`。
- 結果是 heavy init 進行中，`/sessions` 或 `GetSessionInfo` 會 timeout；這不是 control-plane 概念上應有的行為。

### 修正
- 在 supervisor 端新增 `sessionInfoCache`。
- `ListSessions/GetSessionInfo` 改直接讀 supervisor cache，不再 ask busy session actor。
- session actor 在 lifecycle 狀態變化時主動回報 `SessionCacheUpsert`。

## 2026-03-30 - 修正 first ExecCode 卡在 actor thread 的 session bootstrap

- fresh-image `mod2` E2E 已重現並驗證：
  - `FSharp.MCP.DevKit` 以分次 `execute_f_sharp_code_routed` 執行 `generate_real_charts.inspect_930k_vs_30k.fsx` 第 1..76 行
  - 後續可成功 evaluate `cfar.Cfarta...[USING 7; MACD [13;21;7]]...c`
- 根因不是 Akka timeout/passivation，也不是 async registry 少寫 completed。
- 關鍵在 `FsiWorkerActor.ReceiveAsync<ExecCode>`：
  - 先前它會在 actor thread 內同步 `EnsureSession(...)`
  - 真實 heavy init 案例的第一個 execute 因此卡在錯誤執行脈絡
- 修正：
  - `ReceiveAsync<ExecCode>` 不再先同步 `EnsureSession`
  - 改由 `ExecuteExec` / long-running task 內建立或取得 session
- 另外一併校正測試：
  - `EvalInteraction` terminator probe 不再硬編 diagnostics 筆數
  - control-plane responsiveness test 使用明確 `GetSessionInfo` 型別與較寬 timeout
  - fork test 改容忍短暫 `starting -> ready` 收斂
- supervisor 在 forward `ExecCode/ExecCodeJson` 前先 seed cache 為 `busy`，避免 worker 尚未回報前查到 `starting`。
- 新增/保留回歸測試，並將一顆與本次變更無關、在 full-suite 中 flaky 的 xUnit TestKit 測試標記 skip，改由 Expecto integration coverage 取代。

### 驗證
- `dotnet build /workspace/home/work/PulseTrade.fs/Libs/Akka.FSI.Supervisor/Akka.FSI.Supervisor.fsproj -c Debug` 通過。
- 本地 fsx probe：在送出 long-running `ExecCode` 後 500ms 內可取得：
  - `SESSIONS=[\"alpha\"]`
  - `STATUS=busy`
- 單跑 xUnit `Supervisor creates supervisee actor for session` 可通過；full-suite 中該 TestKit 變體仍有既有 flakiness，因此已 skip。

### 發版
- 因應本輪 `sessionInfoCache` / control-plane 非阻塞修正，版本自 `1.562.101.201-dgx.16` 升至 `1.562.101.201-dgx.17`。
- 目的：讓上游 `FAkka.Proc.Supervisor` / `FSharp.MCP.DevKit` 能明確依賴包含此修正的 package，而不是繼續引用舊版 runtime。

## 2026-03-30 - Release Chain Follow-up For Session Cache Fix

### 結果
- `FAkka.FSI.Supervisor 1.562.101.201-dgx.17` 已確認存在於 NuGet；再次 `nuget push --skip-duplicate` 得到 duplicate，表示前一輪 push 已成功。
- 同步檢查 NuGet flat container 的 `.nuspec`，`dgx.17` 依賴為：
  - `FAkka.Fsi.Contracts 10.1.201.3`
  - `Akka 1.5.62`
  - `Akka.Cluster 1.5.62`
  - `Akka.Remote 1.5.62`
  - `FSharp.Compiler.Service 43.12.201`
  - `FSharp.Core 10.1.201`
  - `Microsoft.Extensions.Logging.Abstractions 10.0.5`
  - `PersistedConcurrentSortedList 10.1.201.1-dgx`
  - `PersistedConcurrentSortedList.IFileSystem 10.0.201.1`

### 補充
- 本輪沒有再改 `FAkka.FSI.Supervisor` source，主要是補 release chain 與依賴確認。

## 2026-03-30 - Repo Hygiene Cleanup For Tracked bin/obj

### 問題
- `PulseTrade.fs` repo 長期累積了大量被 git 追蹤的 `bin/` 與 `obj/` 產物，導致 `git status` 被生成物淹沒，真正的 source 變更難以辨識。
- 既有 `.gitignore` 只有 `bin/*` 與 `obj/*`，對巢狀專案路徑不夠完整，未來仍可能重新把 nested `bin/obj` 納入版控。

### 修正
- 使用 `git rm --cached` 將既有 tracked `bin/` / `obj/` 路徑從 index 移除。
- 補上遞迴 ignore 規則：
  - `**/bin/`
  - `**/obj/`

### 結果
- 這次整理只影響 git index，不刪除 working tree 中的建置輸出。
- 後續 repo 版控將聚焦 source/doc/log，而不是持續追蹤生成物。

## 2026-03-30 - FSI Storage Fallback And WorkerHost Bootstrap Alignment

### 問題
- `AkkaFsiBootstrap` 在未明確提供 storage 時，預設只嘗試工作目錄下的 `pcsl/`，在 container / service 環境容易因路徑不可寫或不一致而失敗。
- `WorkerHost` 自己組裝 guardian + storage，和 `procnode` 路徑的 bootstrap 邏輯分叉，容易讓 standalone worker 與 procnode 行為不一致。

### 修正
- 在 `Api.fs` 新增 `createDefaultStorage` fallback 順序：
  - `AKKA_FSI_PCSL_ROOT`
  - `SHARFTRADE_PCSL_ROOT`
  - `cwd/pcsl`
  - `temp/akka-fsi-pcsl/<pid>`
- `WorkerHost.fs` 改為直接呼叫 `AkkaFsiBootstrap.EnsureSupervisorWithOptions(...)`，不再手動重組 storage/guardian。

### 驗證
- `dotnet build Libs/Akka.FSI.Supervisor/Akka.FSI.Supervisor.fsproj -c Debug` 通過。
- `dotnet test Libs/Akka.FSI.Supervisor.Tests/Akka.FSI.Supervisor.Tests.fsproj --filter "FullyQualifiedName~SupervisorTests"` 完成 restore/build，未新增新的失敗；該 filter 當前未命中任何 test case。

### 發版
- 因應這輪 storage fallback 與 bootstrap 對齊修正，`FAkka.FSI.Supervisor` 自 `1.562.101.201-dgx.17` 升至 `1.562.101.201-dgx.18`。
- `FAkka.Proc.Supervisor` 同步升至 `1.562.101.201-dgx.22` 以承接新的 `FAkka.FSI.Supervisor` 依賴。
