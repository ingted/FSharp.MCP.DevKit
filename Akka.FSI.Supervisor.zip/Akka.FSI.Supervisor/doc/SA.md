# SA.md

## 範圍

- 專案：`Libs/Akka.FSI.Supervisor`
- 關聯元件：
  - `Libs/FAkka.Fsi.Contracts`
  - `Libs/Akka.Proc.Supervisor`
- 本輪主題：
  - 補齊 `Akka.FSI.Supervisor` 子專案的 SA/SD/DevLog 與 log 證據
  - 記錄本輪實際完成的 `/send` 穩定化修正與 README smoke 驗證

## 現況分析

`Akka.FSI.Supervisor` 的執行骨架已存在且可用：

- `FsiGuardianActor` 提供固定入口
- `FsiSupervisorActor` 管理 session actor 與高階 API
- `FsiWorkerActor` 實際持有單一 `FsiSession.Handle`
- `FsiSession.Handle` 封裝 `FsiEvaluationSession`
- `Api.fs` 提供 `AkkaFsiBootstrap` helper

本輪分析聚焦的現況缺口不是 actor lifecycle，而是 cross-boundary contract：

1. `FsiWorker.HandleExec` 在失敗時會把 raw `exn` 放進 `ExecResult.error.detail`
2. `ProcSupervisor` 的 `/send` 會把 `ExecResult` 經 Akka remote / JSON 邊界回送
3. 當 detail 內出現 `FSharp.Compiler.Interactive.Shell.FsiCompilationException` 時，`Newtonsoft.Json` 無法反序列化該例外型別
4. 結果表面症狀是 `/send` 卡住或回 500，但真正壞的是 error payload serialization safety

## 已確認事實

### FSI 執行鏈

- `FsiWorker.HandleExec` 會呼叫 `session.EvalInteraction`
- 成功時回 `ExecResult.ok = true`
- 失敗時回 `ExecResult.ok = false` 並帶：
  - `stdout`
  - `stderr`
  - `diagnostics`
  - `error`

### 問題起點

- 舊實作把 `err` 直接以 `Some(box err)` 放進 `ErrorInfo.detail`
- 這使 `ExecResult` 雖然在同 process 內可用，但跨 actor / REST transport 時不安全

### `/send` 的原始設計邊界

- `/api/proc/nodes/{procId}/send` 是 `Akka.Proc.Supervisor` 的 REST API
- 但語意上不是 generic process IPC
- 它的原始設計是：
  - `ProcSupervisor` 接收字串命令
  - `ProcMessageParser` 解析成 `Akka.FSI.Contracts` 訊息
  - 再轉發到 child proc 內的 `fsiSupervisorPath`
- 因此 `/send` 的成功前提本來就包含「目標 proc 是 FSI host」

## 風險與根因判讀

### 根因 1：錯誤 detail 不可安全序列化

- 根因類型：contract design flaw
- 具體症狀：
  - `Deserialization failed`
  - `FSharp.Compiler.Interactive.Shell+FsiCompilationException`
  - `does not have a valid constructor`
- 判讀：
  - 問題不在 bootstrap procnode 是否活著
  - 問題也不是 `/send` 本身的 REST surface
  - 問題在 `ExecResult.error.detail` 攜帶了不適合跨 transport 的 raw exception object

### 根因 2：README / parser 對多行 code 的 escape 規則不完整

- README 範例用：
  - `--code "let add a b = a + b\nadd 5 7"`
- 但舊 `ProcMessageParser.splitCommandLine` 不會把 quoted `\\n` 還原成真正換行
- 因此即使是正確 F# 程式，仍會以字面上的 `\n` 進 FSI，導致 `FS0010`

## 本輪修正策略

1. 不改 `/send` 的語意，不把它擴張為 generic IPC bus
2. 先修 `Akka.FSI.Supervisor` / contracts：
   - error payload 改成 JSON-safe DTO
3. 再修 `Akka.Proc.Supervisor` parser：
   - 在 quotes 內支援 `\\n`、`\\r`、`\\t`、`\\\"`、`\\\\`
4. 最後以 README smoke 實測：
   - 成功腳本
   - 故意失敗腳本

## 驗證結論

- `Akka.FSI.Supervisor` README smoke：可通
- `Akka.Proc.Supervisor` README `start-default -> send -> stop`：可通
- 故意送壞的 F# code：現在回乾淨的 `ExecResult.ok = false`，不再炸 transport

## 關聯

- `doc/SD.md`
- `doc/DevLog.md`
- `../log/20260325125748.AkkaFSISupervisor文件與追溯補全.00001.00001.log`
