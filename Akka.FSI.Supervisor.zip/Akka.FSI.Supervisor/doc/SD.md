# SD.md

## 設計目標

本輪設計不是重做 actor 架構，而是修正兩個跨邊界穩定性缺口：

1. `ExecResult.error.detail` 必須是 transport-safe
2. `ProcMessageParser` 必須能把 README 所示的 escaped multiline code 正確還原

## 既有結構

### `Akka.FSI.Supervisor`

- `FsiGuardianActor`
- `FsiSupervisorActor`
- `FsiWorkerActor`
- `FsiSession.Handle`
- `AkkaFsiBootstrap`

### `Akka.Proc.Supervisor`

- `ProcRest` 提供 `/send`
- `ProcMessageParser` 把字串轉成 `Akka.FSI.Contracts` 訊息
- `ProcSupervisorActor` / sharded proc node actor 把訊息轉發到 `fsiSupervisorPath`

## 新資料契約

### 舊設計

```fsharp
type ErrorInfo =
    { code: string
      message: string
      detail: obj option }
```

問題：

- `obj option` 缺乏邊界保證
- raw exception object 可能不可 JSON 序列化 / 反序列化
- transport 層會被 error payload 反向污染

### 新設計

```fsharp
type ErrorDetailInfo =
    { errorType: string option
      stackTrace: string option
      extra: string option }

type ErrorInfo =
    { code: string
      message: string
      detail: ErrorDetailInfo option }
```

設計理由：

- `errorType` 保留型別訊息，利於判讀
- `stackTrace` 保留除錯訊息，但仍為純字串
- `extra` 用於 domain-specific 補充，例如：
  - `"FCS compilation exception"`

## `FsiWorker` 錯誤轉換

### 舊流程

```fsharp
| Choice2Of2 err ->
    error = toError "ExecutionError" err.Message (Some(box err))
```

### 新流程

```fsharp
let sanitizeErrorDetail (err: exn) =
    Some
        { errorType = err.GetType().FullName |> Option.ofObj
          stackTrace = err.StackTrace |> Option.ofObj
          extra =
            match err with
            | :? FsiCompilationException -> Some "FCS compilation exception"
            | _ -> None }

| Choice2Of2 err ->
    error = toError "ExecutionError" err.Message (sanitizeErrorDetail err)
```

效果：

- FSI failure 仍完整回報
- 但 transport 不再攜帶 raw exception object

## `ProcMessageParser` quoted escape 設計

### 需求

README 與 REST client 通常會用：

```text
exec --session mysession --code "let add a b = a + b\nadd 5 7"
```

舊 parser 只做簡單 quote split，沒有 escape 還原，導致：

- `\n` 仍是兩個字元 `\` + `n`
- FSI 收到錯誤 source text

### 新規則

在 quoted mode 下支援：

- `\\n` -> newline
- `\\r` -> carriage return
- `\\t` -> tab
- `\\\"` -> `"`
- `\\\\` -> `\`

### 作用範圍

- 只在 `inQuotes` 時處理 escape
- 不變更 `/send` 的命令語意
- 不引入 generic transport 概念

## README smoke 設計

### FSI Supervisor smoke

檔案：

- `test_scripts/verify_readme_smoke.fsx`

流程：

1. 設定 `PROTOBUF_FSHARP_DLL`
2. `#r` 載入 contracts / supervisor / PCSL filesystem dll
3. 建立 `ActorSystem`
4. `EnsureSupervisor`
5. 執行：

```fsharp
let add a b = a + b
add 5 7
```

6. 驗證：
   - `ok = true`
   - `resultJson = Some "12"`
   - `sessionStatus = ready`

### Proc Supervisor smoke

檔案：

- `../Akka.Proc.Supervisor/test_scripts/verify_readme_send_smoke.sh`

流程：

1. `dotnet exec ... Akka.Proc.Supervisor.dll --mode supervisor --spawnnone`
2. `POST /api/proc/nodes/start-default`
3. `GET /api/proc/nodes`
4. `POST /send` with escaped multiline F#
5. `POST /stop`
6. 驗證：
   - `SEND.ok = true`
   - `resultJson = "12"`

## 回退策略

若下游 consumer 尚未升到新 contracts：

- 舊版 package 仍維持舊 `ErrorInfo.detail`
- 本輪 package version 已升版，避免 silent breaking change

## 版本影響

本輪版本調整：

- `FAkka.Fsi.Contracts` -> `10.1.201.1`
- `FAkka.FSI.Supervisor` -> `1.562.101.201-dgx.6`
- `FAkka.Proc.Supervisor` -> `1.562.101.201-dgx.5`

## 關聯

- `doc/SA.md`
- `doc/DevLog.md`
- `../test_scripts/verify_readme_smoke.fsx`
- `../../Akka.Proc.Supervisor/test_scripts/verify_readme_send_smoke.sh`
