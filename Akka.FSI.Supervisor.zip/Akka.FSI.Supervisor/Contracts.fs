namespace Akka.FSI.Contracts

open System
open System.Runtime.CompilerServices

[<IsReadOnly; Struct>]
type RangeLite =
    { file: string
      startLine: int
      startCol: int
      endLine: int
      endCol: int }

[<IsReadOnly; Struct>]
type DiagnosticInfo =
    { severity: string
      code: string option
      message: string
      range: RangeLite option }

[<IsReadOnly; Struct>]
type ErrorInfo =
    { code: string
      message: string
      detail: obj option }

type IMessage = interface end

[<CLIMutable>]
type ExecCode =
    { id: string
      session: string
      code: string
      refs: string list
      loads: string list
      args: string list option
      timeoutMs: int option
      captureStdout: bool option }

    interface IMessage

[<CLIMutable>]
type ExecResult =
    { id: string
      ok: bool
      resultJson: string option
      stdout: string
      stderr: string
      diagnostics: DiagnosticInfo list
      elapsedMs: int64
      session: string
      error: ErrorInfo option }

    interface IMessage

type ExecCodeJson =
    | ExecCodeJson of json: string

    interface IMessage

type ExecResultJson =
    | ExecResultJson of json: string

    interface IMessage

[<CLIMutable>]
type GetSessionInfo =
    { session: string }

    interface IMessage

[<CLIMutable>]
type SessionInfo =
    { session: string
      status: string
      refs: string list
      loads: string list
      searchPaths: string list
      variables: (string * string) list
      lastCheckpointId: string option
      runningSinceUtc: DateTime option }

    interface IMessage

[<CLIMutable>]
type ListSessions =
    { all: bool }

    interface IMessage

[<CLIMutable>]
type Sessions =
    { items: SessionInfo list }

    interface IMessage

[<CLIMutable>]
type PutFile =
    { path: string
      content: string
      encoding: string option }

    interface IMessage

[<CLIMutable>]
type DeleteFile =
    { path: string }

    interface IMessage

[<CLIMutable>]
type Commit =
    { keyspace: string
      comment: string option }

    interface IMessage

[<CLIMutable>]
type GetFile =
    { path: string }

    interface IMessage

[<CLIMutable>]
type FileContent =
    { path: string
      content: string option }

    interface IMessage

[<CLIMutable>]
type Checkpoint =
    { session: string
      id: string option
      comment: string option }

    interface IMessage

[<CLIMutable>]
type CheckpointResult =
    { session: string
      id: string }

    interface IMessage

[<CLIMutable>]
type Fork =
    { fromSession: string
      newSession: string
      checkpointId: string option }

    interface IMessage

[<CLIMutable>]
type Join =
    { parentSession: string
      childSessions: string list
      reducer: string option }

    interface IMessage

[<CLIMutable>]
type FileRecord =
    { path: string
      content: string
      timestampUtc: DateTime }

    interface IMessage

[<CLIMutable>]
type StartWorker =
    { seedNodes: string list
      args: string list option }

    interface IMessage

[<CLIMutable>]
type WorkerStarted =
    { pid: int
      address: string option }

    interface IMessage

[<CLIMutable>]
type ExecBatch =
    { items: ExecCode list
      timeoutMs: int option }

    interface IMessage

[<CLIMutable>]
type ExecBatchResult =
    { results: ExecResult list }

    interface IMessage
