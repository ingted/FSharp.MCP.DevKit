namespace Akka.FSI.Supervisor

open Akka.FSI.Contracts
open System
open System.Collections.Generic
open System.Diagnostics
open System.Text
open Akka.Actor
open Akka.Event
open FSharp.Compiler.Diagnostics
open FSharp.Compiler.Interactive.Shell
open PersistedConcurrentSortedList.IFileSystem
open System.Threading
open System.Threading.Tasks

module ExecHelpers =
    let combineSource (refs: string list) (loads: string list) (code: string) =
        let builder = StringBuilder()

        refs
        |> List.distinct
        |> List.iter (fun r -> builder.AppendLine(sprintf "#r \"%s\"" r) |> ignore)

        loads
        |> List.distinct
        |> List.iter (fun l -> builder.AppendLine(sprintf "#load \"%s\"" l) |> ignore)

        builder.AppendLine(code) |> ignore
        builder.ToString()

    let diagnosticsToContract (diagnostics: FSharpDiagnostic array) = FsiSession.diagnostics diagnostics

    let normalizeSessionName (name: string) =
        if String.IsNullOrWhiteSpace name then "default" else name

    let toSessionActorName (name: string) =
        // Design: session name is the routing key; if not GUID, UI uses actor path to disambiguate.
        let normalized = normalizeSessionName name
        let safe =
            normalized
            |> Seq.map (fun ch ->
                if Char.IsLetterOrDigit ch || ch = '-' || ch = '_' then ch else '_')
            |> Seq.toArray
            |> String
        "session-" + safe

    let toError code message detail =
        Some
            { code = code
              message = message
              detail = detail }

    let splitInteractionBatch (code: string) =
        let normalized =
            if isNull code then
                String.Empty
            else
                code.Replace("\r\n", "\n").Replace('\r', '\n')

        let lines = normalized.Split('\n')
        let chunks = ResizeArray<string>()
        let current = ResizeArray<string>()

        let hasMeaningfulContent () =
            current |> Seq.exists (fun line -> not (String.IsNullOrWhiteSpace line))

        let indentationLevel (line: string) =
            line
            |> Seq.takeWhile (fun ch -> ch = ' ' || ch = '\t')
            |> Seq.length

        let nextNonEmptyIndentation startIndex =
            let mutable index = startIndex
            let mutable result = None

            while index < lines.Length && result.IsNone do
                let candidate = lines[index]

                if not (String.IsNullOrWhiteSpace candidate) then
                    result <- Some(indentationLevel candidate)

                index <- index + 1

            result

        let flush () =
            let chunk =
                current
                |> Seq.toArray
                |> String.concat "\n"
                |> fun value ->
                    let trimmed = value.Trim()
                    if trimmed.EndsWith(";;", StringComparison.Ordinal) then
                        trimmed.Substring(0, trimmed.Length - 2).TrimEnd()
                    else
                        trimmed

            current.Clear()

            if not (String.IsNullOrWhiteSpace chunk) then
                chunks.Add(chunk)

        for index, line in lines |> Array.indexed do
            current.Add(line)

            if line.TrimEnd().EndsWith(";;", StringComparison.Ordinal) then
                flush ()
            elif String.IsNullOrWhiteSpace line then
                match nextNonEmptyIndentation (index + 1) with
                | Some 0 when hasMeaningfulContent () -> flush ()
                | _ -> ()

        flush ()
        chunks |> Seq.toList

    let sanitizeErrorDetail (err: exn) =
        Some
            { errorType = err.GetType().FullName |> Option.ofObj
              stackTrace = err.StackTrace |> Option.ofObj
              extra =
                match err with
                | :? FsiCompilationException ->
                    Some "FCS compilation exception"
                | _ -> None }

open ExecHelpers

type GetCheckpointEntry =
    { checkpointId: string option }

type ApplyCheckpointEntry =
    { checkpoint: ExecCode }

type internal SessionCacheUpsert =
    { cachedInfo: SessionInfo }

type internal SessionCacheRemove =
    { sessionName: string }

/// <summary>
/// Per-session actor that owns a single FSI session instance.
/// </summary>
type FsiWorkerActor(settings: SupervisorSettings, storage: IPcslStorage, sessionName: string) as this =
    inherit ReceiveActor()

    let sessionName = normalizeSessionName sessionName
    let mutable session: FsiSession.Handle option = None
    let checkpoints = Dictionary<string, ExecCode>(StringComparer.OrdinalIgnoreCase)

    do this.Initialize()

    member _.ActorCtx = ActorBase.Context

    member this.Log() = Logging.GetLogger(this.ActorCtx)

    member this.Reply<'T>(msg: 'T) =
        let ctx = this.ActorCtx
        ctx.Sender.Tell(msg, ctx.Self)

    member _.EnsureSession (logger: ILoggingAdapter, argv: string array option) =
        match session with
        | Some handle -> handle
        | None ->
            logger.Info("Starting FSI session {0}", sessionName)
            let handle = new FsiSession.Handle(sessionName, ?argv = argv)
            session <- Some handle
            handle

    member _.TryCaptureItValue(logger: ILoggingAdapter, handle: FsiSession.Handle) : string option =
        let rec unwrap (value: obj) =
            match value with
            | :? FSharp.Compiler.Interactive.Shell.FsiValue as fsiValue -> unwrap fsiValue.ReflectionValue
            | _ -> value

        let serializeValue (value: obj) =
            let unwrapped = unwrap value
            try
                JsonCodec.serialize unwrapped |> Some
            with _ ->
                unwrapped.ToString() |> JsonCodec.serialize |> Some

        let boundIt =
            handle.RawSession.GetBoundValues()
            |> Seq.tryFind (fun b -> String.Equals(b.Name, "it", StringComparison.Ordinal))

        match boundIt with
        | Some bound -> serializeValue bound.Value
        | None ->
            let choice, _ = handle.EvalExpression "fsi_it"

            match choice with
            | Choice1Of2(Some value) -> serializeValue value.ReflectionValue
            | Choice1Of2 None ->
                logger.Debug("fsi_it evaluation returned None")
                None
            | Choice2Of2 err ->
                logger.Debug("fsi_it evaluation failed: {0}", err.Message)
                None

    member this.WriteResultToStorage(result: ExecResult) =
        let path = sprintf "%s/%s.json" settings.pcsl.resultsKeyspace result.id
        storage.Put(path, JsonCodec.execResultToJson result)

    member this.ExecuteExec(logger: ILoggingAdapter, msg: ExecCode) =
        let sw = Stopwatch.StartNew()
        let safeArgs =
            if obj.ReferenceEquals(msg.args, null) then None else msg.args
        let session = this.EnsureSession (logger, safeArgs |> Option.map List.toArray)
        session.ResetBuffers()
        session.Runtime.Status <- "busy"
        let safeRefs =
            if obj.ReferenceEquals(msg.refs, null) then [] else msg.refs
        let safeLoads =
            if obj.ReferenceEquals(msg.loads, null) then [] else msg.loads
        let refs = safeRefs |> List.distinct
        let loads = safeLoads |> List.distinct
        session.UpdateRefs refs loads
        let code = if isNull msg.code then "" else msg.code
        let source = combineSource refs loads code
        let diagnostics = ResizeArray<FSharpDiagnostic>()
        let mutable lastError : exn option = None
        let chunks = splitInteractionBatch source

        for index, chunk in chunks |> List.indexed do
            if lastError.IsNone then
                let choice, currentDiagnostics = session.EvalInteraction chunk
                diagnostics.AddRange(currentDiagnostics)

                match choice with
                | Choice1Of2 _ -> ()
                | Choice2Of2 err -> lastError <- Some err

        let stdout = session.StdoutText()
        let stderr = session.StderrText()
        let elapsed = sw.ElapsedMilliseconds

        match lastError with
        | None ->
            session.Runtime.Status <- "ready"
            session.RefreshVariables()

            let result =
                { id = msg.id
                  ok = true
                  resultJson = this.TryCaptureItValue(logger, session)
                  stdout = stdout
                  stderr = stderr
                  diagnostics = diagnostics.ToArray() |> diagnosticsToContract
                  elapsedMs = elapsed
                  session = sessionName
                  error = None }

            if settings.pcsl.autoCommit then
                this.WriteResultToStorage result

            result
        | Some err ->
            session.Runtime.Status <- "faulted"

            let result =
                { id = msg.id
                  ok = false
                  resultJson = None
                  stdout = stdout
                  stderr = stderr
                  diagnostics = diagnostics.ToArray() |> diagnosticsToContract
                  elapsedMs = elapsed
                  session = sessionName
                  error = toError "ExecutionError" err.Message (sanitizeErrorDetail err) }

            session.Runtime.Status <- "ready"
            result

    member this.RunExecAsync(logger: ILoggingAdapter, msg: ExecCode) =
        Task.Factory.StartNew(
            Func<ExecResult>(fun () -> this.ExecuteExec(logger, msg)),
            CancellationToken.None,
            TaskCreationOptions.LongRunning,
            TaskScheduler.Default)

    member this.HandleExecJson(logger: ILoggingAdapter, ExecCodeJson json) =
        let msg = JsonCodec.execCodeFromJson json
        this.ExecuteExec(logger, msg)

    member _.GetSearchPaths(_session: FsiSession.Handle) = []

    member this.CurrentSessionInfo() =
        match session with
        | Some session ->
            { session = sessionName
              status = session.Runtime.Status
              refs = session.Runtime.Refs
              loads = session.Runtime.Loads
              searchPaths = this.GetSearchPaths session
              variables = session.Runtime.Variables
              lastCheckpointId = session.Runtime.LastCheckpointId
              runningSinceUtc = session.Runtime.RunningSinceUtc }
        | None ->
            { session = sessionName
              status = "missing"
              refs = []
              loads = []
              searchPaths = []
              variables = []
              lastCheckpointId = None
              runningSinceUtc = None }

    member this.PublishSessionInfo() =
        this.ActorCtx.Parent.Tell({ cachedInfo = this.CurrentSessionInfo() }, this.ActorCtx.Self)

    member this.PublishSessionInfoTo(parentRef: IActorRef, selfRef: IActorRef) =
        parentRef.Tell({ cachedInfo = this.CurrentSessionInfo() }, selfRef)

    member this.HandleGetSession() =
        this.Reply(this.CurrentSessionInfo())

    member this.HandleCheckpoint(msg: Checkpoint) =
        let session = this.EnsureSession(this.Log(), None)

        let checkpointId =
            match msg.id with
            | Some id -> id
            | None -> Guid.NewGuid().ToString("N")

        checkpoints[checkpointId] <-
            { id = checkpointId
              session = sessionName
              code = ""
              refs = session.Runtime.Refs
              loads = session.Runtime.Loads
              args = None
              timeoutMs = None
              captureStdout = None }

        session.ApplyCheckpoint(Some checkpointId)
        storage.Put(sprintf "%s/%s/%s.json" settings.pcsl.snapshotsKeyspace sessionName checkpointId, "{}")
        this.PublishSessionInfo()

        this.Reply
            { session = sessionName
              id = checkpointId }

    member this.HandleGetCheckpointEntry(msg: GetCheckpointEntry) =
        match session with
        | None ->
            let ex = Exception(sprintf "Session %s is missing" sessionName)
            this.ActorCtx.Sender.Tell(Status.Failure ex, this.ActorCtx.Self)
        | Some handle ->
            let checkpointId =
                match msg.checkpointId with
                | Some id -> id
                | None ->
                    match handle.Runtime.LastCheckpointId with
                    | Some id -> id
                    | None -> String.Empty

            match checkpointId with
            | "" ->
                let ex = Exception(sprintf "Session %s has no checkpoint" sessionName)
                this.ActorCtx.Sender.Tell(Status.Failure ex, this.ActorCtx.Self)
            | _ ->
                match checkpoints.TryGetValue checkpointId with
                | true, entry ->
                    this.ActorCtx.Sender.Tell(entry, this.ActorCtx.Self)
                | _ ->
                    let ex = Exception(sprintf "Checkpoint %s not found" checkpointId)
                    this.ActorCtx.Sender.Tell(Status.Failure ex, this.ActorCtx.Self)

    member this.HandleApplyCheckpointEntry(msg: ApplyCheckpointEntry) =
        let session = this.EnsureSession(this.Log(), None)
        session.UpdateRefs msg.checkpoint.refs msg.checkpoint.loads
        session.Runtime.Status <- "ready"
        this.PublishSessionInfo()

    member this.Initialize() =
        // Design:
        // - ExecCode is evaluated on a dedicated long-running task so the actor thread itself
        //   is not performing the heavy FSI work.
        // - We intentionally keep the ReceiveAsync handler awaiting that task instead of
        //   immediately queueing-and-returning. This preserves current lifecycle semantics:
        //   session reset/stop will wait for the in-flight execution rather than disposing
        //   the FSI session underneath a still-running evaluation task.
        // - A true actor-side queue is possible, but it needs coordinated shutdown/cancel
        //   behavior across ResetSession/GracefulStop before it is safe to adopt.
        this.ReceiveAsync<ExecCode>(fun msg ->
            let senderRef = this.ActorCtx.Sender
            let selfRef = this.ActorCtx.Self
            let parentRef = this.ActorCtx.Parent
            let logger = this.Log()
            logger.Debug(sprintf "FsiWorker received: %A" msg)

            task {
                try
                    let! result = this.RunExecAsync(logger, msg)
                    this.PublishSessionInfoTo(parentRef, selfRef)
                    senderRef.Tell(result, selfRef)
                with ex ->
                    this.PublishSessionInfoTo(parentRef, selfRef)
                    senderRef.Tell(Status.Failure ex, selfRef)
            }
            :> Task)
        |> ignore
        this.ReceiveAsync<ExecCodeJson>(fun msg ->
            let senderRef = this.ActorCtx.Sender
            let selfRef = this.ActorCtx.Self
            let logger = this.Log()
            logger.Debug(sprintf "FsiWorker received: %A" msg)

            task {
                try
                    let result = this.HandleExecJson(logger, msg)
                    senderRef.Tell(result, selfRef)
                with ex ->
                    senderRef.Tell(Status.Failure ex, selfRef)
            }
            :> Task)
        |> ignore
        this.Receive<GetSessionInfo>(fun _ -> this.HandleGetSession()) |> ignore
        this.Receive<Checkpoint>(fun msg -> this.HandleCheckpoint msg) |> ignore
        this.Receive<GetCheckpointEntry>(fun msg -> this.HandleGetCheckpointEntry msg) |> ignore
        this.Receive<ApplyCheckpointEntry>(fun msg -> this.HandleApplyCheckpointEntry msg) |> ignore

    override _.PostStop() =
        session
        |> Option.iter (fun handle ->
            (handle :> IDisposable).Dispose())
