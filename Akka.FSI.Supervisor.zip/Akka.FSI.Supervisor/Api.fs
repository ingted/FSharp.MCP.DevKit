﻿namespace Akka.FSI.Supervisor

open System
open Akka.Actor
open Akka.Event
open Akka.Configuration
open Akka.FSI.Contracts
open PersistedConcurrentSortedList.IFileSystem

module AkkaFsiBootstrap =
    let supervisorPath = "/user/fsi/supervisor"

    let private tryCreateStorage (root: string) =
        try
            let storage = PcslStorage.pcsl2 root "fsi"
            Ok storage
        with ex ->
            Result.Error ex

    let private createDefaultStorage (system: ActorSystem) =
        let cwdRoot = IO.Path.Combine(IO.Directory.GetCurrentDirectory(), "pcsl")
        let tempRoot =
            IO.Path.Combine(
                IO.Path.GetTempPath(),
                "akka-fsi-pcsl",
                string Environment.ProcessId)

        let candidates =
            [ Environment.GetEnvironmentVariable("AKKA_FSI_PCSL_ROOT")
              Environment.GetEnvironmentVariable("SHARFTRADE_PCSL_ROOT")
              cwdRoot
              tempRoot ]
            |> List.choose (fun path ->
                if String.IsNullOrWhiteSpace path then None else Some path)

        let rec loop paths lastError =
            match paths with
            | [] ->
                match lastError with
                | Some ex -> raise ex
                | None -> failwith "No writable PCSL root could be resolved."
            | root :: rest ->
                match tryCreateStorage root with
                | Ok storage ->
                    if root <> cwdRoot then
                        system.Log.Warning(
                            "Using fallback PCSL root '{Root}' instead of working-directory storage '{WorkingDirectoryRoot}'.",
                            root,
                            cwdRoot)

                    storage
                | Error ex ->
                    system.Log.Warning(
                        "PCSL root '{0}' is unavailable; trying next fallback. Reason: {1}",
                        root,
                        ex.Message)

                    loop rest (Some ex)

        loop candidates None

    let ensureGuardian (system: ActorSystem) (settings: SupervisorSettings) (storage: IPcslStorage) =
        let guardianPath = "/user/fsi"
        let selection = system.ActorSelection guardianPath

        let resolved =
            try
                selection.ResolveOne(TimeSpan.FromMilliseconds(200.0)).Result |> Some
            with _ ->
                None

        match resolved with
        | Some actor -> actor
        | None -> system.ActorOf(Props.Create(fun () -> FsiGuardianActor(settings, storage)), "fsi")

    let resolveSupervisor (system: ActorSystem) =
        async {
            let selection = system.ActorSelection supervisorPath

            try
                let! actor = selection.ResolveOne(TimeSpan.FromSeconds(2.0)) |> Async.AwaitTask
                return Some actor
            with _ ->
                return None
        }

    //let EnsureSupervisorWithOptions (system: ActorSystem, configOpt: Config option, storageOpt: IPcslStorage option) =
    //    let settings =
    //        match configOpt with
    //        | Some cfg -> SupervisorSettingsReader.load (Some cfg)
    //        | None -> SupervisorSettingsReader.load (Some system.Settings.Config)

    //    let storage = defaultArg storageOpt (PcslStorage.inMemory ())
    //    ensureGuardian system settings storage |> ignore

    //    resolveSupervisor system
    //    |> Async.RunSynchronously
    //    |> function
    //        | Some actor -> actor
    //        | None ->
    //            resolveSupervisor system
    //            |> Async.RunSynchronously
    //            |> function
    //                | Some actor -> actor
    //                | None -> failwith "Failed to start Akka.FSI supervisor"

    let EnsureSupervisorWithOptions (system: ActorSystem, configOpt: Config option, storageOpt: IPcslStorage option) =
        Akka.FSI.Contracts.ContractSerialization.installForAssemblies system [ typeof<Akka.FSI.Contracts.IMessage>.Assembly ]
        |> ignore

        let settings =
            match configOpt with
            | Some cfg -> SupervisorSettingsReader.load (Some cfg)
            | None -> SupervisorSettingsReader.load (Some system.Settings.Config)

        let storage =
            match storageOpt with
            | Some s -> s
            | None -> createDefaultStorage system
        ensureGuardian system settings storage |> ignore

        let attempt1 = resolveSupervisor system |> Async.RunSynchronously

        match attempt1 with
        | Some actor -> actor
        | None ->
            system.Log.Warning("First attempt to resolve supervisor failed; retrying")
            System.Threading.Thread.Sleep 100

            resolveSupervisor system
            |> Async.RunSynchronously
            |> function
                | Some actor -> actor
                | None ->
                    system.Log.Error("Failed to resolve supervisor after second attempt")
                    failwith "Failed to start Akka.FSI supervisor"

    let EnsureSupervisor (system: ActorSystem) =
        EnsureSupervisorWithOptions(system, None, None)

    let EnsureSupervisorWithConfig (system: ActorSystem, config: Config) =
        EnsureSupervisorWithOptions(system, Some config, None)

    let EnsureSupervisorWithStorage (system: ActorSystem, storage: IPcslStorage) =
        EnsureSupervisorWithOptions(system, None, Some storage)

    let EnsureSupervisorWithConfigAndStorage (system: ActorSystem, config: Config, storage: IPcslStorage) =
        EnsureSupervisorWithOptions(system, Some config, Some storage)

    let GetSupervisor (system: ActorSystem) =
        resolveSupervisor system |> Async.RunSynchronously

    let ExecJson (supervisor: IActorRef) (json: string) =
        async {
            let! result =
                supervisor.Ask<ExecResult>(ExecCodeJson json, TimeSpan.FromSeconds(30.0))
                |> Async.AwaitTask

            return JsonCodec.execResultToJson result
        }

    let PutFileJson (supervisor: IActorRef) (path: string) (content: string) =
        async {
            let! _ =
                supervisor.Ask<bool>(
                    { path = path
                      content = content
                      encoding = None },
                    TimeSpan.FromSeconds(5.0)
                )
                |> Async.AwaitTask

            return true
        }

    let GetSessionInfoJson (supervisor: IActorRef) (session: string) =
        async {
            let request: GetSessionInfo = { session = session }
            let! info =
                supervisor.Ask<SessionInfo>(request, TimeSpan.FromSeconds(5.0))
                |> Async.AwaitTask

            return JsonCodec.serialize info
        }
