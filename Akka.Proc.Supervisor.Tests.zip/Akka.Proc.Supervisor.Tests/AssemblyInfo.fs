namespace Akka.Proc.Supervisor.Tests

open Xunit

[<assembly: CollectionBehavior(DisableTestParallelization = true)>]
do ()
