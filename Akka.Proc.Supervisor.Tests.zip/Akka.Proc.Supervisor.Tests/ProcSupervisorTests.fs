﻿namespace Akka.Proc.Supervisor.Tests

open System
open System.IO
open System.Diagnostics
open System.Net
open System.Net.Http
open System.Net.Sockets
open System.Text
open System.Text.Json
open System.Threading.Tasks
open System.Runtime.ExceptionServices
open System.Runtime.InteropServices
open Xunit
open Xunit.Abstractions
open Akka.Actor
open Akka.Cluster
open Akka.Cluster.Sharding
open Akka.Configuration
open Akka.DistributedData
open Akka.Proc.Supervisor
open Akka.FSI.Contracts

module TestHelpers =
    let contractSerializationConfig () =
        Akka.FSI.Contracts.ContractSerialization.configForAssemblies [ typeof<Akka.FSI.Contracts.IMessage>.Assembly; typeof<ProcStartSpec>.Assembly ]

    let shortSettings: ProcSupervisorSettings =
        { systemName = "proc-system"
          probeIntervalMs = 200
          probeTimeoutMs = 500
          probeFailureThreshold = 2
          restartDelayMs = 200
          checkIntervalMs = 200
          forwardTimeoutMs = 2000
          web = { host = "0.0.0.0"; port = 6001 }
          sharding =
              { typeName = "proc-node"
                role = None
                numberOfShards = 20 } }

    let systemConfig () =
        let remoteDefaults =
            ConfigurationFactory.FromResource(
                "Akka.Remote.Configuration.Remote.conf",
                typeof<Akka.Remote.RemoteActorRefProvider>.Assembly)
        let distributedDataDefaults = Akka.DistributedData.DistributedData.DefaultConfig()
        let shardingDefaults = ClusterSharding.DefaultConfig()
        let singletonDefaults = Akka.Cluster.Tools.Singleton.ClusterSingleton.DefaultConfig()
        ConfigurationFactory.ParseString(
            """
            akka {
              loglevel = "ERROR"
              stdout-loglevel = "ERROR"
              actor.provider = "cluster"
              actor.serialize-messages = off
              actor.serialize-creators = off
              suppress-json-serializer-warning = on
              remote.dot-netty.tcp {
                hostname = "127.0.0.1"
                port = 0
              }
              cluster {
                sharding {
                  state-store-mode = "ddata"
                  entity-recovery-strategy = "all"
                  coordinator-singleton = "akka.cluster.singleton"
                }
              }
              cluster.singleton {
                singleton-name = "singleton"
                role = ""
                hand-over-retry-interval = 1s
                min-number-of-hand-over-retries = 15
                use-lease = ""
                lease-retry-interval = 5s
                consider-app-version = false
              }
            }
            """
        ).WithFallback(contractSerializationConfig ()).WithFallback(
            remoteDefaults
                .WithFallback(distributedDataDefaults)
                .WithFallback(shardingDefaults)
                .WithFallback(singletonDefaults)
                .WithFallback(ConfigurationFactory.Default()))

    let systemConfigWithPort (host: string) (port: int) =
        ConfigurationFactory.ParseString(
            $"""
            akka.remote.dot-netty.tcp.hostname = "{host}"
            akka.remote.dot-netty.tcp.port = {port}
            """
        ).WithFallback(systemConfig ())

    let waitUntil (timeout: TimeSpan) (interval: TimeSpan) (condition: unit -> Task<bool>) =
        task {
            let sw = Stopwatch.StartNew()
            let mutable ok = false
            while not ok && sw.Elapsed < timeout do
                let! current = condition()
                ok <- current
                if not ok then
                    do! Task.Delay(interval)
            return ok
        }

    let waitUntilSync (timeout: TimeSpan) (interval: TimeSpan) (condition: unit -> bool) =
        waitUntil timeout interval (fun () -> Task.FromResult(condition()))

    let withSystem (name: string) (f: ActorSystem -> Task<'T>) =
        task {
            use system = ActorSystem.Create(name, systemConfig ())
            let! outcome =
                task {
                    try
                        let! result = f system
                        return Choice1Of2 result
                    with ex ->
                        return Choice2Of2 ex
                }
            let! _ = system.Terminate()
            do! system.WhenTerminated
            match outcome with
            | Choice1Of2 result -> return result
            | Choice2Of2 ex ->
                ExceptionDispatchInfo.Capture(ex).Throw()
                return Unchecked.defaultof<'T>
        }

    let waitForClusterUp (cluster: Cluster) =
        waitUntilSync (TimeSpan.FromSeconds 10.0) (TimeSpan.FromMilliseconds 100.0) (fun () ->
            cluster.SelfMember.Status = MemberStatus.Up)

    let startSupervisor (system: ActorSystem) (settings: ProcSupervisorSettings) =
        let settings =
            if isNull (box settings) then
                ProcSupervisorSettings.Default
            else
                settings
        let cluster = Cluster.Get system
        cluster.Join(cluster.SelfAddress)
        let registry = system.ActorOf(Props.Create(fun () -> ProcRegistryActor()), "proc-registry")
        let shardSettings =
            let baseSettings =
                ClusterShardingSettings.Create(system)
                    .WithStateStoreMode(StateStoreMode.DData)
            match settings.sharding.role with
            | Some role -> baseSettings.WithRole(role)
            | None -> baseSettings
        let extractor = ProcMessageExtractor(settings.sharding.numberOfShards)
        let region =
            ClusterSharding.Get(system).Start(
                settings.sharding.typeName,
                Props.Create(fun () -> ProcNodeActor(settings, registry, None)),
                shardSettings,
                extractor)
        let supervisor = system.ActorOf(Props.Create(fun () -> ProcSupervisorActor(region, registry)), "proc-supervisor")
        cluster, supervisor

    let ask<'T> (actor: IActorRef) (msg: obj) =
        actor.Ask<'T>(msg, TimeSpan.FromSeconds 5.0)

    let getProcInfo (supervisor: IActorRef) procId =
        ask<ProcSnapshot> supervisor ({ procId = procId } : GetProcInfo)

    let startProc (supervisor: IActorRef) (spec: ProcStartSpec) =
        ask<ProcSnapshot> supervisor ({ procId = spec.procId; spec = spec } : StartProc)

    let stopProc (supervisor: IActorRef) procId =
        ask<ProcSnapshot> supervisor ({ procId = procId; force = true } : StopProc)

    let private shellSpec procId shellCommand =
        if RuntimeInformation.IsOSPlatform(OSPlatform.Windows) then
            { procId = procId
              fileName = "powershell"
              args = [ "-NoProfile"; "-Command"; shellCommand ]
              workingDir = None
              role = None
              probeMessage = None
              probeCron = None
              probeIntervalMs = None }
        else
            { procId = procId
              fileName = "/bin/sh"
              args = [ "-lc"; shellCommand ]
              workingDir = None
              role = None
              probeMessage = None
              probeCron = None
              probeIntervalMs = None }

    let longRunningSpec procId =
        if RuntimeInformation.IsOSPlatform(OSPlatform.Windows) then
            shellSpec procId "Start-Sleep -Seconds 30"
        else
            shellSpec procId "sleep 30"

    let shortLivedSpec procId =
        if RuntimeInformation.IsOSPlatform(OSPlatform.Windows) then
            shellSpec procId "Start-Sleep -Milliseconds 500"
        else
            shellSpec procId "sleep 0.5"

    let getFreePort () =
        let listener = new TcpListener(IPAddress.Loopback, 0)
        listener.Start()
        let port = (listener.LocalEndpoint :?> IPEndPoint).Port
        listener.Stop()
        port

    let tryParseFirstProcNode (json: string) =
        let doc = JsonDocument.Parse(json)
        let root = doc.RootElement
        if root.ValueKind = JsonValueKind.Array && root.GetArrayLength() > 0 then
            let first = root[0]
            let procId =
                let mutable prop = Unchecked.defaultof<JsonElement>
                if first.TryGetProperty("procId", &prop) && prop.ValueKind = JsonValueKind.String then
                    prop.GetString()
                else
                    null
            let pid =
                let mutable pidProp = Unchecked.defaultof<JsonElement>
                if first.TryGetProperty("pid", &pidProp) && pidProp.ValueKind = JsonValueKind.Number then
                    Some(pidProp.GetInt32())
                else
                    None
            let fsiSupervisorPath =
                let mutable pathProp = Unchecked.defaultof<JsonElement>
                if first.TryGetProperty("fsiSupervisorPath", &pathProp) && pathProp.ValueKind = JsonValueKind.String then
                    pathProp.GetString()
                else
                    null
            procId, pid, fsiSupervisorPath
        else
            null, None, null

    let tryParseExecResultOk (json: string) =
        let doc = JsonDocument.Parse(json)
        let root = doc.RootElement
        let mutable okProp = Unchecked.defaultof<JsonElement>
        let mutable resultProp = Unchecked.defaultof<JsonElement>
        let ok =
            root.TryGetProperty("ok", &okProp) && okProp.ValueKind = JsonValueKind.True
        let result =
            if root.TryGetProperty("resultJson", &resultProp) && resultProp.ValueKind = JsonValueKind.String then
                resultProp.GetString()
            else
                null
        ok, result

type SessionEchoActor() as this =
    inherit ReceiveActor()

    do
        this.Receive<ListSessions>(fun _ ->
            let ctx: IActorContext = this.ActorCtx
            ctx.Sender.Tell({ items = [] }, ctx.Self))
        this.ReceiveAny(fun msg ->
            let ctx: IActorContext = this.ActorCtx
            ctx.Sender.Tell(msg, ctx.Self))

    member _.ActorCtx: IActorContext = ActorBase.Context

type SessionFailActor() as this =
    inherit ReceiveActor()

    do
        this.ReceiveAny(fun _ ->
            let ctx: IActorContext = this.ActorCtx
            ctx.Sender.Tell(Status.Failure(Exception("probe failed")), ctx.Self))

    member _.ActorCtx: IActorContext = ActorBase.Context

type ProcSupervisorTests(output: ITestOutputHelper) =
    [<Fact>]
    member _.``ProcNode stdout parser extracts akka tcp address``() =
        let line =
            "[INFO][03/26/2026 16:18:46.336Z][Thread 0001][remoting (akka://proc-system)] Remoting started; listening on addresses : [akka.tcp://proc-system@10.28.112.140:44367]"

        let parsed = ProcNodeBootstrapParser.tryExtractNodeAddressFromStdout line
        Assert.Equal(Some "akka.tcp://proc-system@10.28.112.140:44367", parsed)

    [<Fact>]
    member _.``ProcNode stdout parser ignores non-address line``() =
        let parsed = ProcNodeBootstrapParser.tryExtractNodeAddressFromStdout "FsiSupervisorActor ready"
        Assert.Equal(None, parsed)

    [<Fact>]
    member _.``Default procnode spec uses dotnet exec with runtimeconfig and depsfile``() =
        let spec =
            ProcStartSpecBuilder.buildManagedProcNodeSpec
                "demo-proc"
                "akka.tcp://proc-system@127.0.0.1:8110/user/proc-supervisor"
                "proc-system"
                [ "akka.tcp://proc-system@127.0.0.1:8110" ]
                "127.0.0.1"
                18081
                [ "procnode" ]
                None
                None
                None

        Assert.Equal("dotnet", spec.fileName)
        Assert.NotEmpty(spec.args)
        Assert.Equal("exec", spec.args[0])
        Assert.Contains("--runtimeconfig", spec.args)
        Assert.Contains("--depsfile", spec.args)
        Assert.Contains("--mode", spec.args)
        Assert.Contains("procnode", spec.args)
        Assert.Contains("--supervisor", spec.args)
        Assert.Contains("--host", spec.args)
        Assert.Contains("--port", spec.args)
        Assert.Contains("--role", spec.args)
        Assert.Equal(Some "procnode", spec.role)
        Assert.True(spec.workingDir.IsSome, "working directory should be populated")

    [<Fact>]
    member _.``ProcSupervisor returns assembly version for GetVesion``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let! version = TestHelpers.ask<OpResult> supervisor GetVesion
                        Assert.Equal("GetVesion", version.op)
                        Assert.Equal("Akka.Proc.Supervisor", version.assemblyName)
                        Assert.Equal(Some "1.562.101.201", version.assemblyVersion)
                        Assert.True(version.fileVersion.IsSome, "file version should be present")
                        Assert.True(version.actorPath.IsSome, "actor path should be present")
                        Assert.Contains("/user/proc-supervisor", version.actorPath.Value)
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``ProcSupervisor answers GetVesion and GetAllProcInfo over Akka.Remote``() =
        task {
            let host = "127.0.0.1"
            let supervisorPort = TestHelpers.getFreePort()
            let supervisorSystemName = "proc-remote-supervisor-" + Guid.NewGuid().ToString("N")
            let clientSystemName = "proc-remote-client-" + Guid.NewGuid().ToString("N")

            use supervisorSystem = ActorSystem.Create(supervisorSystemName, TestHelpers.systemConfigWithPort host supervisorPort)

            use clientSystem = ActorSystem.Create(clientSystemName, TestHelpers.systemConfigWithPort host 0)

            let cluster, _ = TestHelpers.startSupervisor supervisorSystem TestHelpers.shortSettings
            let! _ = TestHelpers.waitForClusterUp cluster

            let remotePath = $"akka.tcp://{supervisorSystemName}@{host}:{supervisorPort}/user/proc-supervisor"
            let selection = clientSystem.ActorSelection(remotePath)

            let! version = selection.Ask<OpResult>(GetVesion, TimeSpan.FromSeconds 5.0)
            Assert.Equal("GetVesion", version.op)
            Assert.Equal("Akka.Proc.Supervisor", version.assemblyName)

            let! snapshots = selection.Ask<ProcSnapshot array>(GetAllProcInfo, TimeSpan.FromSeconds 5.0)
            Assert.NotNull(snapshots)
            Assert.Empty(snapshots)

            let! _ = clientSystem.Terminate()
            do! clientSystem.WhenTerminated
            let! _ = supervisorSystem.Terminate()
            do! supervisorSystem.WhenTerminated
            return ()
        }

    [<Fact>]
    member _.``Bootstrap procnode registers a live FSI supervisor when spawned by supervisor process``() =
        task {
            let getFreePort () =
                use listener = new TcpListener(IPAddress.Loopback, 0)
                listener.Start()
                let port = (listener.LocalEndpoint :?> IPEndPoint).Port
                listener.Stop()
                port

            let procAssembly = typeof<ProcSnapshot>.Assembly.Location
            let outputDir = Path.GetDirectoryName(procAssembly)
            let runtimeConfig = Path.Combine(outputDir, "Akka.Proc.Supervisor.runtimeconfig.json")
            let depsFile = Path.Combine(outputDir, "Akka.Proc.Supervisor.deps.json")
            let host = "127.0.0.1"
            let procPort = getFreePort()
            let webPort = getFreePort()
            let systemName = "proc-bootstrap-" + Guid.NewGuid().ToString("N")
            let procId = "bootstrap-" + Guid.NewGuid().ToString("N")
            let seedAddress = $"akka.tcp://{systemName}@{host}:{procPort}"

            let psi = ProcessStartInfo()
            psi.FileName <- "dotnet"
            psi.WorkingDirectory <- outputDir
            psi.ArgumentList.Add("exec")
            psi.ArgumentList.Add("--runtimeconfig")
            psi.ArgumentList.Add(runtimeConfig)
            psi.ArgumentList.Add("--depsfile")
            psi.ArgumentList.Add(depsFile)
            psi.ArgumentList.Add(procAssembly)
            psi.ArgumentList.Add("--mode")
            psi.ArgumentList.Add("supervisor")
            psi.ArgumentList.Add("--systemname")
            psi.ArgumentList.Add(systemName)
            psi.ArgumentList.Add("--host")
            psi.ArgumentList.Add(host)
            psi.ArgumentList.Add("--port")
            psi.ArgumentList.Add(string procPort)
            psi.ArgumentList.Add("--webhost")
            psi.ArgumentList.Add(host)
            psi.ArgumentList.Add("--webport")
            psi.ArgumentList.Add(string webPort)
            psi.ArgumentList.Add("--seed")
            psi.ArgumentList.Add(seedAddress)
            psi.ArgumentList.Add("--spawndefault")
            psi.ArgumentList.Add("--procid")
            psi.ArgumentList.Add(procId)
            psi.RedirectStandardOutput <- true
            psi.RedirectStandardError <- true
            psi.UseShellExecute <- false

            use proc = Process.Start(psi)
            let stdout = System.Collections.Concurrent.ConcurrentQueue<string>()
            let stderr = System.Collections.Concurrent.ConcurrentQueue<string>()
            proc.OutputDataReceived.Add(fun args -> if not (isNull args.Data) then stdout.Enqueue args.Data)
            proc.ErrorDataReceived.Add(fun args -> if not (isNull args.Data) then stderr.Enqueue args.Data)
            proc.BeginOutputReadLine()
            proc.BeginErrorReadLine()

            let dumpOutput () =
                seq {
                    while not stdout.IsEmpty do
                        match stdout.TryDequeue() with
                        | true, line -> yield $"stdout> {line}"
                        | _ -> ()
                    while not stderr.IsEmpty do
                        match stderr.TryDequeue() with
                        | true, line -> yield $"stderr> {line}"
                        | _ -> ()
                }
                |> Seq.iter output.WriteLine

            let http = new HttpClient(Timeout = TimeSpan.FromSeconds 5.0)

            let tryGet (url: string) =
                task {
                    try
                        let! text = http.GetStringAsync(url)
                        return Some text
                    with _ ->
                        return None
                }

            let mutable healthReady = false
            let mutable nodesJson = None
            try
                let! _ =
                    TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 300.0) (fun () ->
                        task {
                            let! text = tryGet $"http://{host}:{webPort}/health"
                            let ok = text |> Option.exists (fun x -> x.Contains("ok", StringComparison.OrdinalIgnoreCase))
                            healthReady <- healthReady || ok
                            return ok
                        })
                let! registered =
                    TestHelpers.waitUntil (TimeSpan.FromSeconds 30.0) (TimeSpan.FromMilliseconds 500.0) (fun () ->
                        task {
                            let! text = tryGet $"http://{host}:{webPort}/api/proc/nodes"
                            nodesJson <- text
                            return
                                text
                                |> Option.exists (fun json ->
                                    use doc = JsonDocument.Parse(json)
                                    doc.RootElement.EnumerateArray()
                                    |> Seq.exists (fun item ->
                                        let mutable procIdValue = Unchecked.defaultof<JsonElement>
                                        let mutable fsiPathValue = Unchecked.defaultof<JsonElement>
                                        item.TryGetProperty("procId", &procIdValue)
                                        && procIdValue.GetString() = procId
                                        && item.TryGetProperty("fsiSupervisorPath", &fsiPathValue)
                                        && fsiPathValue.ValueKind = JsonValueKind.String
                                        && not (String.IsNullOrWhiteSpace(fsiPathValue.GetString()))))
                        })

                Assert.True(healthReady, "supervisor health endpoint should become ready")
                Assert.True(registered, $"bootstrap procnode '{procId}' should register a non-empty fsiSupervisorPath")
            finally
                if not proc.HasExited then
                    try
                        proc.Kill(true)
                        proc.WaitForExit(5000) |> ignore
                    with _ ->
                        ()
                dumpOutput ()
                http.Dispose()
        }

    [<Fact>]
    member _.``Bootstrap procnode FSI supervisor answers GetVesion over Akka.Remote``() =
        task {
            let getFreePort () =
                use listener = new TcpListener(IPAddress.Loopback, 0)
                listener.Start()
                let port = (listener.LocalEndpoint :?> IPEndPoint).Port
                listener.Stop()
                port

            let procAssembly = typeof<ProcSnapshot>.Assembly.Location
            let outputDir = Path.GetDirectoryName(procAssembly)
            let runtimeConfig = Path.Combine(outputDir, "Akka.Proc.Supervisor.runtimeconfig.json")
            let depsFile = Path.Combine(outputDir, "Akka.Proc.Supervisor.deps.json")
            let host = "127.0.0.1"
            let supervisorPort = getFreePort()
            let webPort = getFreePort()
            let systemName = "proc-bootstrap-version-" + Guid.NewGuid().ToString("N")
            let clientSystemName = "proc-bootstrap-version-client-" + Guid.NewGuid().ToString("N")
            let procId = "bootstrap-version-" + Guid.NewGuid().ToString("N")
            let seedAddress = $"akka.tcp://{systemName}@{host}:{supervisorPort}"

            let psi = ProcessStartInfo()
            psi.FileName <- "dotnet"
            psi.WorkingDirectory <- outputDir
            psi.ArgumentList.Add("exec")
            psi.ArgumentList.Add("--runtimeconfig")
            psi.ArgumentList.Add(runtimeConfig)
            psi.ArgumentList.Add("--depsfile")
            psi.ArgumentList.Add(depsFile)
            psi.ArgumentList.Add(procAssembly)
            psi.ArgumentList.Add("--mode")
            psi.ArgumentList.Add("supervisor")
            psi.ArgumentList.Add("--systemname")
            psi.ArgumentList.Add(systemName)
            psi.ArgumentList.Add("--host")
            psi.ArgumentList.Add(host)
            psi.ArgumentList.Add("--port")
            psi.ArgumentList.Add(string supervisorPort)
            psi.ArgumentList.Add("--webhost")
            psi.ArgumentList.Add(host)
            psi.ArgumentList.Add("--webport")
            psi.ArgumentList.Add(string webPort)
            psi.ArgumentList.Add("--seed")
            psi.ArgumentList.Add(seedAddress)
            psi.ArgumentList.Add("--spawndefault")
            psi.ArgumentList.Add("--procid")
            psi.ArgumentList.Add(procId)
            psi.RedirectStandardOutput <- true
            psi.RedirectStandardError <- true
            psi.UseShellExecute <- false

            use proc = Process.Start(psi)
            let stdout = System.Collections.Concurrent.ConcurrentQueue<string>()
            let stderr = System.Collections.Concurrent.ConcurrentQueue<string>()
            proc.OutputDataReceived.Add(fun args -> if not (isNull args.Data) then stdout.Enqueue args.Data)
            proc.ErrorDataReceived.Add(fun args -> if not (isNull args.Data) then stderr.Enqueue args.Data)
            proc.BeginOutputReadLine()
            proc.BeginErrorReadLine()

            let dumpOutput () =
                seq {
                    while not stdout.IsEmpty do
                        match stdout.TryDequeue() with
                        | true, line -> yield $"stdout> {line}"
                        | _ -> ()
                    while not stderr.IsEmpty do
                        match stderr.TryDequeue() with
                        | true, line -> yield $"stderr> {line}"
                        | _ -> ()
                }
                |> Seq.iter output.WriteLine

            use http = new HttpClient(Timeout = TimeSpan.FromSeconds 5.0)
            use clientSystem = ActorSystem.Create(clientSystemName, TestHelpers.systemConfigWithPort host 0)

            let tryGet (url: string) =
                task {
                    try
                        let! text = http.GetStringAsync(url)
                        return Some text
                    with _ ->
                        return None
                }

            try
                let! ready =
                    TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 300.0) (fun () ->
                        task {
                            let! text = tryGet $"http://{host}:{webPort}/api/proc/nodes"
                            return
                                text
                                |> Option.exists (fun json ->
                                    use doc = JsonDocument.Parse(json)
                                    doc.RootElement.EnumerateArray()
                                    |> Seq.exists (fun item ->
                                        let mutable procIdValue = Unchecked.defaultof<JsonElement>
                                        let mutable fsiPathValue = Unchecked.defaultof<JsonElement>
                                        item.TryGetProperty("procId", &procIdValue)
                                        && procIdValue.GetString() = procId
                                        && item.TryGetProperty("fsiSupervisorPath", &fsiPathValue)
                                        && fsiPathValue.ValueKind = JsonValueKind.String
                                        && not (String.IsNullOrWhiteSpace(fsiPathValue.GetString()))))
                        })

                Assert.True(ready, "bootstrap procnode should expose a live fsiSupervisorPath")

                let procSelection =
                    clientSystem.ActorSelection($"akka.tcp://{systemName}@{host}:{supervisorPort}/user/proc-supervisor")

                let mutable snapshotOpt : ProcSnapshot option = None
                let! runningReady =
                    TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 300.0) (fun () ->
                        task {
                            let! snapshots = procSelection.Ask<ProcSnapshot array>(GetAllProcInfo, TimeSpan.FromSeconds 5.0)
                            snapshotOpt <-
                                snapshots
                                |> Array.tryFind (fun item -> String.Equals(item.procId, procId, StringComparison.Ordinal))
                            return
                                snapshotOpt
                                |> Option.exists (fun snapshot ->
                                    String.Equals(snapshot.status, "running", StringComparison.OrdinalIgnoreCase)
                                    && snapshot.fsiSupervisorPath.IsSome)
                        })

                Assert.True(runningReady, "bootstrap procnode should reach running status with a live fsi supervisor path")
                let snapshot = snapshotOpt.Value

                let fsiSelection = clientSystem.ActorSelection(snapshot.fsiSupervisorPath.Value)
                let! _ = fsiSelection.ResolveOne(TimeSpan.FromSeconds 5.0)
                let! sessions = fsiSelection.Ask<Sessions>({ all = true }, TimeSpan.FromSeconds 5.0)
                Assert.NotNull(sessions)
                let! version = fsiSelection.Ask<OpResult>(GetVesion, TimeSpan.FromSeconds 5.0)
                Assert.Equal("GetVesion", version.op)
                Assert.Equal("Akka.FSI.Supervisor", version.assemblyName)
            finally
                if not proc.HasExited then
                    try
                        proc.Kill(true)
                        proc.WaitForExit(5000) |> ignore
                    with _ ->
                        ()
                dumpOutput ()
                try
                    clientSystem.Terminate().GetAwaiter().GetResult() |> ignore
                    clientSystem.WhenTerminated.GetAwaiter().GetResult() |> ignore
                with _ ->
                    ()
        }

    [<Fact>]
    member _.``StartProc launches process``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec = TestHelpers.longRunningSpec procId
                        let! _ = TestHelpers.startProc supervisor spec
                        let! hasPid =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 5.0) (TimeSpan.FromMilliseconds 100.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.pid.IsSome
                                })
                        Assert.True(hasPid, "Process PID should be reported after start.")
                        let! _ = TestHelpers.stopProc supervisor procId
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``StopProc terminates process``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec = TestHelpers.longRunningSpec procId
                        let! _ = TestHelpers.startProc supervisor spec
                        let! _ = TestHelpers.stopProc supervisor procId
                        let! snapshot = TestHelpers.getProcInfo supervisor procId
                        Assert.True(snapshot.pid.IsNone, "PID should be cleared after stop.")
                        Assert.Equal("stopped", snapshot.status)
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``Probe success updates snapshot``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec =
                            { TestHelpers.longRunningSpec procId with
                                probeMessage = Some "listsessions --all true"
                                probeIntervalMs = Some 200 }
                        let! _ = TestHelpers.startProc supervisor spec
                        let echo =
                            system.ActorOf(Props.Create(fun () -> SessionEchoActor()), "probe-echo")
                        let ready =
                            { procId = procId
                              pid = 0
                              fsiSupervisorPath = echo.Path.ToStringWithAddress(cluster.SelfAddress)
                              nodeAddress = cluster.SelfAddress.ToString() }
                        supervisor.Tell(ready)
                        let! ok =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 6.0) (TimeSpan.FromMilliseconds 200.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.lastProbeOk = Some true
                                })
                        if not ok then
                            let! snapshot = TestHelpers.getProcInfo supervisor procId
                            output.WriteLine($"Probe snapshot: status={snapshot.status} lastProbeOk={snapshot.lastProbeOk} failures={snapshot.probeFailures} lastError={snapshot.lastError} fsiPath={snapshot.fsiSupervisorPath}")
                        Assert.True(ok, "Probe should eventually succeed.")
                        let! snapshot = TestHelpers.getProcInfo supervisor procId
                        Assert.Equal(Some true, snapshot.lastProbeOk)
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``Process restarts after exit``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec = TestHelpers.shortLivedSpec procId
                        let! _ = TestHelpers.startProc supervisor spec
                        let! firstPidReady =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 5.0) (TimeSpan.FromMilliseconds 100.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.pid.IsSome
                                })
                        Assert.True(firstPidReady, "Proc should report an initial PID before exit.")
                        let! firstSnapshot = TestHelpers.getProcInfo supervisor procId
                        let firstPid = firstSnapshot.pid
                        let! restarted =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 6.0) (TimeSpan.FromMilliseconds 200.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.pid.IsSome && snapshot.pid <> firstPid
                                })
                        Assert.True(restarted, "Proc should restart with a new PID after exit.")
                        let! _ = TestHelpers.stopProc supervisor procId
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``Probe failures trigger restart``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec =
                            { TestHelpers.longRunningSpec procId with
                                probeMessage = Some "listsessions --all true"
                                probeIntervalMs = Some 200 }
                        let! _ = TestHelpers.startProc supervisor spec
                        let failActor =
                            system.ActorOf(Props.Create(fun () -> SessionFailActor()), "probe-fail")
                        let ready =
                            { procId = procId
                              pid = 0
                              fsiSupervisorPath = failActor.Path.ToStringWithAddress(cluster.SelfAddress)
                              nodeAddress = cluster.SelfAddress.ToString() }
                        supervisor.Tell(ready)
                        let! _ =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 5.0) (TimeSpan.FromMilliseconds 100.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.pid.IsSome
                                })
                        let! firstSnapshot = TestHelpers.getProcInfo supervisor procId
                        let firstPid = firstSnapshot.pid
                        let! restarted =
                            TestHelpers.waitUntil (TimeSpan.FromSeconds 8.0) (TimeSpan.FromMilliseconds 200.0) (fun () ->
                                task {
                                    let! snapshot = TestHelpers.getProcInfo supervisor procId
                                    return snapshot.pid.IsSome && snapshot.pid <> firstPid
                                })
                        if not restarted then
                            let! snapshot = TestHelpers.getProcInfo supervisor procId
                            output.WriteLine($"Probe restart snapshot: status={snapshot.status} pid={snapshot.pid} failures={snapshot.probeFailures} lastError={snapshot.lastError} fsiPath={snapshot.fsiSupervisorPath}")
                        Assert.True(restarted, "Probe failures should restart the process.")
                        let! _ = TestHelpers.stopProc supervisor procId
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``ForwardMessage routes to fsi supervisor``() =
        task {
            let systemName = "proc-tests-" + Guid.NewGuid().ToString("N")
            let! _ =
                TestHelpers.withSystem systemName (fun system ->
                    task {
                        let cluster, supervisor = TestHelpers.startSupervisor system TestHelpers.shortSettings
                        let! _ = TestHelpers.waitForClusterUp cluster
                        let procId = Guid.NewGuid().ToString("N")
                        let spec = TestHelpers.longRunningSpec procId
                        let! _ = TestHelpers.startProc supervisor spec
                        let echo =
                            system.ActorOf(Props.Create(fun () -> SessionEchoActor()), "forward-echo")
                        let ready =
                            { procId = procId
                              pid = 0
                              fsiSupervisorPath = echo.Path.ToStringWithAddress(cluster.SelfAddress)
                              nodeAddress = cluster.SelfAddress.ToString() }
                        supervisor.Tell(ready)
                        let! result =
                            TestHelpers.ask<obj> supervisor { procId = procId; message = "listsessions --all true" }
                        let ss = result :?> Sessions
                        output.WriteLine(sprintf "Sessions: %A" ss)
                        Assert.True(result :? Sessions, "Forward should return Sessions response.")
                        let! _ = TestHelpers.stopProc supervisor procId
                        return ()
                    })
            return ()
        }

    [<Fact>]
    member _.``E2E supervisor spawns proc node and forwards exec``() =
        task {
            let assemblyPath = typeof<ProcSupervisorActor>.Assembly.Location
            let webPort = TestHelpers.getFreePort()
            let clusterPort = TestHelpers.getFreePort()
            let systemName = "proc-e2e-" + Guid.NewGuid().ToString("N")
            let psi = new ProcessStartInfo()
            psi.FileName <- "dotnet"
            psi.UseShellExecute <- false
            psi.CreateNoWindow <- true
            psi.RedirectStandardOutput <- true
            psi.RedirectStandardError <- true
            psi.ArgumentList.Add(assemblyPath)
            psi.ArgumentList.Add("--mode")
            psi.ArgumentList.Add("supervisor")
            psi.ArgumentList.Add("--systemname")
            psi.ArgumentList.Add(systemName)
            psi.ArgumentList.Add("--host")
            psi.ArgumentList.Add("127.0.0.1")
            psi.ArgumentList.Add("--port")
            psi.ArgumentList.Add(string clusterPort)
            psi.ArgumentList.Add("--role")
            psi.ArgumentList.Add("procnode")
            psi.ArgumentList.Add("--procnoderole")
            psi.ArgumentList.Add("procnode")
            psi.ArgumentList.Add("--webport")
            psi.ArgumentList.Add(string webPort)
            output.WriteLine($"Starting supervisor: dotnet {assemblyPath} --mode supervisor (web {webPort})")
            use proc = new Process()
            proc.StartInfo <- psi
            let mutable stdout = StringBuilder()
            let mutable stderr = StringBuilder()
            let mutable nodePid: int option = None
            proc.OutputDataReceived.Add(fun args -> if not (isNull args.Data) then stdout.AppendLine(args.Data) |> ignore)
            proc.ErrorDataReceived.Add(fun args -> if not (isNull args.Data) then stderr.AppendLine(args.Data) |> ignore)
            Assert.True(proc.Start(), "Failed to start Akka.Proc.Supervisor process.")
            proc.BeginOutputReadLine()
            proc.BeginErrorReadLine()
            let baseUrl = $"http://127.0.0.1:{webPort}"
            use client = new HttpClient()
            let! ready =
                TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 200.0) (fun () ->
                    task {
                        try
                            let! _ = client.GetStringAsync($"{baseUrl}/api/cluster/info")
                            return true
                        with _ ->
                            return false
                    })
            Assert.True(ready, $"Supervisor REST did not start. stderr: {stderr}")
            let! procInfoReady =
                TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 300.0) (fun () ->
                    task {
                        try
                            let! json = client.GetStringAsync($"{baseUrl}/api/proc/nodes")
                            let procId, pid, _ = TestHelpers.tryParseFirstProcNode json
                            return not (String.IsNullOrWhiteSpace(procId)) && pid.IsSome
                        with _ ->
                            return false
                    })
            Assert.True(procInfoReady, "Proc node did not start in time.")
            let mutable lastNodesJson = ""
            let! fsiReady =
                TestHelpers.waitUntil (TimeSpan.FromSeconds 20.0) (TimeSpan.FromMilliseconds 300.0) (fun () ->
                    task {
                        try
                            let! json = client.GetStringAsync($"{baseUrl}/api/proc/nodes")
                            lastNodesJson <- json
                            let procId, pid, fsiPath = TestHelpers.tryParseFirstProcNode json
                            return
                                not (String.IsNullOrWhiteSpace(procId))
                                && pid.IsSome
                                && not (String.IsNullOrWhiteSpace(fsiPath))
                        with _ ->
                            return false
                    })
            if not fsiReady then
                output.WriteLine($"Nodes JSON: {lastNodesJson}")
                if stderr.Length > 0 then
                    output.WriteLine($"stderr: {stderr}")
                if stdout.Length > 0 then
                    output.WriteLine($"stdout: {stdout}")
            Assert.True(fsiReady, "FSI supervisor did not become ready in time.")
            let! nodesJson = client.GetStringAsync($"{baseUrl}/api/proc/nodes")
            let procId, pidOpt, _ = TestHelpers.tryParseFirstProcNode nodesJson
            Assert.True(pidOpt.IsSome, "Proc node PID should be present.")
            let pid = pidOpt.Value
            nodePid <- Some pid
            Assert.NotEqual(proc.Id, pid)
            let payload =
                JsonSerializer.Serialize({| message = "listsessions --all true"; timeoutMs = 15000 |})
            let mutable lastForwardResponse = ""
            let mutable lastForwardError = ""
            let! execOk =
                TestHelpers.waitUntil (TimeSpan.FromSeconds 30.0) (TimeSpan.FromMilliseconds 500.0) (fun () ->
                    task {
                        try
                            use content = new StringContent(payload, Encoding.UTF8, "application/json")
                            let! response = client.PostAsync($"{baseUrl}/api/proc/nodes/{procId}/send", content)
                            let! responseJson = response.Content.ReadAsStringAsync()
                            lastForwardResponse <- responseJson
                            if response.IsSuccessStatusCode then
                                try
                                    let doc = JsonDocument.Parse(responseJson)
                                    let root = doc.RootElement
                                    let mutable itemsProp = Unchecked.defaultof<JsonElement>
                                    return root.TryGetProperty("items", &itemsProp) && itemsProp.ValueKind = JsonValueKind.Array
                                with _ ->
                                    return false
                            else
                                return false
                        with ex ->
                            lastForwardError <- ex.Message
                            return false
                    })
            if not execOk then
                output.WriteLine($"Forward response: {lastForwardResponse}")
                if not (String.IsNullOrWhiteSpace(lastForwardError)) then
                    output.WriteLine($"Forward error: {lastForwardError}")
                if proc.HasExited then
                    output.WriteLine($"Supervisor exited with code {proc.ExitCode}.")
                if stderr.Length > 0 then
                    output.WriteLine($"stderr: {stderr}")
                if stdout.Length > 0 then
                    output.WriteLine($"stdout: {stdout}")
            Assert.True(execOk, "Forwarded listsessions should succeed.")
            let! _ = client.PostAsync($"{baseUrl}/api/cluster/shutdown", new StringContent("", Encoding.UTF8, "application/json"))
            if not proc.HasExited then
                if not (proc.WaitForExit(5000)) then
                    proc.Kill(true)
            match nodePid with
            | Some pid ->
                try
                    let nodeProc = Process.GetProcessById(pid)
                    nodeProc.Kill(true)
                with _ -> ()
            | None -> ()
            if stderr.Length > 0 then
                output.WriteLine($"stderr: {stderr}")
        }
