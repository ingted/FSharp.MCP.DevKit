namespace Akka.FSI.Supervisor.Tests

open System
open Akka.Actor
open Akka.Configuration
open Akka.FSI.Contracts
open Akka.FSI.Supervisor
open Akka.TestKit.Xunit2
open PersistedConcurrentSortedList.IFileSystem
open System.Threading.Tasks
open Xunit

type FsiSuperviseeTests() =
    inherit TestKit(
        ConfigurationFactory.ParseString(
            """
            akka.loglevel = "ERROR"
            akka.stdout-loglevel = "ERROR"
            akka.actor.provider = "local"
            akka.actor.serialize-messages = off
            akka.actor.serialize-creators = off
            akka.suppress-json-serializer-warning = on
            akka.fsi {
              mode = "inproc"
              worker-count = 1
              auto-session = "default"
              pcsl2 {
                scripts-keyspace = "scripts"
                results-keyspace = "results"
                snapshots-keyspace = "snapshots"
                auto-commit = true
              }
              filesystem {
                overlay-roots = []
                allow-os-read = true
                allow-os-write = false
              }
              timeouts {
                startup-ms = 2000
                exec-ms = 3000
                idle-restart-ms = 600000
              }
            }
            """
        ),
        "fsi-testkit")

    [<Fact(Skip = "Covered by Expecto supervisor/session integration tests; this TestKit variant is flaky in full-suite runs.")>]
    member this.``Supervisor creates supervisee actor for session``() : Task =
        task {
        let storage = RecordingStorage() :> IPcslStorage
        let supervisor = AkkaFsiBootstrap.EnsureSupervisorWithStorage(this.Sys, storage)

        let exec: ExecCode =
            { id = Guid.NewGuid().ToString("N")
              session = "alpha"
              code = "1 + 1"
              refs = []
              loads = []
              args = None
              timeoutMs = None
              captureStdout = None }

        let! _ = supervisor.Ask<ExecResult>(exec, TimeSpan.FromSeconds 60.0)

        let sessions =
            supervisor.Ask<Sessions>({ all = true }, TimeSpan.FromSeconds 10.0)

        let! sessions = sessions

        Assert.Contains(sessions.items, fun value -> value.session = "alpha")

        let infoRequest: GetSessionInfo = { session = "alpha" }
        let! info = supervisor.Ask<SessionInfo>(infoRequest, TimeSpan.FromSeconds 10.0)

        Assert.Equal("alpha", info.session)
        Assert.Equal("ready", info.status)
        }
