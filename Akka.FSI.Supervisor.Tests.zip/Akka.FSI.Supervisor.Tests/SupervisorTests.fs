﻿namespace Akka.FSI.Supervisor.Tests

open System
open System.Net.Sockets
//open Expecto
open Akka.Actor
open Akka.Configuration
open Akka.FSI.Contracts
open Akka.FSI.Supervisor
open PersistedConcurrentSortedList.IFileSystem
//open FSharp.Compiler.IO

module TestHelpers =
    let contractSerializationConfig () =
        Akka.FSI.Contracts.ContractSerialization.configForAssemblies [ typeof<Akka.FSI.Contracts.IMessage>.Assembly ]

    let testConfig =
        ConfigurationFactory.ParseString(
            """
            akka.loglevel = "ERROR"
            akka.stdout-loglevel = "ERROR"
            akka.actor.provider = "local"
            akka.actor.serialize-messages = off
            akka.actor.serialize-creators = off
            akka.suppress-json-serializer-warning = on
            akka.fsi {
              mode = "inproc"
              worker-count = 1
              auto-session = "default"
              pcsl2 {
                scripts-keyspace = "scripts"
                results-keyspace = "results"
                snapshots-keyspace = "snapshots"
                auto-commit = true
              }
              filesystem {
                overlay-roots = []
                allow-os-read = true
                allow-os-write = false
              }
              timeouts {
                startup-ms = 2000
                exec-ms = 3000
                idle-restart-ms = 600000
              }
            }
            """
        ).WithFallback(contractSerializationConfig ())

    let getFreePort () =
        let listener = new TcpListener(Net.IPAddress.Loopback, 0)
        listener.Start()
        let port = (listener.LocalEndpoint :?> Net.IPEndPoint).Port
        listener.Stop()
        port

    let remoteConfigWithPort (host: string) (port: int) =
        ConfigurationFactory.ParseString(
            $"""
            akka.actor.provider = "remote"
            akka.remote.dot-netty.tcp.hostname = "{host}"
            akka.remote.dot-netty.tcp.port = {port}
            """
        ).WithFallback(testConfig)

    let systemTimeout = TimeSpan.FromSeconds 10.0

    let withSystemAsync (f: Akka.Actor.ActorSystem -> Async<'T>) : Async<'T> =
        async {
            let system = Akka.Actor.ActorSystem.Create("fsi-tests", testConfig)

            // 先把 f 的結果/例外收起來，確保後面一定會做清理
            let! outcome = f system |> Async.Catch

            // 一定會做的 async cleanup（即使 f 丟例外或被取消）
            do! system.Terminate() |> Async.AwaitTask |> Async.Ignore
            do! system.WhenTerminated |> Async.AwaitTask |> Async.Ignore

            // 把原本 outcome 還原：成功就回傳值，失敗就原樣 rethrow
            match outcome with
            | Choice1Of2 v -> return v
            | Choice2Of2 ex -> return raise ex
        }

    let withSystemFromConfigAsync (config: Config) (f: Akka.Actor.ActorSystem -> Async<'T>) : Async<'T> =
        async {
            let system = Akka.Actor.ActorSystem.Create("fsi-tests-" + Guid.NewGuid().ToString("N"), config)
            let! outcome = f system |> Async.Catch
            do! system.Terminate() |> Async.AwaitTask |> Async.Ignore
            do! system.WhenTerminated |> Async.AwaitTask |> Async.Ignore

            match outcome with
            | Choice1Of2 v -> return v
            | Choice2Of2 ex -> return raise ex
        }

    let withSupervisorUsing (storageFactory: unit -> 'storage when 'storage :> IPcslStorage) (f: ActorSystem -> IActorRef -> 'storage -> Async<unit>) =
        withSystemAsync(fun system ->
            async {
                let storage = storageFactory()
                let supervisor = AkkaFsiBootstrap.EnsureSupervisorWithStorage(system, storage :> IPcslStorage)
                return! f system supervisor storage
            })

    let withSupervisorUsingConfig
        (config: Config)
        (storageFactory: unit -> 'storage when 'storage :> IPcslStorage)
        (f: ActorSystem -> IActorRef -> 'storage -> Async<unit>)
        =
        withSystemFromConfigAsync config (fun system ->
            async {
                let storage = storageFactory()
                let supervisor = AkkaFsiBootstrap.EnsureSupervisorWithStorage(system, storage :> IPcslStorage)
                return! f system supervisor storage
            })

    let ask<'T> (actor: IActorRef) (message: obj) =
        actor.Ask<'T>(message, systemTimeout) |> Async.AwaitTask

open TestHelpers

module SupervisorSpecification =
    open Expecto
    open FSharp.Compiler.IO
    let mkExec id session code =
        { id = id
          session = session
          code = code
          refs = []
          loads = []
          args = None
          timeoutMs = None
          captureStdout = None }

    let expectResultStored (storage: RecordingStorage) id =
        let path = sprintf "results/%s.json" id
        Expect.isSome (storage.TryFind path) (sprintf "result %s should be stored" id)

    let tests =
        testList "Akka.FSI.Supervisor" [
            testCase "splitInteractionBatch keeps indented bodies intact while splitting top-level paragraphs" <| fun _ ->
                let code =
                    """
open System

type Widget() =
    member _.A = 1

    member _.B = 2

let build () =
    let local = 41

    local + 1

let result = build ()
"""

                let chunks = ExecHelpers.splitInteractionBatch code
                Expect.equal chunks.Length 4 "Top-level paragraphs should become separate interaction chunks"
                Expect.stringContains chunks[0] "open System" "First chunk should keep the open directive"
                Expect.stringContains chunks[1] "member _.B = 2" "Indented type body should stay in the same chunk"
                Expect.stringContains chunks[2] "local + 1" "Function body should stay in the same chunk"
                Expect.equal (chunks[3].Trim()) "let result = build ()" "Final top-level binding should be its own chunk"

            testCase "splitInteractionBatch flushes explicit terminators and trims trailing double-semicolons" <| fun _ ->
                let code =
                    """
open System;;
let x = 1

printfn "%d" x
"""

                let chunks = ExecHelpers.splitInteractionBatch code
                Expect.equal chunks.Length 3 "Explicit terminators and later top-level paragraphs should each become separate chunks"
                Expect.equal (chunks[0].Trim()) "open System" "Trailing ;; should be removed from the flushed chunk"
                Expect.equal (chunks[1].Trim()) "let x = 1" "Subsequent top-level code should remain available to later chunks"
                Expect.equal (chunks[2].Trim()) "printfn \"%d\" x" "Later top-level paragraphs should still be preserved"

            testCase "single EvalInteraction stops after an explicit terminator inside the same string" <| fun _ ->
                use handle = new FsiSession.Handle("terminator-probe")
                let code =
                    """
open System;;
printfn "AFTER-OPEN"
let x = 1
"""

                let result, diagnostics = handle.EvalInteraction(code)
                Expect.equal result (Choice1Of2 None) "FCS still reports the first interaction as successful"
                Expect.equal diagnostics.Length 0 "No direct diagnostics are reported for the truncated interaction"

                let query, queryDiagnostics = handle.EvalExpression("x")

                match query with
                | Choice1Of2 _ -> failtest "x should not be defined when the remainder of the string is ignored"
                | Choice2Of2 ex ->
                    Expect.stringContains ex.Message "earlier error" "The session should report that later fragments were skipped"

                Expect.isGreaterThanOrEqual queryDiagnostics.Length 1 "A follow-up query should surface missing binding diagnostics"
                Expect.equal (handle.StdoutText().Contains("AFTER-OPEN")) false "Statements after the explicit terminator should not execute in the same EvalInteraction"

            testAsync "EnsureSupervisor creates supervisor actor and installs PcslFileSystem" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun system supervisor storage ->
                        async {
                            let expectedPath = "akka://fsi-tests/user/fsi/supervisor"
                            Expect.equal (supervisor.Path.ToString()) expectedPath "Supervisor should live under /user/fsi"

                            let resolved = AkkaFsiBootstrap.GetSupervisor system
                            Expect.isSome resolved "Supervisor should be discoverable"
                            Expect.equal resolved.Value supervisor "Resolved supervisor should equal ensured instance"

                            let fileSystem = FileSystemAutoOpens.FileSystem
                            Expect.equal (fileSystem.GetType()) (typeof<PcslFileSystem>) "PcslFileSystem should be installed"

                            let again = AkkaFsiBootstrap.EnsureSupervisorWithStorage(system, storage :> IPcslStorage)
                            Expect.equal again supervisor "EnsureSupervisor should be idempotent"
                        })
            }

            testAsync "Supervisor returns assembly version for GetVesion" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let! version = ask<OpResult> supervisor GetVesion
                            Expect.equal version.op "GetVesion" "operation name should round-trip"
                            Expect.equal version.assemblyName "Akka.FSI.Supervisor" "assembly name should match package"
                            Expect.equal version.assemblyVersion (Some "1.562.101.201") "assembly version should match current build"
                            Expect.isTrue version.fileVersion.IsSome "file version should be available"
                            Expect.isTrue version.actorPath.IsSome "actor path should be included"
                            Expect.stringContains version.actorPath.Value "/user/fsi/supervisor" "actor path should point to supervisor"
                        })
            }

            testAsync "Supervisor answers GetVesion over Akka.Remote" {
                let host = "127.0.0.1"
                let supervisorPort = getFreePort ()
                let supervisorSystemName = "fsi-remote-supervisor-" + Guid.NewGuid().ToString("N")
                let clientSystemName = "fsi-remote-client-" + Guid.NewGuid().ToString("N")

                let supervisorSystem = ActorSystem.Create(supervisorSystemName, remoteConfigWithPort host supervisorPort)
                let clientSystem = ActorSystem.Create(clientSystemName, remoteConfigWithPort host 0)
                let storage = RecordingStorage()

                let! outcome =
                    async {
                        let supervisor = AkkaFsiBootstrap.EnsureSupervisorWithStorage(supervisorSystem, storage :> IPcslStorage)
                        let remotePath = $"akka.tcp://{supervisorSystemName}@{host}:{supervisorPort}/user/fsi/supervisor"
                        let selection = clientSystem.ActorSelection(remotePath)
                        let! version = selection.Ask<OpResult>(GetVesion, systemTimeout) |> Async.AwaitTask
                        Expect.equal version.op "GetVesion" "operation name should round-trip over remoting"
                        Expect.equal version.assemblyName "Akka.FSI.Supervisor" "assembly name should match package over remoting"
                        Expect.equal version.assemblyVersion (Some "1.562.101.201") "assembly version should match current build over remoting"
                        Expect.isTrue version.fileVersion.IsSome "file version should be available over remoting"
                        Expect.isTrue version.actorPath.IsSome "actor path should be available over remoting"
                        Expect.equal version.actorPath.Value (supervisor.Path.ToString()) "actor path should match the remote supervisor path"
                    }
                    |> Async.Catch

                do! clientSystem.Terminate() |> Async.AwaitTask |> Async.Ignore
                do! clientSystem.WhenTerminated |> Async.AwaitTask |> Async.Ignore
                do! supervisorSystem.Terminate() |> Async.AwaitTask |> Async.Ignore
                do! supervisorSystem.WhenTerminated |> Async.AwaitTask |> Async.Ignore

                match outcome with
                | Choice1Of2 () -> ()
                | Choice2Of2 ex -> return raise ex
            }

            testAsync "Remote GetVesion stays responsive during long-running ExecCode" {
                let host = "127.0.0.1"
                let supervisorPort = getFreePort ()
                let supervisorSystemName = "fsi-remote-supervisor-busy-" + Guid.NewGuid().ToString("N")
                let clientSystemName = "fsi-remote-client-busy-" + Guid.NewGuid().ToString("N")

                let supervisorSystem = ActorSystem.Create(supervisorSystemName, remoteConfigWithPort host supervisorPort)
                let clientSystem = ActorSystem.Create(clientSystemName, remoteConfigWithPort host 0)
                let storage = RecordingStorage()

                let! outcome =
                    async {
                        let _ = AkkaFsiBootstrap.EnsureSupervisorWithStorage(supervisorSystem, storage :> IPcslStorage)
                        let remotePath = $"akka.tcp://{supervisorSystemName}@{host}:{supervisorPort}/user/fsi/supervisor"
                        let selection = clientSystem.ActorSelection(remotePath)

                        let exec =
                            mkExec
                                "req-remote-busy"
                                "alpha"
                                """
open System.Diagnostics
let sw = Stopwatch.StartNew()
while sw.ElapsedMilliseconds < 3000L do
    ()
42
"""

                        let! execTask =
                            async {
                                let! result = selection.Ask<ExecResult>(exec, TimeSpan.FromSeconds 20.0) |> Async.AwaitTask
                                return result
                            }
                            |> Async.StartChild

                        do! Async.Sleep 250

                        let! version = selection.Ask<OpResult>(GetVesion, systemTimeout) |> Async.AwaitTask
                        Expect.equal version.op "GetVesion" "operation name should still round-trip while exec is running"
                        Expect.equal version.assemblyName "Akka.FSI.Supervisor" "assembly name should match package during long exec"

                        let! execResult = execTask
                        Expect.isTrue execResult.ok "Long-running remote execution should still complete"
                        Expect.equal execResult.resultJson (Some "42") "Long-running remote execution should preserve result"
                    }
                    |> Async.Catch

                do! clientSystem.Terminate() |> Async.AwaitTask |> Async.Ignore
                do! clientSystem.WhenTerminated |> Async.AwaitTask |> Async.Ignore
                do! supervisorSystem.Terminate() |> Async.AwaitTask |> Async.Ignore
                do! supervisorSystem.WhenTerminated |> Async.AwaitTask |> Async.Ignore

                match outcome with
                | Choice1Of2 () -> ()
                | Choice2Of2 ex -> return raise ex
            }

            testAsync "Caller ask timeout does not cancel in-flight session execution" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let exec =
                                mkExec
                                    "req-timeout-survives"
                                    "alpha"
                                    """
open System.Diagnostics
let sw = Stopwatch.StartNew()
while sw.ElapsedMilliseconds < 1200L do
    ()
let survivedTimeout = 42
"""

                            let! timedOut =
                                async {
                                    let! outcome =
                                        async {
                                            let! _ =
                                                supervisor.Ask<ExecResult>(exec, TimeSpan.FromMilliseconds 100.0)
                                                |> Async.AwaitTask
                                            return ()
                                        }
                                        |> Async.Catch

                                    match outcome with
                                    | Choice1Of2 () -> return false
                                    | Choice2Of2 ex ->
                                        return ex.Message.Contains("Timeout after", StringComparison.OrdinalIgnoreCase)
                                }

                            Expect.isTrue timedOut "Short ask timeout should fire at caller side"

                            do! Async.Sleep 1500

                            let! followUp =
                                ask<ExecResult>
                                    supervisor
                                    (mkExec "req-timeout-survives-read" "alpha" "survivedTimeout")

                            Expect.isTrue followUp.ok "Execution should keep running after caller ask timeout"
                            Expect.equal followUp.resultJson (Some "42") "Completed execution should preserve its binding"
                        })
            }

            testAsync "ListSessions and GetSessionInfo stay responsive while long-running ExecCode is running" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let exec =
                                mkExec
                                    "req-session-cache-busy"
                                    "alpha"
                                    """
open System.Diagnostics
let sw = Stopwatch.StartNew()
while sw.ElapsedMilliseconds < 1500L do
    ()
let busyValue = 42
"""

                            let! execTask =
                                async {
                                    let! result =
                                        supervisor.Ask<ExecResult>(exec, TimeSpan.FromSeconds 20.0)
                                        |> Async.AwaitTask
                                    return result
                                }
                                |> Async.StartChild

                            do! Async.Sleep 150

                            let! sessions =
                                supervisor.Ask<Sessions>({ all = true }, TimeSpan.FromSeconds 2.0)
                                |> Async.AwaitTask

                            let infoRequest: GetSessionInfo = { session = "alpha" }

                            let! info =
                                supervisor.Ask<SessionInfo>(infoRequest, TimeSpan.FromSeconds 2.0)
                                |> Async.AwaitTask

                            Expect.isTrue
                                (sessions.items |> List.exists (fun item -> item.session = "alpha"))
                                "ListSessions should still return the busy session"
                            Expect.equal info.status "busy" "GetSessionInfo should report busy while ExecCode is in flight"

                            let! execResult = execTask
                            Expect.isTrue execResult.ok "Long-running execution should still complete"
                        })
            }

            testAsync "idleRestartMs is not wired to ReceiveTimeout or passivation" {
                let customConfig =
                    ConfigurationFactory.ParseString(
                        """
                        akka.fsi.timeouts.idle-restart-ms = 100
                        """
                    ).WithFallback(testConfig)

                do!
                    withSupervisorUsingConfig customConfig (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let exec = mkExec "req-no-passivation" "alpha" "let stillHere = 7\nstillHere"
                            let! _ = ask<ExecResult> supervisor exec

                            do! Async.Sleep 500

                            let infoRequest: GetSessionInfo = { session = "alpha" }
                            let! info = ask<SessionInfo> supervisor infoRequest
                            Expect.equal info.status "ready" "Session should still exist after idleRestartMs elapses"
                            Expect.isTrue
                                (info.variables |> List.exists (fun (name, _) -> name = "stillHere"))
                                "Bindings should still be present because no passivation/receive-timeout is wired"
                        })
            }

            testAsync "ExecCode returns result, captures value and auto commits" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec = mkExec "req-success" "alpha" "let value = 40 + 2\nvalue"
                            let! result = ask<ExecResult> supervisor exec

                            Expect.isTrue result.ok "Execution should succeed"
                            Expect.equal result.resultJson (Some "42") "fsi_it should be captured as JSON"
                            Expect.isTrue (result.stdout <> null) "stdout should always be captured"

                            expectResultStored storage exec.id
                        })
            }

            testAsync "ExecCode failure reports ExecutionError and does not store result" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec = mkExec "req-fail" "alpha" "failwith \"boom\""
                            let! result = ask<ExecResult> supervisor exec

                            Expect.isFalse result.ok "Execution should fail"
                            let error = result.error |> Option.defaultWith (fun () -> failwith "Expected error")
                            Expect.equal error.code "ExecutionError" "Failure should be tagged as ExecutionError"
                            Expect.isNone (storage.TryFind ("results/" + exec.id + ".json")) "Failed results should not be stored"
                        })
            }

            testAsync "ExecCodeJson deserializes payload" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec = mkExec "req-json" "alpha" "1 + 1"
                            let json = JsonCodec.serialize exec
                            let! result = ask<ExecResult> supervisor (ExecCodeJson json)
                            Expect.isTrue result.ok "Execution from JSON should succeed"
                            Expect.equal result.resultJson (Some "2") "JSON execution should capture result"
                            expectResultStored storage exec.id
                        })
            }

            testAsync "ExecCode tracks sessions in supervisor state" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun system supervisor _ ->
                        async {
                            let execA = mkExec "req-a" "alpha" "42"
                            let execB = mkExec "req-b" "beta" "21 + 21"
                            let! _ = ask<ExecResult> supervisor execA
                            let! _ = ask<ExecResult> supervisor execB

                            let listRequest: ListSessions = { all = true }
                            let! sessions = ask<Sessions> supervisor listRequest
                            let sessionIds = sessions.items |> List.map (fun value -> value.session) |> Set.ofList
                            Expect.equal sessionIds (Set.ofList [ "alpha"; "beta" ]) "Supervisor should track both sessions"
                        })
            }

            testAsync "ExecCode executes multi-interaction batches separated by terminators" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let define = mkExec "req-batch-define" "alpha" "let firstValue = 1;;\nlet secondValue = 2"
                            let read = mkExec "req-batch-read" "alpha" "secondValue"

                            let! defineResult = ask<ExecResult> supervisor define
                            let! readResult = ask<ExecResult> supervisor read

                            Expect.isTrue defineResult.ok "Batch execution should succeed"
                            Expect.isTrue readResult.ok "Follow-up read should succeed"
                            Expect.equal readResult.resultJson (Some "2") "Later interactions in the same batch should persist"
                        })
            }

            testAsync "Session info reflects missing and existing sessions" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let missingRequest: GetSessionInfo = { session = "ghost" }
                            let! missing = ask<SessionInfo> supervisor missingRequest
                            Expect.equal missing.status "missing" "Unknown session should be reported as missing"

                            let exec = mkExec "req-session" "alpha" "let y = 10\ny"
                            let! _ = ask<ExecResult> supervisor exec
                            let infoRequest: GetSessionInfo = { session = "alpha" }
                            let! info = ask<SessionInfo> supervisor infoRequest
                            Expect.equal info.session "alpha" "Session name should match"
                            Expect.equal info.status "ready" "Session should be ready after execution"
                            Expect.isTrue (info.variables |> List.exists (fun (name, _) -> name = "y")) "Session variables should contain y"
                        })
            }

            testAsync "ResetSession clears existing session state and reports missing afterwards" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let exec = mkExec "req-reset" "alpha" "let keepValue = 42\nkeepValue"
                            let! _ = ask<ExecResult> supervisor exec

                            let beforeResetRequest: GetSessionInfo = { session = "alpha" }
                            let! beforeReset = ask<SessionInfo> supervisor beforeResetRequest
                            Expect.equal beforeReset.status "ready" "Session should exist before reset"
                            Expect.isTrue (beforeReset.variables |> List.exists (fun (name, _) -> name = "keepValue")) "Binding should exist before reset"

                            let resetRequest: ResetSession = { session = "alpha" }
                            let! reset = ask<ResetSessionResult> supervisor resetRequest
                            Expect.equal reset.session "alpha" "Reset should target the requested session"
                            Expect.isTrue reset.existed "Reset should report existing session"
                            Expect.equal reset.status "reset" "Reset should report reset status"

                            let afterResetRequest: GetSessionInfo = { session = "alpha" }
                            let! afterReset = ask<SessionInfo> supervisor afterResetRequest
                            Expect.equal afterReset.status "missing" "Session should be removed after reset"

                            let! evalAfterReset = ask<ExecResult> supervisor (mkExec "req-after-reset" "alpha" "keepValue")
                            Expect.isFalse evalAfterReset.ok "Binding should no longer exist after reset"
                            let error = evalAfterReset.error |> Option.defaultWith (fun () -> failwith "Expected error after reset")
                            Expect.equal error.code "ExecutionError" "Missing binding should surface as execution error"
                        })
            }
            (*
            這段測試會觸發 OpenFileForReadShim 的原因不是測試本身在找 input.fsx，而是 FSI 執行流程的預設行為：

            withSupervisorUsing 會建立 FsiSupervisorActor，它在初始化時安裝全域的 PcslFileSystem（Supervisor.fs），所以後續 FCS 的檔案讀取都走這個 shim。
            ask<ExecResult> 最終走到 FsiWorkerActor.HandleExec，用 FsiEvaluationSession.EvalInteraction 執行字串程式碼（FsiWorker.fs、FsiSession.fs）。
            FCS/FSI 會用一個「虛擬檔名」當作互動輸入的來源，預設就是 input.fsx。它會嘗試用 IFileSystem.OpenFileForReadShim 去讀這個檔來做診斷/定位（PcslFileSystem.fs）。因為 RecordingStorage 沒有、OS 也沒有，所以會丟 FileNotFoundException，但這個例外在 FCS 內部被吃掉，執行仍然用傳進去的字串內容完成。
            所以 unit test 不會失敗是正常的：測試關心的是 session info/variables，而不是檔案讀寫；這個「沒有實體 input.fsx」正是 FSI 的預設情境。
            測試結果是合理的。如果你想避免這個 input.fsx 的讀取嘗試，可以在 storage/overlay 放一個同名空檔，或在測試中改成明確 #load 某個已存在的腳本。

            *)
            (*
            專案 Akka.FSI.Supervisor.Tests 中

            解釋一下

                        testAsync "Session info reflects missing and existing sessions" {
                            do!
                                withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                                    async {
                                        let! missing = ask<SessionInfo> supervisor { session = "ghost" }
                                        Expect.equal missing.status "missing" "Unknown session should be reported as missing"

                                        let exec = mkExec "req-session" "alpha" "let y = 10\ny"
                                        let! _ = ask<ExecResult> supervisor exec
                                        let! info = ask<SessionInfo> supervisor { session = "alpha" }
                                        Expect.equal info.session "alpha" "Session name should match"
                                        Expect.equal info.status "ready" "Session should be ready after execution"
                                        Expect.isTrue (info.variables |> List.exists (fun (name, _) -> name = "y")) "Session variables should contain y"
                                    })
                        }
			
            為什麼會觸發

                    member _.OpenFileForReadShim(path, ?useMemoryMappedFile, ?shouldShadowCopy) =
                        match storageHit path with
                        | Some content -> toMemoryStream content
                        | None when isAllowedRoot path ->
                            baseFs.OpenFileForReadShim(
                                path,
                                ?useMemoryMappedFile = useMemoryMappedFile,
                                ?shouldShadowCopy = shouldShadowCopy
                            )
                        | _ -> raise (FileNotFoundException(sprintf "File '%s' not found" path))

            找不到 input.fsx 然後為什麼即使沒有這個檔此 unit test 也不會失敗，這是 by default 的測試情境嗎?測試結果正確?			

            ✦ 這是一個非常好的觀察。這個現象的發生與 F# Compiler Service (FCS) 的內部運作機制以及你的 PcslFileSystem
              的實作方式有關。

              以下是詳細的解釋：

              1. 為什麼會觸發 FileNotFoundException 找 input.fsx？

              當你呼叫 mkExec "req-session" "alpha" "let y = 10\ny" 並透過 EvalInteraction 執行時，FSI (FCS)
              內部會將這段程式碼字串視為一個來自虛擬檔案的輸入。FSI 通常會給這個虛擬檔案一個預設名稱，常見的就是 input.fsx
              (或是類似的暫時名稱)。

              儘管程式碼內容已經在記憶體中（傳遞給了 EvalInteraction），FCS 在某些編譯或分析階段（例如檢查檔案時間戳記、處理 #load
              的相對路徑解析、或是錯誤報告的來源定位）仍然會嘗試透過 IFileSystem 去查詢這個「檔案」的資訊。

              流程如下：
               1. FCS 呼叫 IFileSystem.OpenFileForReadShim("input.fsx")。
               2. 你的 PcslFileSystem 接到請求。
               3. storageHit path 回傳 None（因為 RecordingStorage 裡面沒有這個檔案）。
               4. 檢查 isAllowedRoot path。因為你的測試配置中 overlay-roots = []，這會導致 isAllowedRoot 對所有路徑都回傳
                  true（允許回退到 OS）。
               5. 進入 baseFs.OpenFileForReadShim(...)，這會呼叫實際的 OS 檔案系統。
               6. OS 檔案系統在硬碟上找不到 input.fsx，因此拋出 System.IO.FileNotFoundException。

              2. 為什麼測試沒有失敗 (Test Passes)？

              測試通過的原因是 F# Compiler Service (FCS) 內部捕獲 (Catch) 了這個例外，並且能夠容錯處理。

               * 容錯機制：當 FCS 執行
                 EvalInteraction（互動式評估）時，它知道來源是「字串」而非實體檔案。雖然它嘗試去讀取檔案（可能是為了某些一致性檢查或
                 除錯資訊），但當發生 FileNotFoundException
                 時，它會認定這不是一個致命錯誤，並繼續使用記憶體中的字串內容進行編譯和執行。
               * 執行結果：因為 FCS 忽略了這個檔案找不到的錯誤，程式碼 let y = 10 成功編譯並執行。
               * Session 狀態：
                   * 變數 y 被成功綁定。
                   * 執行沒有回傳 Choice2Of2 (Error)。
                   * 你的測試斷言 Expect.equal info.status "ready" 和檢查變數 y 存在，都能正確通過。

              3. 這是 Default 的測試情境嗎？測試結果正確嗎？

               * 是否為 Default 情境：是的，在使用自訂 IFileSystem 且設定為「找不到就回退給 OS
                 (baseFs)」的架構下，這是一個正常的副作用。如果你沒有特別在虛擬檔案系統中攔截 input.fsx，它就會一路穿透到 OS
                 層並報錯。
               * 測試結果是否正確：是正確的。測試驗證的是「Session 能夠執行程式碼並更新狀態」，這一點已經達成。FileNotFoundException
                 在這裡是 FCS 內部的雜訊 (Noise)，不影響功能驗證。

              總結

              這個例外是因為 PcslFileSystem 忠實地將所有找不到的檔案請求都轉發給了 OS，而 OS 確實找不到這個由 FCS 虛擬產生的
              input.fsx。FCS 足夠聰明，知道在互動模式下這不是致命傷，所以「吞掉」了這個例外並繼續工作。

              如果你覺得這個例外很困擾（例如在 Debug 時會一直中斷），你可以在 PcslFileSystem 中針對 input.fsx
              做特殊處理，或者就把它當作是 FSI 整合時的已知行為。
            *)

            testAsync "ListSessions returns all active sessions" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let execA = mkExec "req-a" "alpha" "42"
                            let execB = mkExec "req-b" "beta" "21 + 21"
                            let! _ = ask<ExecResult> supervisor execA
                            let! _ = ask<ExecResult> supervisor execB

                            let listRequest: ListSessions = { all = true }
                            let! sessions = ask<Sessions> supervisor listRequest
                            let sessionNames = sessions.items |> List.map (fun s -> s.session)
                            Expect.contains sessionNames "alpha" "Session alpha should be listed"
                            Expect.contains sessionNames "beta" "Session beta should be listed"
                        })
            }

            testAsync "Checkpoint stores snapshot and updates session state" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec = mkExec "req-check" "alpha" "let z = 5\nz"
                            let! _ = ask<ExecResult> supervisor exec

                            let checkpointRequest: Checkpoint =
                                { session = "alpha"
                                  id = Some "cp-1"
                                  comment = Some "first" }

                            let! checkpoint =
                                ask<CheckpointResult>
                                    supervisor
                                    checkpointRequest

                            Expect.equal checkpoint.id "cp-1" "Checkpoint should echo requested id"
                            let snapshotPath = "snapshots/alpha/cp-1.json"
                            Expect.isSome (storage.TryFind snapshotPath) "Snapshot should be persisted"

                            let infoRequest: GetSessionInfo = { session = "alpha" }
                            let! info = ask<SessionInfo> supervisor infoRequest
                            Expect.equal info.lastCheckpointId (Some "cp-1") "Session should record last checkpoint id"
                        })
            }

            testAsync "Fork creates a new session from checkpoint" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor _ ->
                        async {
                            let exec = mkExec "req-fork" "alpha" "let x = 1\nx"
                            let! _ = ask<ExecResult> supervisor exec
                            let checkpointRequest: Checkpoint =
                                { session = "alpha"
                                  id = Some "fork-cp"
                                  comment = None }

                            let! _ =
                                ask<CheckpointResult>
                                    supervisor
                                    checkpointRequest

                            let forkRequest: Fork =
                                { fromSession = "alpha"
                                  newSession = "beta"
                                  checkpointId = Some "fork-cp" }

                            let! fork =
                                ask<CheckpointResult>
                                    supervisor
                                    forkRequest

                            Expect.equal fork.session "beta" "Fork should return new session name"

                            let infoRequest: GetSessionInfo = { session = "beta" }

                            let! info =
                                async {
                                    let mutable latest = Unchecked.defaultof<SessionInfo>
                                    let mutable ready = false

                                    for _ in 1 .. 10 do
                                        let! current = ask<SessionInfo> supervisor infoRequest
                                        latest <- current

                                        if current.status = "ready" then
                                            ready <- true
                                        else
                                            do! Async.Sleep 100

                                    Expect.isTrue ready "Forked session should eventually become ready"
                                    return latest
                                }

                            Expect.equal info.status "ready" "Forked session should be ready"
                        })
            }

            testAsync "Join aggregates committed child results" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec1 = mkExec "child-1" "alpha" "100"
                            let exec2 = mkExec "child-2" "alpha" "200"
                            let! _ = ask<ExecResult> supervisor exec1
                            let! _ = ask<ExecResult> supervisor exec2

                            let! join =
                                ask<CheckpointResult>
                                    supervisor
                                    { parentSession = "alpha"
                                      childSessions = [ exec1.id; exec2.id ]
                                      reducer = None }

                            let path = sprintf "results/%s.json" join.id
                            let stored = storage.TryFind path |> Option.defaultValue ""
                            Expect.stringContains stored "child-1" "Join payload should include first child"
                            Expect.stringContains stored "child-2" "Join payload should include second child"
                            Expect.equal join.session "alpha" "Join response should retain parent session"
                        })
            }

            testAsync "File operations delegate to Pcsl storage" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let put =
                                { path = "prelude.fsx"
                                  content = "printfn \"hi\""
                                  encoding = None }

                            let! putOk = ask<bool> supervisor put
                            Expect.isTrue putOk "PutFile should return true"

                            Expect.isSome (storage.TryFind "scripts/prelude.fsx")
                                "File should be stored under scripts keyspace"

                            let! file = ask<FileContent> supervisor { path = "prelude.fsx" }
                            Expect.equal file.content (Some "printfn \"hi\"") "GetFile should return stored content"

                            let! deleted = ask<bool> supervisor ({ path = "prelude.fsx" }: DeleteFile)
                            Expect.isTrue deleted "DeleteFile should return true"
                            Expect.isNone (storage.TryFind "scripts/prelude.fsx") "File should be removed after delete"
                        })
            }

            testAsync "Commit requests propagate to storage" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let! committed = ask<bool> supervisor { keyspace = "scripts"; comment = Some "snapshot" }
                            Expect.isTrue committed "Commit should return true"
                            Expect.equal storage.CommitCalls [ "scripts", Some "snapshot" ] "Commit should be recorded"
                        })
            }

            testAsync "Bootstrap helpers use JSON helpers" {
                do!
                    withSupervisorUsing (fun () -> RecordingStorage()) (fun _ supervisor storage ->
                        async {
                            let exec = mkExec "req-api" "alpha" "3 * 4"
                            let! resultJson = AkkaFsiBootstrap.ExecJson supervisor (JsonCodec.serialize exec)
                            let result = JsonCodec.deserialize<ExecResult> resultJson
                            Expect.isTrue result.ok "ExecJson should return ok result"

                            let! _ = AkkaFsiBootstrap.PutFileJson supervisor "samples/demo.fsx" "()"
                            Expect.isSome (storage.TryFind "scripts/samples/demo.fsx") "PutFileJson should write content"

                            let! infoJson = AkkaFsiBootstrap.GetSessionInfoJson supervisor "alpha"
                            let info = JsonCodec.deserialize<SessionInfo> infoJson
                            Expect.equal info.session "alpha" "GetSessionInfoJson should return requested session"
                        })
            }

            test "SupervisorSettingsReader loads values from configuration" {
                let config =
                    ConfigurationFactory.ParseString(
                        """
                        akka.fsi {
                          mode = "outproc"
                          worker-count = 3
                          auto-session = "warm"
                          timeouts {
                            startup-ms = 100
                            exec-ms = 200
                            idle-restart-ms = 300
                          }
                          pcsl2 {
                            scripts-keyspace = "code"
                            results-keyspace = "out"
                            snapshots-keyspace = "snap"
                            auto-commit = false
                          }
                          filesystem {
                            overlay-roots = ["/tmp/fsi"]
                            allow-os-read = false
                            allow-os-write = true
                          }
                        }
                        """
                    )

                let settings = SupervisorSettingsReader.load (Some config)
                Expect.equal settings.mode "outproc" "Mode should match config"
                Expect.equal settings.workerCount 3 "Worker count should match"
                Expect.equal settings.autoSession "warm" "Auto session should match"
                Expect.equal settings.timeouts.execMs 200 "Exec timeout should match"
                Expect.equal settings.pcsl.autoCommit false "Auto commit should be disabled"
                Expect.equal settings.filesystem.overlayRoots [ "/tmp/fsi" ] "Overlay roots should match"
            }
        ]
