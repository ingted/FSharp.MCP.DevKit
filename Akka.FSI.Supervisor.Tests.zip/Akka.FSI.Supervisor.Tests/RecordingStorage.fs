﻿namespace Akka.FSI.Supervisor.Tests

open System
open System.Collections.Concurrent
open System.Collections.Generic
open Akka.FSI.Contracts
open Akka.FSI.Supervisor
open PersistedConcurrentSortedList.IFileSystem

/// <summary>
/// Recording test double for <see cref="IPcslStorage"/> that keeps writes in-memory
/// and tracks commit invocations.
/// </summary>
type RecordingStorage() =
    let store = ConcurrentDictionary<string, string>()
    let commits = List<(string * string option)>()

    member _.Keys = store.Keys |> Seq.toList
    member _.TryFind path =
        match store.TryGetValue path with
        | true, value -> Some value
        | _ -> None

    member _.CommitCalls = commits |> Seq.toList

    interface IPcslStorage with
        member _.Put(path, content) =
            store.AddOrUpdate(path, content, fun _ _ -> content) |> ignore

        member _.Delete(path) =
            store.TryRemove path |> ignore

        member _.TryGet(path) =
            match store.TryGetValue path with
            | true, value -> Some value
            | _ -> None

        member _.List(prefix) =
            store
            |> Seq.choose (fun (KeyValue(k, v)) ->
                if k.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) then
                    Some
                        { path = k
                          content = v
                          timestampUtc = DateTime.UtcNow }
                else
                    None)
            |> Seq.toList

        member _.Commit(keyspace, comment) =
            commits.Add((keyspace, comment))
