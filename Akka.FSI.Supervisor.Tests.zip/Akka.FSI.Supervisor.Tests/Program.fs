﻿module Akka.FSI.Supervisor.Tests.Program

open Expecto

[<EntryPoint>]
let main argv =
    ExpectoBridge().RunAll()
    0
    //runTestsWithCLIArgs [] argv SupervisorSpecification.tests
