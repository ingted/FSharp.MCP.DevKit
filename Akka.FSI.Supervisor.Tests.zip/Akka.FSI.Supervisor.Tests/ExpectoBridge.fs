﻿namespace Akka.FSI.Supervisor.Tests

open Expecto
open Xunit

// Bridges the Expecto suite into xUnit so that `dotnet test` discovers and executes the tests.
type ExpectoBridge() =
    [<Fact>]
    member _.RunAll() =
        let exitCode =
            Tests.runTestsWithCLIArgs [ Expecto.Tests.CLIArguments.Sequenced ] [||] SupervisorSpecification.tests

        Assert.Equal(0, exitCode)

